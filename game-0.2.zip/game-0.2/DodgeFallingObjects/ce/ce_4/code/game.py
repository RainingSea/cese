import pygame
import random

class Block:
    def __init__(self, x: int, y: int, width: int, height: int, speed: int):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.speed = speed

    def fall(self):
        self.y += self.speed

    def draw(self, surface: pygame.Surface):
        pygame.draw.rect(surface, (255, 0, 0), (self.x, self.y, self.width, self.height))

class Player:
    def __init__(self, x: int, width: int, height: int):
        self.x = x
        self.width = width
        self.height = height

    def move(self, direction: str):
        if direction == 'left':
            self.x -= 5
        elif direction == 'right':
            self.x += 5

    def draw(self, surface: pygame.Surface):
        pygame.draw.rect(surface, (0, 255, 0), (self.x, 550, self.width, self.height))

class Game:
    def __init__(self):
        self.player = Player(300, 50, 50)
        self.blocks = []
        self.score = 0
        self.game_over = False

    def run(self):
        pygame.init()
        screen = pygame.display.set_mode((600, 600))
        clock = pygame.time.Clock()
        
        while not self.game_over:
            self.handle_events()
            self.spawn_block()
            self.update_blocks()
            self.check_collision()
            self.draw(screen)
            pygame.display.flip()
            clock.tick(60)

        pygame.quit()

    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.game_over = True

        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            self.player.move('left')
        if keys[pygame.K_RIGHT]:
            self.player.move('right')

    def spawn_block(self):
        if random.randint(1, 20) == 1:  # Randomly spawn a block
            block_width = random.randint(20, 100)
            block_x = random.randint(0, 600 - block_width)
            new_block = Block(block_x, 0, block_width, 20, 5)
            self.blocks.append(new_block)

    def update_blocks(self):
        for block in self.blocks:
            block.fall()

    def check_collision(self):
        for block in self.blocks:
            if (self.player.x < block.x + block.width and
                self.player.x + self.player.width > block.x and
                550 < block.y + block.height):
                self.game_over = True

    def draw(self, surface: pygame.Surface):
        surface.fill((0, 0, 0))  # Clear the screen
        self.player.draw(surface)
        for block in self.blocks:
            block.draw(surface)
        self.display_score(surface)

    def display_score(self, surface: pygame.Surface):
        font = pygame.font.Font(None, 36)
        score_text = font.render(f'Score: {self.score}', True, (255, 255, 255))
        surface.blit(score_text, (10, 10))