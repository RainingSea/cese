import unittest
import pygame
from game import Game, Player, Block

class TestDodgeFallingObjectsGame(unittest.TestCase):

    def setUp(self):
        # Initialize the game and its components
        self.game = Game()
        self.player = self.game.player

    def test_player_movement(self):
        # Functionality 1: Player Movement
        initial_x = self.player.x

        # Test moving left
        self.player.move('left')
        self.assertLess(self.player.x, initial_x, "Player should move left")

        # Test moving right
        initial_x = self.player.x
        self.player.move('right')
        self.assertGreater(self.player.x, initial_x, "Player should move right")

        # Test moving beyond the left edge
        self.player.x = 0
        self.player.move('left')
        self.assertEqual(self.player.x, 0, "Player should not move beyond the left edge")

        # Test moving beyond the right edge
        self.player.x = 550
        self.player.move('right')
        self.assertEqual(self.player.x, 550, "Player should not move beyond the right edge")

    def test_collision_detection(self):
        # Functionality 2: Collision Detection
        block = Block(self.player.x, 540, self.player.width, 20, 0)
        self.game.blocks.append(block)
        self.game.check_collision()
        self.assertTrue(self.game.game_over, "Game should end when player collides with a block")

        # Reset game state for next test
        self.game.game_over = False
        self.game.blocks.clear()

        # Test avoiding a block
        block = Block(self.player.x + 100, 540, self.player.width, 20, 0)
        self.game.blocks.append(block)
        self.game.check_collision()
        self.assertFalse(self.game.game_over, "Game should continue when player avoids a block")

    def test_falling_blocks_behavior(self):
        # Functionality 3: Falling Blocks Behavior
        self.game.spawn_block()
        self.assertTrue(any(block.y == 0 for block in self.game.blocks), "Blocks should spawn at the top of the screen")

        # Test block falling
        block = Block(0, 0, 50, 20, 5)
        self.game.blocks.append(block)
        self.game.update_blocks()
        self.assertEqual(block.y, 5, "Block should fall down the screen")

    def test_scoring_system(self):
        # Functionality 4: Scoring System
        initial_score = self.game.score
        self.game.score += 1  # Simulate surviving for a second
        self.assertGreater(self.game.score, initial_score, "Score should increase over time")

        # Test score display on game over
        self.game.game_over = True
        self.assertEqual(self.game.score, 1, "Final score should be displayed on game over")

    def test_player_movement_constraints(self):
        # Functionality 5: Player Movement Constraints
        initial_y = 550  # Player's fixed vertical position
        self.player.move('left')
        self.assertEqual(self.player.x, initial_y, "Player should not move vertically")

        # Test horizontal movement only
        initial_x = self.player.x
        self.player.move('right')
        self.assertNotEqual(self.player.x, initial_x, "Player should move horizontally")

    def test_game_over_condition(self):
        # Functionality 6: Game Over Condition
        block = Block(self.player.x, 540, self.player.width, 20, 0)
        self.game.blocks.append(block)
        self.game.check_collision()
        self.assertTrue(self.game.game_over, "Game should end when player collides with a block")

        # Test game reset
        self.game.game_over = False
        self.assertFalse(self.game.game_over, "Game should reset after game over")

    def test_data_storage(self):
        # Functionality 7: Data Storage
        self.fail("Data storage functionality is not implemented in the codebase")

if __name__ == '__main__':
    unittest.main()
