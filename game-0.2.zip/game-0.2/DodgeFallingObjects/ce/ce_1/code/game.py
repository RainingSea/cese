import pygame
from player import Player
from block import Block

class Game:
    def __init__(self):
        self.player = Player(300, 50, 50)  # Initialize player at x=300, width=50, height=50
        self.falling_blocks = []
        self.score = 0
        self.speed = 5
        self.screen_width = 600
        self.screen_height = 400
        self.window = pygame.display.set_mode((self.screen_width, self.screen_height))
        pygame.display.set_caption("Dodge the Falling Blocks")

    def run(self):
        clock = pygame.time.Clock()
        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False

            keys = pygame.key.get_pressed()
            if keys[pygame.K_LEFT] and self.player.x_position > 0:
                self.player.move_left()
            if keys[pygame.K_RIGHT] and self.player.x_position < self.screen_width - self.player.width:
                self.player.move_right()

            self.spawn_block()
            self.update_blocks()
            self.check_collision()
            self.update_score()

            self.window.fill((0, 0, 0))  # Clear screen
            self.display_score()
            self.draw_player()
            self.draw_blocks()
            pygame.display.flip()
            clock.tick(60)  # Limit to 60 frames per second

        pygame.quit()

    def spawn_block(self):
        if random.randint(1, 20) == 1:  # Randomly spawn a block
            block_width = random.randint(20, 100)
            block_x = random.randint(0, self.screen_width - block_width)
            new_block = Block(block_x, 0, block_width, 20)  # Block height is fixed at 20
            self.falling_blocks.append(new_block)

    def update_blocks(self):
        for block in self.falling_blocks:
            block.fall(self.speed)

    def check_collision(self):
        for block in self.falling_blocks:
            if (self.player.x_position < block.x_position + block.width and
                self.player.x_position + self.player.width > block.x_position and
                self.player.height + self.screen_height - 50 > block.y_position):
                self.game_over()

    def update_score(self):
        self.score += 1  # Increment score over time

    def display_score(self):
        font = pygame.font.Font(None, 36)
        text = font.render(f'Score: {self.score}', True, (255, 255, 255))
        self.window.blit(text, (10, 10))

    def draw_player(self):
        pygame.draw.rect(self.window, (0, 255, 0), (self.player.x_position, self.screen_height - 50, self.player.width, self.player.height))

    def draw_blocks(self):
        for block in self.falling_blocks:
            pygame.draw.rect(self.window, (255, 0, 0), (block.x_position, block.y_position, block.width, block.height))

    def game_over(self):
        with open('scores.txt', 'a') as f:
            f.write(f'{self.score}\n')
        pygame.quit()