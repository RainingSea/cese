import unittest
import pygame
from game import Game
from player import Player
from block import Block
import os

class TestDodgeFallingObjectsGame(unittest.TestCase):

    def setUp(self):
        # Initialize the game and its components
        pygame.init()
        self.game = Game()
        self.player = self.game.player

    def test_player_movement(self):
        # Functionality 1: Player Movement
        initial_x = self.player.x_position

        # Simulate left arrow key press
        self.player.move_left()
        self.assertLess(self.player.x_position, initial_x, "Player should move left")

        # Simulate right arrow key press
        initial_x = self.player.x_position
        self.player.move_right()
        self.assertGreater(self.player.x_position, initial_x, "Player should move right")

        # Attempt to move beyond the left edge
        self.player.x_position = 0
        self.player.move_left()
        self.assertEqual(self.player.x_position, 0, "Player should not move beyond the left edge")

        # Attempt to move beyond the right edge
        self.player.x_position = self.game.screen_width - self.player.width
        self.player.move_right()
        self.assertEqual(self.player.x_position, self.game.screen_width - self.player.width, "Player should not move beyond the right edge")

    def test_collision_detection(self):
        # Functionality 2: Collision Detection
        block = Block(self.player.x_position, self.game.screen_height - 50, self.player.width, 20)
        self.game.falling_blocks.append(block)

        # Simulate collision
        self.game.check_collision()
        self.assertFalse(pygame.get_init(), "Game should end on collision")

        # Reset game for next test
        pygame.init()
        self.game = Game()

        # Simulate avoiding collision
        self.player.move_left()
        self.game.check_collision()
        self.assertTrue(pygame.get_init(), "Game should continue if no collision")

    def test_falling_blocks_behavior(self):
        # Functionality 3: Falling Blocks Behavior
        self.game.spawn_block()
        self.assertTrue(any(block.y_position == 0 for block in self.game.falling_blocks), "Blocks should spawn at the top")

        initial_speed = self.game.speed
        self.game.update_blocks()
        self.assertTrue(all(block.y_position > 0 for block in self.game.falling_blocks), "Blocks should fall downwards")

        # Simulate time passing to increase speed
        self.game.score = 1000
        self.game.update_blocks()
        self.assertGreater(self.game.speed, initial_speed, "Block speed should increase over time")

    def test_scoring_system(self):
        # Functionality 4: Scoring System
        initial_score = self.game.score
        self.game.update_score()
        self.assertGreater(self.game.score, initial_score, "Score should increase over time")

        # Simulate game over and check score display
        block = Block(self.player.x_position, self.game.screen_height - 50, self.player.width, 20)
        self.game.falling_blocks.append(block)
        self.game.check_collision()
        self.assertFalse(pygame.get_init(), "Game should end and display final score on collision")

    def test_player_movement_constraints(self):
        # Functionality 5: Player Movement Constraints
        initial_y = self.game.screen_height - 50

        # Attempt to move vertically
        self.player.move_left()
        self.assertEqual(self.game.screen_height - 50, initial_y, "Player should not move vertically")

        # Move left and right while block is falling
        self.player.move_left()
        self.assertNotEqual(self.player.x_position, initial_y, "Player should move left and right only")

    def test_game_over_condition(self):
        # Functionality 6: Game Over Condition
        block = Block(self.player.x_position, self.game.screen_height - 50, self.player.width, 20)
        self.game.falling_blocks.append(block)
        self.game.check_collision()
        self.assertFalse(pygame.get_init(), "Game should end immediately on collision")

        # Restart game after game over
        pygame.init()
        self.game = Game()
        self.assertTrue(pygame.get_init(), "Game should reset and allow restart")

    def test_data_storage(self):
        # Functionality 7: Data Storage
        block = Block(self.player.x_position, self.game.screen_height - 50, self.player.width, 20)
        self.game.falling_blocks.append(block)
        self.game.check_collision()

        with open('scores.txt', 'r') as f:
            scores = f.readlines()
            self.assertIn(f"{self.game.score}\n", scores, "Score should be saved to local text file")

if __name__ == '__main__':
    unittest.main()
