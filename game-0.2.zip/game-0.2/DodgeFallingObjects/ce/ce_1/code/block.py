import random

class Block:
    def __init__(self, x: int, y: int, width: int, height: int):
        self.x_position = x
        self.y_position = y
        self.width = width
        self.height = height

    def fall(self, speed: float):
        self.y_position += speed  # Move down by speed pixels