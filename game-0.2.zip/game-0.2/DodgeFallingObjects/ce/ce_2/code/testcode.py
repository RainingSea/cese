import unittest
import pygame
from game import Game
from player import Player
from block import Block

class TestDodgeFallingObjectsGame(unittest.TestCase):

    def setUp(self):
        # Initialize the game and its components
        self.game = Game()
        self.player = self.game.player
        self.blocks = self.game.blocks

    def test_player_movement(self):
        # Functionality 1: Test player movement to the left
        initial_x = self.player.x
        self.player.move('left')
        self.assertLess(self.player.x, initial_x, "Player should move left")

        # Test player movement to the right
        initial_x = self.player.x
        self.player.move('right')
        self.assertGreater(self.player.x, initial_x, "Player should move right")

        # Test player does not move beyond the left edge
        self.player.x = 0
        self.player.move('left')
        self.assertEqual(self.player.x, 0, "Player should not move beyond the left edge")

        # Test player does not move beyond the right edge
        self.player.x = 750
        self.player.move('right')
        self.assertEqual(self.player.x, 750, "Player should not move beyond the right edge")

    def test_collision_detection(self):
        # Functionality 2: Test collision detection
        block = Block(self.player.x, 50)
        block.y = self.player.y
        self.blocks.append(block)
        collision = self.game.check_collision()
        self.assertTrue(collision, "Collision should be detected")

        # Test avoiding collision
        self.player.x = 0
        collision = self.game.check_collision()
        self.assertFalse(collision, "Collision should not be detected")

    def test_falling_blocks_behavior(self):
        # Functionality 3: Test falling blocks behavior
        initial_block_count = len(self.blocks)
        self.game.spawn_block()
        self.assertGreater(len(self.blocks), initial_block_count, "A new block should be spawned")

        # Test block falling speed increase
        block = Block(0, 50)
        self.blocks.append(block)
        initial_y = block.y
        self.game.update_blocks()
        self.assertGreater(block.y, initial_y, "Block should fall down")

    def test_scoring_system(self):
        # Functionality 4: Test scoring system
        initial_score = self.game.score
        self.game.update_score()
        self.assertGreater(self.game.score, initial_score, "Score should increase")

    def test_player_movement_constraints(self):
        # Functionality 5: Test player movement constraints
        initial_y = self.player.y
        self.player.move('up')
        self.assertEqual(self.player.y, initial_y, "Player should not move vertically")

    def test_game_over_condition(self):
        # Functionality 6: Test game over condition
        block = Block(self.player.x, 50)
        block.y = self.player.y
        self.blocks.append(block)
        collision = self.game.check_collision()
        self.assertTrue(collision, "Game should end on collision")

    def test_data_storage(self):
        # Functionality 7: Test data storage (not implemented in codebase)
        self.fail("Data storage functionality is not implemented in the codebase")

if __name__ == '__main__':
    unittest.main()
