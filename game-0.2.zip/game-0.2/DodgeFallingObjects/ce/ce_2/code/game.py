import pygame
from player import Player
from block import Block
import random

class Game:
    def __init__(self):
        self.player = Player(375, 550)
        self.blocks = []
        self.score = 0
        self.speed = 5

    def run(self):
        pygame.init()
        screen = pygame.display.set_mode((800, 600))
        clock = pygame.time.Clock()
        running = True

        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False

            keys = pygame.key.get_pressed()
            if keys[pygame.K_LEFT] and self.player.x > 0:
                self.player.move("left")
            if keys[pygame.K_RIGHT] and self.player.x < 750:
                self.player.move("right")

            self.spawn_block()
            self.update_blocks()
            self.check_collision()

            screen.fill((0, 0, 0))
            self.player.draw(screen)
            for block in self.blocks:
                block.draw(screen)

            pygame.display.flip()
            clock.tick(60)

        pygame.quit()

    def spawn_block(self):
        if random.randint(1, 20) == 1:  # Randomly spawn a block
            size = random.randint(20, 50)
            x = random.randint(0, 800 - size)
            self.blocks.append(Block(x, size))

    def update_blocks(self):
        for block in self.blocks:
            block.fall(self.speed)
            if block.y > 600:
                self.blocks.remove(block)
                self.update_score()

    def check_collision(self) -> bool:
        for block in self.blocks:
            if (self.player.x < block.x + block.size and
                self.player.x + 50 > block.x and
                self.player.y < block.y + block.size and
                self.player.y + 50 > block.y):
                return True
        return False

    def update_score(self):
        self.score += 1