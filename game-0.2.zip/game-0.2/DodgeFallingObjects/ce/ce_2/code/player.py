class Player:
    def __init__(self, x: int, y: int):
        self.x = x
        self.y = y

    def move(self, direction: str):
        if direction == "left":
            self.x -= 5
        elif direction == "right":
            self.x += 5

    def draw(self, surface):
        player_rect = pygame.Rect(self.x, self.y, 50, 50)
        pygame.draw.rect(surface, (0, 255, 0), player_rect)