import random

class Block:
    def __init__(self, x: int, size: int):
        self.x = x
        self.y = 0
        self.size = size

    def fall(self, speed: float):
        self.y += speed

    def draw(self, surface):
        block_rect = pygame.Rect(self.x, self.y, self.size, self.size)
        pygame.draw.rect(surface, (255, 0, 0), block_rect)