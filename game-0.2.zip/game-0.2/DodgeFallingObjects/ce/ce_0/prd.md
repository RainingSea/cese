[OUTPUT]
## general overview of the project
Develop a Dodge the Falling Blocks game. You must design a GUI.

## software functional requirements
1. The game shall allow the player to control a small character at the bottom of the screen using the left and right arrow keys.
2. The game shall implement a mechanism to spawn falling blocks from the top of the screen at random positions.
3. The game shall detect collisions between the player-controlled character and the falling blocks, ending the game upon collision.
4. The falling blocks shall move straight down the screen, with their speed increasing as the player survives longer.
5. The game shall maintain a scoring system that tracks the amount of time the player has survived, updating the score continuously.
6. The player-controlled character shall be restricted to horizontal movement only, with no vertical movement allowed.
7. Upon game over, the final score shall be displayed to the player.
[/OUTPUT]