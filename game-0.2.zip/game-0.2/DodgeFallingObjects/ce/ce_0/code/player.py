class Player:
    def __init__(self, x: int, width: int, height: int):
        self.x = x
        self.width = width
        self.height = height

    def move_left(self):
        self.x -= 5

    def move_right(self):
        self.x += 5

    def get_position(self) -> tuple:
        return (self.x, self.height)