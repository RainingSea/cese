import unittest
import pygame
from game import Game
from player import Player
from block import Block

class TestDodgeFallingObjectsGame(unittest.TestCase):

    def setUp(self):
        # Initialize the game and its components
        self.game = Game()
        self.player = self.game.player

    def test_player_movement(self):
        # Functionalities 1: Test player movement to the left
        initial_x = self.player.x
        self.player.move_left()
        self.assertLess(self.player.x, initial_x, "Player should move left")

        # Test player movement to the right
        initial_x = self.player.x
        self.player.move_right()
        self.assertGreater(self.player.x, initial_x, "Player should move right")

        # Test player does not move beyond the left edge
        self.player.x = 0
        self.player.move_left()
        self.assertEqual(self.player.x, 0, "Player should not move beyond the left edge")

        # Test player does not move beyond the right edge
        self.player.x = self.game.screen_width - self.player.width
        self.player.move_right()
        self.assertEqual(self.player.x, self.game.screen_width - self.player.width, "Player should not move beyond the right edge")

    def test_collision_detection(self):
        # Functionalities 2: Test collision detection
        block = Block(self.player.x, self.player.height, 50, 20)
        self.game.blocks.append(block)
        self.game.check_collision()
        self.assertEqual(self.game.score, 1, "Score should increase after collision")
        self.assertNotIn(block, self.game.blocks, "Block should be removed after collision")

        # Test avoiding collision
        self.player.x = 0
        block = Block(self.game.screen_width, self.player.height, 50, 20)
        self.game.blocks.append(block)
        self.game.check_collision()
        self.assertEqual(self.game.score, 1, "Score should not increase if no collision")

    def test_falling_blocks_behavior(self):
        # Functionalities 3: Test falling blocks behavior
        initial_block_count = len(self.game.blocks)
        self.game.spawn_block()
        self.assertGreaterEqual(len(self.game.blocks), initial_block_count, "Blocks should spawn randomly")

        # Test block falling speed increase
        initial_speed = self.game.speed
        self.game.speed += 1  # Simulate time progression
        self.assertGreater(self.game.speed, initial_speed, "Block speed should increase over time")

    def test_scoring_system(self):
        # Functionalities 4: Test scoring system
        initial_score = self.game.score
        self.game.update_score()
        self.assertGreater(self.game.score, initial_score, "Score should increase over time")

    def test_player_movement_constraints(self):
        # Functionalities 5: Test player cannot move vertically
        initial_y = self.player.height
        self.player.move_left()
        self.assertEqual(self.player.height, initial_y, "Player should not move vertically")

    def test_game_over_condition(self):
        # Functionalities 6: Test game over condition
        block = Block(self.player.x, self.player.height, 50, 20)
        self.game.blocks.append(block)
        self.game.check_collision()
        self.assertEqual(self.game.score, 1, "Game should end after collision")

    def test_data_storage(self):
        # Functionalities 7: Test data storage (not implemented in codebase)
        self.fail("Data storage functionality is not implemented in the codebase")

if __name__ == '__main__':
    unittest.main()
