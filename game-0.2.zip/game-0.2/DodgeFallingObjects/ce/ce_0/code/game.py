import pygame
from player import Player
from block import Block
import random

class Game:
    def __init__(self):
        self.player = Player(300, 50, 50)
        self.blocks = []
        self.score = 0
        self.speed = 5
        self.screen_width = 600
        self.screen_height = 400
        self.window = pygame.display.set_mode((self.screen_width, self.screen_height))
        pygame.font.init()
        self.font = pygame.font.SysFont('Arial', 30)

    def run(self):
        pygame.init()
        clock = pygame.time.Clock()
        running = True

        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False

            keys = pygame.key.get_pressed()
            if keys[pygame.K_LEFT] and self.player.x > 0:
                self.player.move_left()
            if keys[pygame.K_RIGHT] and self.player.x < self.screen_width - self.player.width:
                self.player.move_right()

            self.spawn_block()
            self.update_blocks()
            self.check_collision()
            self.display_score()

            pygame.display.flip()
            clock.tick(30)

        pygame.quit()

    def spawn_block(self):
        if random.randint(1, 20) == 1:  # Randomly spawn a block
            block_width = random.randint(20, 100)
            block_x = random.randint(0, self.screen_width - block_width)
            new_block = Block(block_x, 0, block_width, 20)
            self.blocks.append(new_block)

    def check_collision(self) -> bool:
        for block in self.blocks:
            if (self.player.get_position()[0] < block.get_position()[0] + block.width and
                self.player.get_position()[0] + self.player.width > block.get_position()[0] and
                self.player.get_position()[1] < block.get_position()[1] + block.height and
                self.player.get_position()[1] + self.player.height > block.get_position()[1]):
                self.update_score()
                self.blocks.remove(block)

    def update_score(self):
        self.score += 1

    def display_score(self):
        self.window.fill((0, 0, 0))  # Clear screen
        score_text = self.font.render(f'Score: {self.score}', True, (255, 255, 255))
        self.window.blit(score_text, (10, 10))

        # Draw player
        pygame.draw.rect(self.window, (0, 255, 0), (self.player.get_position()[0], self.player.get_position()[1], self.player.width, self.player.height))

        # Draw blocks
        for block in self.blocks:
            pygame.draw.rect(self.window, (255, 0, 0), (block.get_position()[0], block.get_position()[1], block.width, block.height))