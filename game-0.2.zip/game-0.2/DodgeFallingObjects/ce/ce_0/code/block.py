import random

class Block:
    def __init__(self, x: int, y: int, width: int, height: int):
        self.x = x
        self.y = y
        self.width = width
        self.height = height

    def fall(self, speed: float):
        self.y += speed

    def get_position(self) -> tuple:
        return (self.x, self.y)