import pygame
import random

class Player:
    def __init__(self, x_position: int, width: int, height: int):
        self.x_position = x_position
        self.width = width
        self.height = height

    def move(self, direction: str) -> None:
        if direction == 'left':
            self.x_position -= 10
        elif direction == 'right':
            self.x_position += 10

    def get_position(self) -> tuple:
        return (self.x_position, 480 - self.height)  # Assuming the player is at the bottom of the screen


class Block:
    def __init__(self, x_position: int, width: int, height: int):
        self.x_position = x_position
        self.y_position = 0
        self.width = width
        self.height = height

    def fall(self, speed: float) -> None:
        self.y_position += speed

    def get_position(self) -> tuple:
        return (self.x_position, self.y_position)


class Game:
    def __init__(self):
        self.player = Player(250, 50, 50)
        self.blocks = []
        self.score = 0
        self.speed = 5

    def run(self) -> None:
        pygame.init()
        screen = pygame.display.set_mode((500, 500))
        pygame.display.set_caption("Dodge the Falling Blocks")
        clock = pygame.time.Clock()
        running = True

        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False

            keys = pygame.key.get_pressed()
            if keys[pygame.K_LEFT] and self.player.x_position > 0:
                self.player.move('left')
            if keys[pygame.K_RIGHT] and self.player.x_position < 450:
                self.player.move('right')

            self.spawn_block()
            self.update_blocks()
            self.check_collision()
            self.update_score()

            screen.fill((0, 0, 0))
            self.display_score(screen)
            self.draw_player(screen)
            self.draw_blocks(screen)
            pygame.display.flip()
            clock.tick(60)

        pygame.quit()

    def spawn_block(self) -> None:
        if random.randint(1, 20) == 1:  # Randomly spawn a block
            block_width = random.randint(20, 100)
            block_x = random.randint(0, 500 - block_width)
            self.blocks.append(Block(block_x, block_width, 20))

    def update_blocks(self) -> None:
        for block in self.blocks:
            block.fall(self.speed)

        self.blocks = [block for block in self.blocks if block.y_position < 500]

    def check_collision(self) -> bool:
        player_pos = self.player.get_position()
        for block in self.blocks:
            block_pos = block.get_position()
            if (player_pos[0] < block_pos[0] + block.width and
                player_pos[0] + self.player.width > block_pos[0] and
                player_pos[1] < block_pos[1] + block.height and
                player_pos[1] + self.player.height > block_pos[1]):
                return True
        return False

    def update_score(self) -> None:
        self.score += 1  # Increment score over time

    def display_score(self, screen) -> None:
        font = pygame.font.Font(None, 36)
        score_text = font.render(f'Score: {self.score}', True, (255, 255, 255))
        screen.blit(score_text, (10, 10))

    def draw_player(self, screen) -> None:
        pygame.draw.rect(screen, (0, 255, 0), (*self.player.get_position(), self.player.width, self.player.height))

    def draw_blocks(self, screen) -> None:
        for block in self.blocks:
            pygame.draw.rect(screen, (255, 0, 0), (*block.get_position(), block.width, block.height))