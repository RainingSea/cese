import unittest
import pygame
from game import Game, Player, Block

class TestDodgeFallingObjectsGame(unittest.TestCase):

    def setUp(self):
        # Initialize the game and its components
        self.game = Game()
        self.player = self.game.player

    def test_player_movement(self):
        # Functionality 1: Player Movement
        initial_x = self.player.x_position

        # Test moving left
        self.player.move('left')
        self.assertLess(self.player.x_position, initial_x, "Player should move left")

        # Test moving right
        initial_x = self.player.x_position
        self.player.move('right')
        self.assertGreater(self.player.x_position, initial_x, "Player should move right")

        # Test boundary on the left
        self.player.x_position = 0
        self.player.move('left')
        self.assertEqual(self.player.x_position, 0, "Player should not move beyond the left edge")

        # Test boundary on the right
        self.player.x_position = 450
        self.player.move('right')
        self.assertEqual(self.player.x_position, 450, "Player should not move beyond the right edge")

    def test_collision_detection(self):
        # Functionality 2: Collision Detection
        block = Block(self.player.x_position, 50, 50)
        self.game.blocks.append(block)
        collision = self.game.check_collision()
        self.assertTrue(collision, "Collision should be detected when block overlaps player")

        # Move player to avoid collision
        self.player.x_position = 0
        collision = self.game.check_collision()
        self.assertFalse(collision, "Player should avoid collision by moving away")

    def test_falling_blocks_behavior(self):
        # Functionality 3: Falling Blocks Behavior
        initial_block_count = len(self.game.blocks)
        self.game.spawn_block()
        self.assertGreaterEqual(len(self.game.blocks), initial_block_count, "Blocks should spawn randomly")

        # Simulate block falling
        block = Block(0, 50, 50)
        initial_y = block.y_position
        block.fall(self.game.speed)
        self.assertGreater(block.y_position, initial_y, "Block should fall downwards")

    def test_scoring_system(self):
        # Functionality 4: Scoring System
        initial_score = self.game.score
        self.game.update_score()
        self.assertGreater(self.game.score, initial_score, "Score should increase over time")

    def test_player_movement_constraints(self):
        # Functionality 5: Player Movement Constraints
        initial_y = self.player.get_position()[1]
        self.player.move('left')
        self.assertEqual(self.player.get_position()[1], initial_y, "Player should not move vertically")

    def test_game_over_condition(self):
        # Functionality 6: Game Over Condition
        block = Block(self.player.x_position, 50, 50)
        self.game.blocks.append(block)
        collision = self.game.check_collision()
        self.assertTrue(collision, "Game should end when player collides with a block")

    def test_data_storage(self):
        # Functionality 7: Data Storage
        self.fail("Data storage functionality is not implemented in the codebase")

if __name__ == '__main__':
    unittest.main()
