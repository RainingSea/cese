import pygame
import random

class Block:
    def __init__(self, color, position):
        self.color = color
        self.position = position

    def draw(self, surface):
        pygame.draw.rect(surface, self.color, (*self.position, 50, 50))

    def is_connected(self, other):
        return self.color == other.color

class Score:
    def __init__(self):
        self.points = 0

    def add_points(self, points):
        self.points += points

    def get_score(self):
        return self.points

class Grid:
    def __init__(self, size):
        self.blocks = []
        self.initialize_grid(size)

    def initialize_grid(self, size):
        colors = [(255, 0, 0), (0, 255, 0), (0, 0, 255), (255, 255, 0)]
        for i in range(size):
            row = []
            for j in range(size):
                color = random.choice(colors)
                block = Block(color, (j * 50, i * 50))
                row.append(block)
            self.blocks.append(row)

    def draw_grid(self, surface):
        for row in self.blocks:
            for block in row:
                block.draw(surface)

    def check_connection(self, start, end):
        start_block = self.blocks[start[1]][start[0]]
        end_block = self.blocks[end[1]][end[0]]
        return start_block.is_connected(end_block)

class Game:
    def __init__(self):
        self.grid = Grid(8)
        self.score = Score()
        self.screen = pygame.display.set_mode((400, 400))
        pygame.display.set_caption("Color Link Puzzle")

    def start_game(self):
        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False

            self.screen.fill((255, 255, 255))
            self.grid.draw_grid(self.screen)
            pygame.display.flip()

    def clear_blocks(self, blocks):
        for block in blocks:
            x, y = block.position
            self.grid.blocks[y][x] = Block((255, 255, 255), (x * 50, y * 50))  # Clear block

    def update_score(self, points):
        self.score.add_points(points)