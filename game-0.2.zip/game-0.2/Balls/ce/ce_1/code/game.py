import pygame
import random

class PlayerBall:
    def __init__(self, size: int, position_x: int, position_y: int):
        self.size = size
        self.position_x = position_x
        self.position_y = position_y

    def move(self, direction: str) -> None:
        if direction == 'UP':
            self.position_y -= 5
        elif direction == 'DOWN':
            self.position_y += 5
        elif direction == 'LEFT':
            self.position_x -= 5
        elif direction == 'RIGHT':
            self.position_x += 5

    def grow(self) -> None:
        self.size += 1

class EnemyBall:
    def __init__(self, size: int, position_x: int, position_y: int):
        self.size = size
        self.position_x = position_x
        self.position_y = position_y

    def move(self) -> None:
        # Enemies move randomly for simplicity
        self.position_x += random.choice([-1, 1])
        self.position_y += random.choice([-1, 1])

class Game:
    def __init__(self):
        self.player_ball = PlayerBall(size=10, position_x=400, position_y=300)
        self.enemy_balls = []
        self.score = 0

    def run(self) -> None:
        pygame.init()
        screen = pygame.display.set_mode((800, 600))
        pygame.display.set_caption("Battle of Balls")
        clock = pygame.time.Clock()
        running = True

        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False

            keys = pygame.key.get_pressed()
            if keys[pygame.K_UP]:
                self.player_ball.move('UP')
            if keys[pygame.K_DOWN]:
                self.player_ball.move('DOWN')
            if keys[pygame.K_LEFT]:
                self.player_ball.move('LEFT')
            if keys[pygame.K_RIGHT]:
                self.player_ball.move('RIGHT')

            self.update()
            self.check_collisions()
            self.spawn_enemy_ball()

            screen.fill((255, 255, 255))
            pygame.draw.circle(screen, (0, 0, 255), (self.player_ball.position_x, self.player_ball.position_y), self.player_ball.size)
            for enemy in self.enemy_balls:
                pygame.draw.circle(screen, (255, 0, 0), (enemy.position_x, enemy.position_y), enemy.size)

            pygame.display.flip()
            clock.tick(60)

        self.save_data()
        pygame.quit()

    def update(self) -> None:
        for enemy in self.enemy_balls:
            enemy.move()

    def check_collisions(self) -> None:
        for enemy in self.enemy_balls:
            if (self.player_ball.position_x - enemy.position_x) ** 2 + (self.player_ball.position_y - enemy.position_y) ** 2 < (self.player_ball.size + enemy.size) ** 2:
                self.player_ball.grow()
                self.score += 1
                self.enemy_balls.remove(enemy)

    def spawn_enemy_ball(self) -> None:
        if len(self.enemy_balls) < 5:  # Limit the number of enemy balls
            size = random.randint(5, 15)
            position_x = random.randint(0, 800)
            position_y = random.randint(0, 600)
            self.enemy_balls.append(EnemyBall(size, position_x, position_y))

    def save_data(self) -> None:
        with open('game_data.txt', 'w') as file:
            file.write(f'score|{self.score}\n')
            file.write(f'enemy_balls_consumed|{self.score}\n')