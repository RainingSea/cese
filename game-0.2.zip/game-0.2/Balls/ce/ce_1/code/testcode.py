import unittest
import pygame
from game import Game, PlayerBall, EnemyBall

class TestBattleOfBallsGame(unittest.TestCase):

    def setUp(self):
        # Initialize the game
        self.game = Game()

    def test_player_ball_movement(self):
        # Functionalities 1: Test player's ball movement upwards
        initial_y = self.game.player_ball.position_y
        self.game.player_ball.move('UP')
        self.assertLess(self.game.player_ball.position_y, initial_y, "Player's ball should move up")

    def test_enemy_ball_collision(self):
        # Functionalities 2: Test collision with a smaller enemy ball
        self.game.player_ball.size = 10
        enemy_ball = EnemyBall(size=5, position_x=self.game.player_ball.position_x, position_y=self.game.player_ball.position_y)
        self.game.enemy_balls.append(enemy_ball)
        self.game.check_collisions()
        self.assertEqual(self.game.player_ball.size, 11, "Player's ball should grow in size after collision")
        self.assertNotIn(enemy_ball, self.game.enemy_balls, "Enemy ball should be removed after collision")

    def test_player_ball_consumption(self):
        # Functionalities 3: Test scenario where player's ball is surrounded by larger enemy balls
        self.game.player_ball.size = 5
        enemy_ball = EnemyBall(size=10, position_x=self.game.player_ball.position_x, position_y=self.game.player_ball.position_y)
        self.game.enemy_balls.append(enemy_ball)
        # Simulate game end condition (not implemented in codebase)
        self.fail("Game end condition when player's ball is consumed is not implemented in the codebase")

    def test_initialize_game_entities(self):
        # Functionalities 4: Test game initialization
        self.assertEqual(len(self.game.enemy_balls), 0, "Initially, there should be no enemy balls")
        self.assertEqual(self.game.player_ball.size, 10, "Player's ball should be initialized with size 10")

    def test_enemy_ball_spawning(self):
        # Functionalities 5: Test enemy ball spawning
        initial_enemy_count = len(self.game.enemy_balls)
        self.game.spawn_enemy_ball()
        self.assertEqual(len(self.game.enemy_balls), initial_enemy_count + 1, "A new enemy ball should be spawned")

    def test_data_storage_functionality(self):
        # Functionalities 6: Test saving game state to a file
        self.game.save_data()
        with open('game_data.txt', 'r') as file:
            data = file.read()
        self.assertIn('score|0', data, "Game state should be saved with score 0")
        self.assertIn('enemy_balls_consumed|0', data, "Game state should be saved with enemy balls consumed 0")

if __name__ == '__main__':
    unittest.main()
