import pygame
import random

class PlayerBall:
    def __init__(self, size: float, position: tuple):
        self.size = size
        self.position = position

    def grow(self, amount: float) -> None:
        self.size += amount

    def move(self, direction: tuple) -> None:
        self.position = (self.position[0] + direction[0], self.position[1] + direction[1])

class EnemyBall:
    def __init__(self, size: float, position: tuple):
        self.size = size
        self.position = position

    def move(self) -> None:
        # Move the enemy ball randomly for simplicity
        self.position = (self.position[0] + random.choice([-1, 1]), self.position[1] + random.choice([-1, 1]))

class Game:
    def __init__(self):
        self.player_ball = PlayerBall(size=20.0, position=(400, 300))
        self.enemy_balls = [EnemyBall(size=10.0, position=(random.randint(0, 800), random.randint(0, 600))) for _ in range(5)]

    def run(self) -> None:
        pygame.init()
        screen = pygame.display.set_mode((800, 600))
        clock = pygame.time.Clock()
        running = True

        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False

            keys = pygame.key.get_pressed()
            direction = (0, 0)
            if keys[pygame.K_LEFT]:
                direction = (-5, 0)
            if keys[pygame.K_RIGHT]:
                direction = (5, 0)
            if keys[pygame.K_UP]:
                direction = (0, -5)
            if keys[pygame.K_DOWN]:
                direction = (0, 5)

            self.player_ball.move(direction)
            self.update()
            self.check_collisions()

            screen.fill((0, 0, 0))
            pygame.draw.circle(screen, (0, 255, 0), (int(self.player_ball.position[0]), int(self.player_ball.position[1])), int(self.player_ball.size))
            for enemy in self.enemy_balls:
                pygame.draw.circle(screen, (255, 0, 0), (int(enemy.position[0]), int(enemy.position[1])), int(enemy.size))
            pygame.display.flip()
            clock.tick(60)

        pygame.quit()

    def update(self) -> None:
        for enemy in self.enemy_balls:
            enemy.move()

    def check_collisions(self) -> None:
        for enemy in self.enemy_balls:
            distance = ((self.player_ball.position[0] - enemy.position[0]) ** 2 + (self.player_ball.position[1] - enemy.position[1]) ** 2) ** 0.5
            if distance < (self.player_ball.size + enemy.size):
                self.player_ball.grow(5.0)
                self.enemy_balls.remove(enemy)

    def load_game_data(self) -> None:
        try:
            with open('game_data.txt', 'r') as file:
                lines = file.readlines()
                self.player_ball.size = float(lines[0].strip())
                self.player_ball.position = tuple(map(float, lines[1].strip().split(',')))
                self.enemy_balls = []
                for line in lines[2:]:
                    size, position = line.strip().split('|')
                    enemy_size = float(size)
                    enemy_position = tuple(map(float, position.split(',')))
                    self.enemy_balls.append(EnemyBall(enemy_size, enemy_position))
        except FileNotFoundError:
            pass

    def save_game_data(self) -> None:
        with open('game_data.txt', 'w') as file:
            file.write(f"{self.player_ball.size}\n")
            file.write(f"{self.player_ball.position[0]},{self.player_ball.position[1]}\n")
            for enemy in self.enemy_balls:
                file.write(f"{enemy.size}|{enemy.position[0]},{enemy.position[1]}\n")