from game import Game

if __name__ == "__main__":
    game = Game()
    game.load_game_data()
    game.run()
    game.save_game_data()