import unittest
import pygame
from game import Game, PlayerBall, EnemyBall

class TestBallGame(unittest.TestCase):

    def setUp(self):
        # Initialize the game and its components
        self.game = Game()

    def test_player_ball_movement(self):
        # Functionalities 1: Simulate pressing the up arrow key to move the player's ball
        initial_position = self.game.player_ball.position
        self.game.player_ball.move((0, -5))  # Simulate up arrow key
        self.assertEqual(self.game.player_ball.position, (initial_position[0], initial_position[1] - 5), 
                         "Player's ball should move upward by 5 units")

    def test_enemy_ball_collision(self):
        # Functionalities 2: Position the player's ball to collide with a smaller enemy ball
        self.game.player_ball.position = (100, 150)
        self.game.check_collisions()
        self.assertEqual(self.game.player_ball.size, 25.0, "Player's ball should grow in size after collision")
        self.assertEqual(len(self.game.enemy_balls), 4, "Enemy ball should be removed after collision")

    def test_player_ball_consumption(self):
        # Functionalities 3: Simulate a scenario where the player's ball is surrounded by larger enemy balls
        self.game.player_ball.size = 5.0  # Make player ball smaller
        self.game.enemy_balls = [EnemyBall(size=30.0, position=(400, 300))]  # Larger enemy ball
        self.game.check_collisions()
        # Since the game does not have an explicit end condition, we check if player ball size remains unchanged
        self.assertEqual(self.game.player_ball.size, 5.0, "Player's ball should not grow when consumed by larger enemy")

    def test_initialize_game_entities(self):
        # Functionalities 4: Trigger the game initialization function
        self.assertEqual(len(self.game.enemy_balls), 5, "There should be five enemy balls initialized")
        self.assertGreater(self.game.player_ball.size, self.game.enemy_balls[0].size, 
                           "Player's ball should be larger than enemy balls")

    def test_enemy_ball_spawning(self):
        # Functionalities 5: Call the function responsible for spawning enemy balls
        # Note: The current codebase does not have a function for spawning new enemy balls
        self.fail("Enemy ball spawning functionality is not implemented in the codebase")

    def test_data_storage_functionality(self):
        # Functionalities 6: Save the game state to a local text file
        self.game.save_game_data()
        with open('game_data.txt', 'r') as file:
            lines = file.readlines()
            self.assertEqual(float(lines[0].strip()), self.game.player_ball.size, "Player's ball size should be saved correctly")
            self.assertEqual(tuple(map(float, lines[1].strip().split(','))), self.game.player_ball.position, "Player's ball position should be saved correctly")
            self.assertEqual(len(lines[2:]), len(self.game.enemy_balls), "All enemy balls should be saved correctly")

if __name__ == '__main__':
    unittest.main()
