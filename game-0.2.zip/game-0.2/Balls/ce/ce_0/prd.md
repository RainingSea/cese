[OUTPUT]
## general overview of the project
Develop a Battle of Balls Game

## software functional requirements
1. The player's ball must remain at the center of the screen.
2. Other balls must move relative to the player's ball.
3. The player must be able to move their ball using the up, down, left, and right arrow keys.
4. When the player's ball collides with a smaller enemy ball:
   - The player's ball must grow in size.
   - The smaller enemy ball must be consumed and removed from the game.
5. The game must end if the player's ball is consumed by another ball.
6. The game must initialize the player's ball and four enemy balls at the start.
7. The player's ball must be initially larger than the enemy balls.
8. Enemy balls must spawn on the map and must be smaller than the player's ball.
[/OUTPUT]