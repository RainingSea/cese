import pygame
from game import Game

def main():
    game = Game()
    game.start_game()

    while game.running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                game.running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    game.player_ball.move('UP')
                elif event.key == pygame.K_DOWN:
                    game.player_ball.move('DOWN')
                elif event.key == pygame.K_LEFT:
                    game.player_ball.move('LEFT')
                elif event.key == pygame.K_RIGHT:
                    game.player_ball.move('RIGHT')

        game.update_game()
        game.check_collisions()

    pygame.quit()

if __name__ == "__main__":
    main()