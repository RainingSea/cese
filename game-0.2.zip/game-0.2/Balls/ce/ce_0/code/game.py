import pygame
import random

class PlayerBall:
    def __init__(self, size, position_x, position_y):
        self.size = size
        self.position_x = position_x
        self.position_y = position_y

    def move(self, direction: str):
        if direction == 'UP':
            self.position_y -= 5
        elif direction == 'DOWN':
            self.position_y += 5
        elif direction == 'LEFT':
            self.position_x -= 5
        elif direction == 'RIGHT':
            self.position_x += 5

    def grow(self, size_increase: int):
        self.size += size_increase

class EnemyBall:
    def __init__(self, size, position_x, position_y):
        self.size = size
        self.position_x = position_x
        self.position_y = position_y

    def move(self):
        # Random movement for enemy balls
        self.position_x += random.choice([-1, 1]) * random.randint(1, 3)
        self.position_y += random.choice([-1, 1]) * random.randint(1, 3)

class Game:
    def __init__(self):
        self.player_ball = PlayerBall(size=20, position_x=400, position_y=300)
        self.enemy_balls = [EnemyBall(size=random.randint(10, 30), 
                                       position_x=random.randint(0, 800), 
                                       position_y=random.randint(0, 600)) for _ in range(5)]
        self.score = 0

    def start_game(self):
        pygame.init()
        self.screen = pygame.display.set_mode((800, 600))
        pygame.display.set_caption("Battle of Balls")
        self.clock = pygame.time.Clock()
        self.running = True

    def update_game(self):
        self.screen.fill((255, 255, 255))
        for enemy in self.enemy_balls:
            enemy.move()
            pygame.draw.circle(self.screen, (255, 0, 0), (enemy.position_x, enemy.position_y), enemy.size)
        pygame.draw.circle(self.screen, (0, 0, 255), (self.player_ball.position_x, self.player_ball.position_y), self.player_ball.size)
        pygame.display.flip()
        self.clock.tick(60)

    def check_collisions(self):
        for enemy in self.enemy_balls:
            if (self.player_ball.position_x - enemy.position_x) ** 2 + (self.player_ball.position_y - enemy.position_y) ** 2 < (self.player_ball.size + enemy.size) ** 2:
                self.end_game()

    def end_game(self):
        self.running = False
        with open('game_state.txt', 'w') as f:
            f.write(f"Score: {self.score}\nSize: {self.player_ball.size}\n")