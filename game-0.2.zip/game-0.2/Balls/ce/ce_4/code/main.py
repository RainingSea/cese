import pygame
from game import Game

def main():
    game = Game()
    game.start_game()

    while game.running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                game.end_game()

        game.update()

if __name__ == "__main__":
    main()