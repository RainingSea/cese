import pygame
from player_ball import PlayerBall
from enemy_ball import EnemyBall

class Game:
    def __init__(self):
        self.player_ball = PlayerBall(size=10.0)
        self.enemy_balls = [EnemyBall(size=random.uniform(5, 15), position=(random.randint(0, 800), random.randint(0, 600))) for _ in range(5)]

    def start_game(self) -> None:
        pygame.init()
        self.screen = pygame.display.set_mode((800, 600))
        pygame.display.set_caption("Battle of Balls")
        self.running = True

    def update(self) -> None:
        # Update game state and render
        pass

    def check_collisions(self) -> None:
        # Check for collisions between player ball and enemy balls
        pass

    def end_game(self) -> None:
        self.running = False
        pygame.quit()