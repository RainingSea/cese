class PlayerBall:
    def __init__(self, size: float):
        self.size = size

    def move(self, direction: str) -> None:
        # Logic to move the player ball based on direction
        pass

    def grow(self, amount: float) -> None:
        self.size += amount