import random

class EnemyBall:
    def __init__(self, size: float, position: tuple):
        self.size = size
        self.position = position

    def move(self) -> None:
        # Logic to move enemy balls randomly
        self.position = (random.randint(0, 800), random.randint(0, 600))  # Example screen size