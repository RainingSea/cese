import pygame
from game import Game

def main() -> None:
    game = Game()
    game.initialize()
    game.load_game_data()

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        keys = pygame.key.get_pressed()
        if keys[pygame.K_UP]:
            game.player_ball.move('UP')
        if keys[pygame.K_DOWN]:
            game.player_ball.move('DOWN')
        if keys[pygame.K_LEFT]:
            game.player_ball.move('LEFT')
        if keys[pygame.K_RIGHT]:
            game.player_ball.move('RIGHT')

        game.check_collision()
        game.update()

    game.save_game_data()
    game.end_game()

if __name__ == "__main__":
    main()