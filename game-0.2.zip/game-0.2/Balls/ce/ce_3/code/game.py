import pygame
import random

class PlayerBall:
    def __init__(self, size: float, position: tuple):
        self.size = size
        self.position = position

    def move(self, direction: str) -> None:
        if direction == 'UP':
            self.position = (self.position[0], self.position[1] - 5)
        elif direction == 'DOWN':
            self.position = (self.position[0], self.position[1] + 5)
        elif direction == 'LEFT':
            self.position = (self.position[0] - 5, self.position[1])
        elif direction == 'RIGHT':
            self.position = (self.position[0] + 5, self.position[1])

    def grow(self) -> None:
        self.size += 1

class EnemyBall:
    def __init__(self, size: float, position: tuple):
        self.size = size
        self.position = position

    def move(self) -> None:
        # Random movement logic for enemy balls
        self.position = (self.position[0] + random.choice([-1, 1]), 
                         self.position[1] + random.choice([-1, 1]))

class Game:
    def __init__(self):
        self.player_ball = PlayerBall(size=5, position=(400, 300))
        self.enemy_balls = [EnemyBall(size=random.uniform(1, 5), 
                                       position=(random.randint(0, 800), 
                                                 random.randint(0, 600))) for _ in range(10)]

    def initialize(self) -> None:
        pygame.init()
        self.screen = pygame.display.set_mode((800, 600))
        pygame.display.set_caption("Battle of Balls")

    def update(self) -> None:
        self.screen.fill((255, 255, 255))
        pygame.draw.circle(self.screen, (0, 0, 255), 
                           (int(self.player_ball.position[0]), 
                            int(self.player_ball.position[1])), 
                           int(self.player_ball.size))
        for enemy in self.enemy_balls:
            pygame.draw.circle(self.screen, (255, 0, 0), 
                               (int(enemy.position[0]), 
                                int(enemy.position[1])), 
                               int(enemy.size))
        pygame.display.flip()

    def check_collision(self) -> None:
        for enemy in self.enemy_balls:
            distance = ((self.player_ball.position[0] - enemy.position[0]) ** 2 + 
                         (self.player_ball.position[1] - enemy.position[1]) ** 2) ** 0.5
            if distance < (self.player_ball.size + enemy.size):
                self.player_ball.grow()
                self.enemy_balls.remove(enemy)

    def end_game(self) -> None:
        pygame.quit()

    def load_game_data(self) -> None:
        try:
            with open('game_data.txt', 'r') as file:
                lines = file.readlines()
                self.player_ball.size = float(lines[0].strip())
                self.player_ball.position = tuple(map(float, lines[1].strip().split(',')))
                self.enemy_balls = []
                for line in lines[2:]:
                    size, pos_x, pos_y = map(float, line.strip().split(','))
                    self.enemy_balls.append(EnemyBall(size, (pos_x, pos_y)))
        except FileNotFoundError:
            print("No game data found, starting a new game.")

    def save_game_data(self) -> None:
        with open('game_data.txt', 'w') as file:
            file.write(f"{self.player_ball.size}\n")
            file.write(f"{self.player_ball.position[0]},{self.player_ball.position[1]}\n")
            for enemy in self.enemy_balls:
                file.write(f"{enemy.size},{enemy.position[0]},{enemy.position[1]}\n")