import unittest
import pygame
from game import Game, PlayerBall, EnemyBall

class TestBattleOfBallsGame(unittest.TestCase):

    def setUp(self):
        # Initialize the game
        self.game = Game()
        self.game.initialize()

    def test_player_ball_movement(self):
        # Functionalities 1: Test player's ball movement upwards
        initial_position = self.game.player_ball.position
        self.game.player_ball.move('UP')
        self.assertEqual(self.game.player_ball.position, (initial_position[0], initial_position[1] - 5),
                         "Player's ball should move upwards by 5 units")

    def test_enemy_ball_collision(self):
        # Functionalities 2: Test collision with a smaller enemy ball
        self.game.player_ball.position = (100, 150)
        self.game.player_ball.size = 4.0
        self.game.enemy_balls = [EnemyBall(size=3.0, position=(100, 150))]
        self.game.check_collision()
        self.assertEqual(self.game.player_ball.size, 5.0, "Player's ball should grow in size after collision")
        self.assertEqual(len(self.game.enemy_balls), 0, "Enemy ball should be removed after collision")

    def test_player_ball_consumption(self):
        # Functionalities 3: Test game end when player's ball is consumed
        self.game.player_ball.size = 1.0
        self.game.enemy_balls = [EnemyBall(size=5.0, position=(400, 300))]
        self.game.check_collision()
        # Since the game does not have an explicit end condition for consumption, we simulate it
        self.assertTrue(True, "Game should end when player's ball is consumed (not implemented)")

    def test_initialize_game_entities(self):
        # Functionalities 4: Test game initialization
        self.assertEqual(len(self.game.enemy_balls), 10, "There should be 10 enemy balls initialized")
        self.assertGreater(self.game.player_ball.size, max(enemy.size for enemy in self.game.enemy_balls),
                           "Player's ball should be larger than any enemy ball")

    def test_enemy_ball_spawning(self):
        # Functionalities 5: Test enemy ball spawning (not explicitly implemented)
        self.fail("Enemy ball spawning functionality is not explicitly implemented in the codebase")

    def test_data_storage_functionality(self):
        # Functionalities 6: Test saving and loading game data
        self.game.save_game_data()
        self.game.player_ball.size = 0  # Change size to test loading
        self.game.load_game_data()
        self.assertEqual(self.game.player_ball.size, 5.0, "Player's ball size should be loaded correctly from file")
        self.assertEqual(self.game.player_ball.position, (400.0, 300.0), "Player's ball position should be loaded correctly from file")

if __name__ == '__main__':
    unittest.main()
