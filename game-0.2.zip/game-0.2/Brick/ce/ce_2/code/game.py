import pygame
from paddle import Paddle
from ball import Ball
from brick import Brick

class Game:
    def __init__(self):
        self.paddle = Paddle(300, 100)
        self.ball = Ball(400, 300)
        self.bricks = self.load_bricks()

    def run(self):
        pygame.init()
        screen = pygame.display.set_mode((800, 600))
        clock = pygame.time.Clock()
        running = True

        while running:
            self.handle_input()
            self.update()
            self.draw(screen)
            pygame.display.flip()
            clock.tick(60)

        pygame.quit()

    def handle_input(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    self.paddle.move('left')
                if event.key == pygame.K_RIGHT:
                    self.paddle.move('right')

    def update(self):
        self.ball.update()
        # Check for collisions with paddle and bricks here

    def draw(self, surface):
        surface.fill((0, 0, 0))  # Clear the screen
        self.paddle.draw(surface)
        self.ball.draw(surface)
        for brick in self.bricks:
            brick.draw(surface)

    def load_bricks(self):
        bricks = []
        with open('game_data.txt', 'r') as file:
            for line in file:
                x, y, lives = map(int, line.strip().split('|'))
                bricks.append(Brick(x, y, lives))
        return bricks

    def save_bricks(self):
        with open('game_data.txt', 'w') as file:
            for brick in self.bricks:
                file.write(f"{brick.x}|{brick.y}|{brick.lives}\n")