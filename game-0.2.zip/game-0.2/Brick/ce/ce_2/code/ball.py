import pygame

class Ball:
    def __init__(self, x: int, y: int):
        self.x = x
        self.y = y
        self.dx = 5  # Change in x
        self.dy = -5  # Change in y

    def update(self):
        self.x += self.dx
        self.y += self.dy

    def draw(self, surface):
        pygame.draw.circle(surface, (0, 255, 0), (self.x, self.y), 10)