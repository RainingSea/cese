import pygame
import os

class Paddle:
    def __init__(self, x: int, width: int):
        self.x = x
        self.width = width

    def move(self, direction: str):
        if direction == "left":
            self.x -= 5
        elif direction == "right":
            self.x += 5

    def draw(self, surface):
        pygame.draw.rect(surface, (255, 255, 255), (self.x, surface.get_height() - 20, self.width, 10))


class Ball:
    def __init__(self, x: int, y: int):
        self.x = x
        self.y = y
        self.velocity_x = 3
        self.velocity_y = -3

    def move(self):
        self.x += self.velocity_x
        self.y += self.velocity_y

    def draw(self, surface):
        pygame.draw.circle(surface, (255, 255, 255), (self.x, self.y), 5)


class Brick:
    def __init__(self, id: int, life: int):
        self.id = id
        self.life = life

    def hit(self):
        self.life -= 1

    def draw(self, surface):
        color = (255, 0, 0) if self.life > 0 else (0, 0, 0)
        pygame.draw.rect(surface, color, (self.id * 60, 30, 50, 20))


class Game:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((800, 600))
        self.paddle = Paddle(375, 100)
        self.ball = Ball(400, 300)
        self.bricks = [Brick(i, 1) for i in range(10)]
        self.lives = 3

    def run(self):
        clock = pygame.time.Clock()
        running = True
        while running:
            self.handle_input()
            self.update()
            self.draw()
            clock.tick(60)

        pygame.quit()

    def handle_input(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()

        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            self.paddle.move("left")
        if keys[pygame.K_RIGHT]:
            self.paddle.move("right")

    def update(self):
        self.ball.move()
        if self.ball.y >= 580:
            self.lives -= 1
            self.ball = Ball(400, 300)  # Reset ball position

        for brick in self.bricks:
            if brick.life > 0 and self.ball.x in range(brick.id * 60, brick.id * 60 + 50) and self.ball.y in range(30, 50):
                brick.hit()
                self.ball.velocity_y *= -1

    def draw(self):
        self.screen.fill((0, 0, 0))
        self.paddle.draw(self.screen)
        self.ball.draw(self.screen)
        for brick in self.bricks:
            brick.draw(self.screen)
        pygame.display.flip()

    def load_game_state(self):
        if os.path.exists('game_state.txt'):
            with open('game_state.txt', 'r') as file:
                for line in file:
                    brick_id, life_count = map(int, line.strip().split(':'))
                    self.bricks[brick_id].life = life_count

    def save_game_state(self):
        with open('game_state.txt', 'w') as file:
            for brick in self.bricks:
                file.write(f"{brick.id}:{brick.life}\n")