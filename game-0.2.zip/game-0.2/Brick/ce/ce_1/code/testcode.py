import unittest
import pygame
from game import Game, Paddle, Ball, Brick

class TestBrickBreakerGame(unittest.TestCase):

    def setUp(self):
        # Initialize the game and its components
        self.game = Game()
        self.paddle = self.game.paddle
        self.ball = self.game.ball
        self.bricks = self.game.bricks

    def test_control_paddle_movement(self):
        # Functionalities 1: Test paddle movement to the left
        initial_x = self.paddle.x
        self.paddle.move('left')
        self.assertLess(self.paddle.x, initial_x, "Paddle should move left")

        # Test paddle movement to the right
        initial_x = self.paddle.x
        self.paddle.move('right')
        self.assertGreater(self.paddle.x, initial_x, "Paddle should move right")

    def test_ball_bounce_mechanics(self):
        # Functionalities 2: Simulate ball hitting the paddle
        self.ball.x = self.paddle.x + self.paddle.width // 2
        self.ball.y = self.game.screen.get_height() - 25  # Just above the paddle
        initial_velocity_y = self.ball.velocity_y
        self.game.update()
        self.assertEqual(self.ball.velocity_y, -initial_velocity_y, "Ball should bounce off the paddle")

    def test_brick_splitting_logic(self):
        # Functionalities 3: Test brick splitting logic (not implemented in codebase)
        self.fail("Brick splitting logic is not implemented in the codebase")

    def test_brick_disappearance(self):
        # Functionalities 4: Hit a brick until it disappears
        brick = self.bricks[0]
        initial_life = brick.life
        for _ in range(initial_life):
            brick.hit()
        self.assertEqual(brick.life, 0, "Brick should disappear when life reaches 0")

    def test_game_start_mechanism(self):
        # Functionalities 5: Simulate starting the game by moving the paddle
        self.game.handle_input()
        # Since the game loop is continuous, we assume the game starts with the first input
        self.assertTrue(self.game.lives > 0, "Game should be running after starting")

    def test_ball_movement(self):
        # Functionalities 6: Test ball movement upwards
        initial_y = self.ball.y
        self.ball.move()
        self.assertNotEqual(self.ball.y, initial_y, "Ball should move")

    def test_save_game_state(self):
        # Functionalities 7: Test saving game state
        self.game.save_game_state()
        self.assertTrue(os.path.exists('game_state.txt'), "Game state should be saved to a file")

    def test_load_game_state(self):
        # Functionalities 8: Test loading game state
        self.game.save_game_state()  # Ensure there's a state to load
        self.game.load_game_state()
        # Check if the game state is loaded correctly
        with open('game_state.txt', 'r') as file:
            for line in file:
                brick_id, life_count = map(int, line.strip().split(':'))
                self.assertEqual(self.bricks[brick_id].life, life_count, "Game state should be loaded correctly")

    def test_end_game_condition(self):
        # Functionalities 9: Simulate the ball falling below the paddle
        self.ball.y = self.game.screen.get_height() + 1
        initial_lives = self.game.lives
        self.game.update()
        self.assertEqual(self.game.lives, initial_lives - 1, "Lives should decrease when the ball falls below the paddle")

if __name__ == '__main__':
    unittest.main()
