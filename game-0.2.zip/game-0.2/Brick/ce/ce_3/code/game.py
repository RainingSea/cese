import pygame
from paddle import Paddle
from ball import Ball
from brick import Brick

class Game:
    def __init__(self, width: int, height: int):
        self.width = width
        self.height = height
        self.paddle = Paddle(width // 2, 100)
        self.ball = Ball(width // 2, height // 2)
        self.bricks = self.load_bricks()

    def load_bricks(self):
        bricks = []
        with open('bricks.txt', 'r') as file:
            for line in file:
                x, y, lives = map(int, line.strip().split('|'))
                bricks.append(Brick(x, y, lives))
        return bricks

    def run(self):
        pygame.init()
        screen = pygame.display.set_mode((self.width, self.height))
        clock = pygame.time.Clock()
        running = True

        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False

            keys = pygame.key.get_pressed()
            if keys[pygame.K_LEFT]:
                self.paddle.move('left')
            if keys[pygame.K_RIGHT]:
                self.paddle.move('right')

            self.ball.move()
            self.check_collisions()
            self.draw(screen)
            clock.tick(60)

        pygame.quit()

    def draw(self, screen):
        screen.fill((0, 0, 0))
        self.paddle.draw(screen)
        self.ball.draw(screen)
        for brick in self.bricks:
            brick.draw(screen)
        pygame.display.flip()

    def check_collisions(self):
        # Check for collisions with the paddle and bricks
        pass  # Collision logic to be implemented