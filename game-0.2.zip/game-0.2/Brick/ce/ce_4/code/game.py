import pygame
from paddle import Paddle
from ball import Ball
from brick import Brick

class Game:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((800, 600))
        self.paddle = Paddle(375, 100)
        self.ball = Ball(400, 300)
        self.bricks = [Brick(x * 60, y * 30, 1) for x in range(13) for y in range(5)]
        self.score = 0

    def run(self):
        running = True
        while running:
            self.handle_input()
            self.update()
            self.draw()
            pygame.display.flip()
            pygame.time.delay(30)

    def handle_input(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()

        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            self.paddle.move('left')
        if keys[pygame.K_RIGHT]:
            self.paddle.move('right')

    def update(self):
        self.ball.update()
        # Ball collision with paddle and bricks logic would go here

    def draw(self):
        self.screen.fill((0, 0, 0))
        self.paddle.draw(self.screen)
        self.ball.draw(self.screen)
        for brick in self.bricks:
            brick.draw(self.screen)

    def save_game_state(self):
        with open('game_state.txt', 'w') as f:
            f.write(f'Score: {self.score}\n')
            for brick in self.bricks:
                f.write(f'{brick.x}|{brick.y}|{brick.lives}\n')