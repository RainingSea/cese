import pygame

class Paddle:
    def __init__(self, x: int, width: int):
        self.x = x
        self.width = width

    def move(self, direction: str):
        if direction == 'left':
            self.x -= 10
        elif direction == 'right':
            self.x += 10

    def draw(self, surface):
        pygame.draw.rect(surface, (255, 255, 255), (self.x, surface.get_height() - 20, self.width, 10))