import pygame

class Brick:
    def __init__(self, x: int, y: int, lives: int):
        self.x = x
        self.y = y
        self.lives = lives

    def hit(self):
        self.lives -= 1

    def draw(self, surface):
        color = (255, 0, 0) if self.lives > 0 else (0, 0, 0)
        pygame.draw.rect(surface, color, (self.x, self.y, 50, 20))