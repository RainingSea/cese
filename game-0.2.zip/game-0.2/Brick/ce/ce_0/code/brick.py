class Brick:
    def __init__(self, brick_id, life_count):
        self.id = brick_id
        self.life_count = life_count

    def hit(self):
        if self.life_count > 0:
            self.life_count -= 1

    def is_destroyed(self):
        return self.life_count <= 0