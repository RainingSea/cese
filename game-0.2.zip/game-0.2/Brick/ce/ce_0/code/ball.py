class Ball:
    def __init__(self, position_x, position_y, velocity_x, velocity_y):
        self.position_x = position_x
        self.position_y = position_y
        self.velocity_x = velocity_x
        self.velocity_y = velocity_y

    def update_position(self):
        self.position_x += self.velocity_x
        self.position_y += self.velocity_y

    def bounce(self):
        self.velocity_y = -self.velocity_y