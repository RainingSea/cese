import pygame
from paddle import Paddle
from ball import Ball
from brick import Brick

class Game:
    def __init__(self):
        self.paddle = Paddle(300, 100)
        self.ball = Ball(400, 300, 5, -5)
        self.bricks = [Brick(i, 3) for i in range(10)]

    def start_game(self):
        pygame.init()
        self.screen = pygame.display.set_mode((800, 600))
        pygame.display.set_caption("Brick Breaker")
        self.load_game_data()
        self.run_game_loop()

    def run_game_loop(self):
        running = True
        while running:
            self.handle_input()
            self.update()
            self.draw()
            pygame.display.flip()

    def update(self):
        self.ball.update_position()
        self.check_collisions()

    def draw(self):
        self.screen.fill((0, 0, 0))
        # Draw paddle
        pygame.draw.rect(self.screen, (255, 255, 255), (self.paddle.position_x, 550, self.paddle.width, 10))
        # Draw ball
        pygame.draw.circle(self.screen, (255, 255, 255), (self.ball.position_x, self.ball.position_y), 10)
        # Draw bricks
        for brick in self.bricks:
            if not brick.is_destroyed():
                pygame.draw.rect(self.screen, (255, 0, 0), (brick.id * 80, 50, 80, 30))

    def handle_input(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    self.paddle.move_left()
                if event.key == pygame.K_RIGHT:
                    self.paddle.move_right()

    def check_collisions(self):
        # Check for ball collision with paddle and bricks
        pass

    def load_game_data(self):
        try:
            with open('game_data.txt', 'r') as file:
                for line in file:
                    brick_id, life_count = map(int, line.strip().split(':'))
                    self.bricks[brick_id].life_count = life_count
        except FileNotFoundError:
            pass

    def save_game_data(self):
        with open('game_data.txt', 'w') as file:
            for brick in self.bricks:
                file.write(f"{brick.id}:{brick.life_count}\n")