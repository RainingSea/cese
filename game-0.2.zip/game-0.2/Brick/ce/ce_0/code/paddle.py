class Paddle:
    def __init__(self, position_x, width):
        self.position_x = position_x
        self.width = width

    def move_left(self):
        self.position_x -= 10

    def move_right(self):
        self.position_x += 10