import random
import pygame

class Block:
    def __init__(self, color: str) -> None:
        self.color = color

class Grid:
    def __init__(self, size: int) -> None:
        self.blocks = []
        self.initialize_grid(size)

    def initialize_grid(self, size: int) -> None:
        colors = ['red', 'green', 'blue', 'yellow', 'purple', 'orange']
        self.blocks = [[Block(random.choice(colors)) for _ in range(size)] for _ in range(size)]

    def get_block(self, pos: tuple) -> Block:
        x, y = pos
        return self.blocks[y][x]

    def set_block(self, pos: tuple, block: Block) -> None:
        x, y = pos
        self.blocks[y][x] = block

    def find_matches(self) -> list:
        matches = []
        # Check for horizontal matches
        for y in range(len(self.blocks)):
            for x in range(len(self.blocks[y]) - 2):
                if (self.blocks[y][x].color == self.blocks[y][x + 1].color == self.blocks[y][x + 2].color):
                    matches.append((x, y))
                    matches.append((x + 1, y))
                    matches.append((x + 2, y))
        # Check for vertical matches
        for x in range(len(self.blocks[0])):
            for y in range(len(self.blocks) - 2):
                if (self.blocks[y][x].color == self.blocks[y + 1][x].color == self.blocks[y + 2][x].color):
                    matches.append((x, y))
                    matches.append((x, y + 1))
                    matches.append((x, y + 2))
        return matches

class Score:
    def __init__(self) -> None:
        self.points = 0

    def add_points(self, points: int) -> None:
        self.points += points

    def get_score(self) -> int:
        return self.points

class Game:
    def __init__(self) -> None:
        self.grid = Grid(size=8)
        self.score = Score()
        self.moves = 0

    def start_game(self) -> None:
        self.load_game_data()

    def swap_blocks(self, pos1: tuple, pos2: tuple) -> bool:
        block1 = self.get_block(pos1)
        block2 = self.get_block(pos2)
        self.set_block(pos1, block2)
        self.set_block(pos2, block1)
        self.moves += 1
        return True

    def check_matches(self) -> list:
        return self.grid.find_matches()

    def clear_matches(self, matches: list) -> None:
        for pos in matches:
            self.grid.set_block(pos, Block(random.choice(['red', 'green', 'blue', 'yellow', 'purple', 'orange'])))

    def update_score(self) -> None:
        self.score.add_points(10)

    def load_game_data(self) -> None:
        try:
            with open('game_data.txt', 'r') as file:
                data = file.readlines()
                for line in data:
                    key, value = line.strip().split('|')
                    if key == 'score':
                        self.score.points = int(value)
                    elif key == 'moves':
                        self.moves = int(value)
        except FileNotFoundError:
            pass

    def save_game_data(self) -> None:
        with open('game_data.txt', 'w') as file:
            file.write(f'score|{self.score.get_score()}\n')
            file.write(f'moves|{self.moves}\n')