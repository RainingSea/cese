import unittest
import os
from game import Game, Block, Grid

class TestColorSwapChallenge(unittest.TestCase):

    def setUp(self):
        self.game = Game()

    def test_control_grid_of_colored_blocks(self):
        # Functionalities 1: Test initial grid setup
        initial_grid = self.game.grid.blocks
        self.assertEqual(len(initial_grid), 8, "Grid should be initialized with 8 rows")
        self.assertEqual(len(initial_grid[0]), 8, "Grid should be initialized with 8 columns")

        # Test swapping adjacent blocks
        pos1 = (0, 0)
        pos2 = (0, 1)
        block1_color = self.game.grid.get_block(pos1).color
        block2_color = self.game.grid.get_block(pos2).color
        self.game.swap_blocks(pos1, pos2)
        self.assertEqual(self.game.grid.get_block(pos1).color, block2_color, "Blocks should be swapped")
        self.assertEqual(self.game.grid.get_block(pos2).color, block1_color, "Blocks should be swapped")

    def test_clear_blocks_by_matching(self):
        # Functionalities 2: Test clearing blocks by matching
        self.game.grid.set_block((0, 0), Block('red'))
        self.game.grid.set_block((1, 0), Block('red'))
        self.game.grid.set_block((2, 0), Block('red'))
        matches = self.game.check_matches()
        self.assertIn((0, 0), matches, "Match should be found at (0, 0)")
        self.assertIn((1, 0), matches, "Match should be found at (1, 0)")
        self.assertIn((2, 0), matches, "Match should be found at (2, 0)")
        self.game.clear_matches(matches)
        self.assertNotEqual(self.game.grid.get_block((0, 0)).color, 'red', "Block should be cleared")
        self.assertNotEqual(self.game.grid.get_block((1, 0)).color, 'red', "Block should be cleared")
        self.assertNotEqual(self.game.grid.get_block((2, 0)).color, 'red', "Block should be cleared")

    def test_level_progression_and_difficulty(self):
        # Functionalities 3: Test level progression (not implemented in codebase)
        self.fail("Level progression and difficulty functionality is not implemented in the codebase")

    def test_scoring_system(self):
        # Functionalities 4: Test scoring system
        initial_score = self.game.score.get_score()
        self.game.update_score()
        self.assertEqual(self.game.score.get_score(), initial_score + 10, "Score should increase by 10")

    def test_power_ups_activation(self):
        # Functionalities 5: Test power-ups activation (not implemented in codebase)
        self.fail("Power-ups activation functionality is not implemented in the codebase")

    def test_move_limit_tracking(self):
        # Functionalities 6: Test move limit tracking
        initial_moves = self.game.moves
        self.game.swap_blocks((0, 0), (0, 1))
        self.assertEqual(self.game.moves, initial_moves + 1, "Move counter should increase by 1")

    def test_bonus_points_for_combos(self):
        # Functionalities 7: Test bonus points for combos (not implemented in codebase)
        self.fail("Bonus points for combos functionality is not implemented in the codebase")

    def test_data_storage(self):
        # Functionalities 8: Test data storage
        self.game.save_game_data()
        self.assertTrue(os.path.exists('game_data.txt'), "Game data file should exist")
        with open('game_data.txt', 'r') as file:
            data = file.readlines()
            self.assertIn('score|10\n', data, "Score should be saved in the file")
            self.assertIn('moves|1\n', data, "Moves should be saved in the file")

        # Test loading game data
        self.game.load_game_data()
        self.assertEqual(self.game.score.get_score(), 10, "Score should be loaded correctly")
        self.assertEqual(self.game.moves, 1, "Moves should be loaded correctly")

if __name__ == '__main__':
    unittest.main()
