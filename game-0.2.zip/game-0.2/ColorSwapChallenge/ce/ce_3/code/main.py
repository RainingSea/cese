import pygame
from game import Game

def main():
    pygame.init()
    screen = pygame.display.set_mode((400, 400))
    pygame.display.set_caption("Block Matching Game")
    
    game = Game()
    game.start_game()
    
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
        
        screen.fill((255, 255, 255))
        game.grid.draw_grid(screen)
        pygame.display.flip()
    
    pygame.quit()

if __name__ == "__main__":
    main()