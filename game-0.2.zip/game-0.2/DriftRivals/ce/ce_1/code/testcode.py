import unittest
import pygame
from game import Game, Car, Track, Score

class TestDriftRivalsGame(unittest.TestCase):

    def setUp(self):
        # Initialize the game and its components
        pygame.init()
        self.game = Game()
        self.car = self.game.car
        self.track = self.game.track
        self.score = self.game.score

    def test_player_controls_drift_car(self):
        # Functionality 1: Test car movement controls
        initial_position = self.car.position

        # Simulate pressing the up arrow key
        self.car.move('UP')
        self.assertNotEqual(self.car.position, initial_position, "Car should move forward when UP is pressed")

        # Simulate pressing the left arrow key
        self.car.move('LEFT')
        self.assertLess(self.car.position[0], initial_position[0], "Car should move left when LEFT is pressed")

        # Simulate pressing the down arrow key
        self.car.move('DOWN')
        self.assertGreater(self.car.position[1], initial_position[1], "Car should move down when DOWN is pressed")

        # Simulate pressing the right arrow key
        self.car.move('RIGHT')
        self.assertGreater(self.car.position[0], initial_position[0], "Car should move right when RIGHT is pressed")

    def test_variety_of_tracks(self):
        # Functionality 2: Test track loading
        self.assertIsNotNone(self.track, "Track should be loaded")
        self.assertIsInstance(self.track, Track, "Loaded track should be an instance of Track")

    def test_drift_challenges_and_scoring_system(self):
        # Functionality 3: Test drift scoring
        drift_data = self.car.drift()
        initial_score = self.score.points
        self.game.update_score(drift_data)
        self.assertGreater(self.score.points, initial_score, "Score should increase after a drift")

    def test_data_storage(self):
        # Functionality 4: Test score saving
        initial_score = self.score.points
        self.score.save_score()
        with open('scores.txt', 'r') as f:
            lines = f.readlines()
            self.assertIn(f"{initial_score}\n", lines, "Score should be saved in scores.txt")

if __name__ == '__main__':
    unittest.main()
