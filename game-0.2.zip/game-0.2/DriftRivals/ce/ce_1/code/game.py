import pygame
import os
from pygame.locals import *

class Track:
    def __init__(self, name: str, image: str):
        self.name = name
        self.image = image

    def load_track(self) -> None:
        self.track_image = pygame.image.load(self.image)

class Car:
    def __init__(self):
        self.position = (100, 100)
        self.speed = 0.0

    def move(self, direction: str) -> None:
        if direction == 'UP':
            self.position = (self.position[0], self.position[1] - 5)
        elif direction == 'DOWN':
            self.position = (self.position[0], self.position[1] + 5)
        elif direction == 'LEFT':
            self.position = (self.position[0] - 5, self.position[1])
        elif direction == 'RIGHT':
            self.position = (self.position[0] + 5, self.position[1])

    def drift(self) -> dict:
        drift_data = {'angle': 30, 'duration': 2}  # Example drift data
        return drift_data

class Score:
    def __init__(self):
        self.points = 0

    def calculate_score(self, drift_data: dict) -> int:
        self.points += drift_data['angle'] * drift_data['duration']
        return self.points

    def save_score(self) -> None:
        with open('scores.txt', 'a') as f:
            f.write(f"{self.points}\n")

class Game:
    def __init__(self):
        self.track = None
        self.car = Car()
        self.score = Score()
        self.load_tracks()

    def load_tracks(self) -> None:
        with open('tracks.txt', 'r') as f:
            track_data = f.readlines()
            self.track = Track(track_data[0].strip(), track_data[1].strip())
            self.track.load_track()

    def update_score(self, drift_data: dict) -> None:
        current_score = self.score.calculate_score(drift_data)
        print(f"Current Score: {current_score}")

    def run(self) -> None:
        screen = pygame.display.set_mode((800, 600))
        pygame.display.set_caption('Drift Game')
        clock = pygame.time.Clock()
        running = True

        while running:
            for event in pygame.event.get():
                if event.type == QUIT:
                    running = False

            keys = pygame.key.get_pressed()
            if keys[K_UP]:
                self.car.move('UP')
            if keys[K_DOWN]:
                self.car.move('DOWN')
            if keys[K_LEFT]:
                self.car.move('LEFT')
            if keys[K_RIGHT]:
                self.car.move('RIGHT')

            drift_data = self.car.drift()
            self.update_score(drift_data)

            screen.fill((255, 255, 255))
            screen.blit(self.track.track_image, (0, 0))
            pygame.draw.rect(screen, (0, 0, 255), (*self.car.position, 50, 30))
            pygame.display.flip()
            clock.tick(60)

        self.score.save_score()