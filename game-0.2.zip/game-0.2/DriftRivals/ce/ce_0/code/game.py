import pygame
from car import Car
from track import Track
from score_manager import ScoreManager

class Game:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((800, 600))
        self.car = Car(position=(400, 300), speed=5.0)
        self.track = Track()
        self.score_manager = ScoreManager()
        self.track.load_track('tracks.txt')
        self.score_manager.load_scores('scores.txt')

    def run(self) -> None:
        running = True
        while running:
            self.handle_input()
            self.update()
            self.render()

    def handle_input(self) -> None:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()

        keys = pygame.key.get_pressed()
        if keys[pygame.K_UP]:
            self.car.move('UP')
        if keys[pygame.K_DOWN]:
            self.car.move('DOWN')
        if keys[pygame.K_LEFT]:
            self.car.move('LEFT')
        if keys[pygame.K_RIGHT]:
            self.car.move('RIGHT')

    def update(self) -> None:
        # Update game state here
        pass

    def render(self) -> None:
        self.screen.fill((0, 0, 0))  # Clear screen
        # Render track and car here
        pygame.display.flip()