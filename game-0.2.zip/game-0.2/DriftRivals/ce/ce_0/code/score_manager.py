class ScoreManager:
    def __init__(self):
        self.scores = {}

    def load_scores(self, file_path: str) -> None:
        with open(file_path, 'r') as file:
            for line in file:
                player_name, score = line.strip().split('|')
                self.scores[player_name] = float(score)

    def save_score(self, player_name: str, score: float) -> None:
        self.scores[player_name] = score
        with open('scores.txt', 'a') as file:
            file.write(f"{player_name}|{score}\n")

    def get_high_scores(self) -> dict:
        return dict(sorted(self.scores.items(), key=lambda item: item[1], reverse=True))