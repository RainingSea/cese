class Track:
    def __init__(self):
        self.layout = []
        self.difficulty = 0

    def load_track(self, file_path: str) -> None:
        with open(file_path, 'r') as file:
            data = file.readlines()
            self.layout = [line.strip() for line in data if line.strip()]
            self.difficulty = len(self.layout)  # Example difficulty based on track length

    def get_layout(self) -> list:
        return self.layout