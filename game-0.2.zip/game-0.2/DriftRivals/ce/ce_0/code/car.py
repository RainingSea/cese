class Car:
    def __init__(self, position=(0, 0), speed=0.0):
        self.position = position
        self.speed = speed

    def move(self, direction: str) -> None:
        if direction == 'UP':
            self.position = (self.position[0], self.position[1] - self.speed)
        elif direction == 'DOWN':
            self.position = (self.position[0], self.position[1] + self.speed)
        elif direction == 'LEFT':
            self.position = (self.position[0] - self.speed, self.position[1])
        elif direction == 'RIGHT':
            self.position = (self.position[0] + self.speed, self.position[1])

    def drift(self) -> float:
        # Simple drift calculation, can be expanded
        drift_value = self.speed * 0.5
        return drift_value