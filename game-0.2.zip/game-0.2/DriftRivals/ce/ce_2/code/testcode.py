import unittest
from car import Car
from track import Track
from score_manager import ScoreManager

class TestDriftRivalsGame(unittest.TestCase):

    def setUp(self):
        # Initialize the car, track, and score manager
        self.car = Car()
        self.track = Track()
        self.score_manager = ScoreManager()

    def test_player_controls_drift_car(self):
        # Test accelerating the car
        initial_position = self.car.position
        self.car.move('up')
        self.assertNotEqual(self.car.position, initial_position, "Car should move forward when up arrow is pressed")

        # Test turning the car left
        initial_position = self.car.position
        self.car.move('left')
        self.assertNotEqual(self.car.position, initial_position, "Car should turn left when left arrow is pressed")

        # Test braking the car
        initial_position = self.car.position
        self.car.move('down')
        self.assertNotEqual(self.car.position, initial_position, "Car should move backward when down arrow is pressed")

        # Test turning the car right
        initial_position = self.car.position
        self.car.move('right')
        self.assertNotEqual(self.car.position, initial_position, "Car should turn right when right arrow is pressed")

    def test_variety_of_tracks(self):
        # Test loading a track
        self.track.load_track('tracks.json')
        self.assertTrue(self.track.layout, "Track should load successfully")

        # Test navigating through the track
        # This is a placeholder as actual navigation would require game loop and input handling
        self.assertTrue(True, "Player should navigate the track without errors")

    def test_drift_challenges_and_scoring_system(self):
        # Test completing a drift challenge
        drift_score = self.car.drift()
        self.assertGreater(drift_score, 0, "Drift score should be calculated based on performance")

        # Test score updates in real-time
        initial_score = self.score_manager.scores.get("player1", 0)
        self.score_manager.update_score(drift_score)
        updated_score = self.score_manager.scores.get("player1", 0)
        self.assertGreater(updated_score, initial_score, "Score should update in real-time based on drift performance")

    def test_data_storage(self):
        # Test saving score data
        self.score_manager.update_score(10.0)
        self.score_manager.save_score('scores.txt')
        with open('scores.txt', 'r') as file:
            data = file.read()
        self.assertIn("player1|10.0", data, "Score should be saved to the local text file")

        # Test loading score data
        scores = self.score_manager.load_scores('scores.txt')
        self.assertIn("player1", scores, "Score should be loaded from the local text file")
        self.assertEqual(scores["player1"], 10.0, "Loaded score should match the saved score")

if __name__ == '__main__':
    unittest.main()
