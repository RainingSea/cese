class Car:
    def __init__(self):
        self.position = (0, 0)
        self.speed = 0.0

    def move(self, direction: str) -> None:
        if direction == "left":
            self.position = (self.position[0] - 1, self.position[1])
        elif direction == "right":
            self.position = (self.position[0] + 1, self.position[1])
        elif direction == "up":
            self.position = (self.position[0], self.position[1] - 1)
        elif direction == "down":
            self.position = (self.position[0], self.position[1] + 1)

    def drift(self) -> float:
        # Placeholder for drift calculation
        drift_score = 10.0  # Example drift score
        return drift_score