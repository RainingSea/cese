import pygame
from car import Car
from track import Track
from score_manager import ScoreManager

class Game:
    def __init__(self):
        self.pygame = pygame
        self.car = Car()
        self.track = Track()
        self.score_manager = ScoreManager()

    def run(self) -> None:
        self.pygame.init()
        self.track.load_track('tracks.json')
        self.score_manager.load_scores('scores.txt')
        # Main game loop
        while True:
            self.handle_input()
            self.update()
            self.draw()

    def handle_input(self) -> None:
        for event in self.pygame.event.get():
            if event.type == self.pygame.QUIT:
                self.pygame.quit()
                exit()
            # Handle other inputs (e.g., keyboard, controller)

    def update(self) -> None:
        # Update game state
        pass

    def draw(self) -> None:
        # Draw game elements
        self.track.draw()
        print("Car position:", self.car.position)