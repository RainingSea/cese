import json

class ScoreManager:
    def __init__(self):
        self.scores = {}

    def update_score(self, drift_score: float) -> None:
        player_id = "player1"  # Example player ID
        if player_id in self.scores:
            self.scores[player_id] += drift_score
        else:
            self.scores[player_id] = drift_score

    def save_score(self, file_path: str) -> None:
        with open(file_path, 'w') as file:
            for player_id, score in self.scores.items():
                file.write(f"{player_id}|{score}\n")

    def load_scores(self, file_path: str) -> dict:
        try:
            with open(file_path, 'r') as file:
                for line in file:
                    player_id, score = line.strip().split('|')
                    self.scores[player_id] = float(score)
        except FileNotFoundError:
            print("Score file not found. Starting with an empty score list.")
        return self.scores