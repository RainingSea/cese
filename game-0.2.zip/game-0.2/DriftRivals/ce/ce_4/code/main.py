import pygame
from game import Game

def main() -> None:
    game = Game()
    game.current_track.load_track('tracks.txt')
    pygame.display.set_mode((800, 600))
    
    while True:
        game.run()

if __name__ == "__main__":
    main()