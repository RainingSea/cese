class Player:
    def __init__(self, name: str):
        self.name = name
        self.score = 0

    def drift(self) -> None:
        # Implement drift logic here
        pass

    def calculate_score(self, drift_data: dict) -> None:
        # Implement score calculation based on drift data
        self.score += drift_data.get('points', 0)