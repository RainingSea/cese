import pygame
from pygame.locals import *
from track import Track
from player import Player
from scoreboard import Scoreboard

class Game:
    def __init__(self):
        self.tracks = []
        self.player = Player("Player1")
        self.scoreboard = Scoreboard()
        self.load_tracks("tracks.txt")
        self.screen = pygame.display.set_mode((800, 600))
        pygame.display.set_caption("Drift Game")
        self.clock = pygame.time.Clock()

    def load_tracks(self, file_path: str) -> None:
        with open(file_path, 'r') as file:
            for line in file:
                track = Track()
                track.load_track(line.strip())
                self.tracks.append(track)

    def start_game(self) -> None:
        running = True
        while running:
            self.handle_input()
            self.update()
            self.render()
            self.clock.tick(60)

    def update(self) -> None:
        # Update game state logic here
        pass

    def render(self) -> None:
        self.screen.fill((255, 255, 255))  # Clear screen with white
        # Render game elements here
        pygame.display.flip()

    def handle_input(self) -> None:
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                exit()

            # Handle other input events here