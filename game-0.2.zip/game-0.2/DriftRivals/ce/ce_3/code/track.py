class Track:
    def __init__(self):
        self.name = ""
        self.corners = []

    def load_track(self, file_path: str) -> None:
        data = file_path.split('|')
        self.name = data[0]
        self.corners = eval(data[2])  # Assuming corners are provided as a list in string format