import unittest
import pygame
from game import Game, Bird, Pipe

class TestFlappyBirdGame(unittest.TestCase):

    def setUp(self):
        # Initialize the game
        self.game = Game()

    def test_bird_control(self):
        # Functionality 1: Bird Control
        # Test initial position
        initial_y = self.game.bird.y
        self.game.bird.update()
        self.assertGreater(self.game.bird.y, initial_y, "Bird should fall due to gravity")

        # Test bird flap
        self.game.bird.flap()
        self.assertEqual(self.game.bird.velocity, self.game.bird.flap_strength, "Bird should move upward when flapped")

    def test_pipe_navigation(self):
        # Functionality 2: Pipe Navigation
        self.game.update()  # Generate pipes
        self.assertTrue(any(pipe.x == 400 for pipe in self.game.pipes), "Pipes should be generated at the right side of the screen")

        # Test navigation through pipes (collision detection)
        self.game.bird.y = self.game.pipes[0].height + self.game.pipes[0].gap // 2
        self.assertFalse(self.game.check_collision(), "Bird should pass through the gap without collision")

    def test_pipe_movement(self):
        # Functionality 3: Pipe Movement
        self.game.update()  # Generate pipes
        initial_x = self.game.pipes[0].x
        self.game.pipes[0].update()
        self.assertLess(self.game.pipes[0].x, initial_x, "Pipes should move from right to left")

        # Test scoring and pipe speed increase
        initial_score = self.game.score
        self.game.pipes[0].x = -51  # Simulate passing a pipe
        self.game.update()
        self.assertGreater(self.game.score, initial_score, "Score should increase when passing through pipes")

    def test_scoring_system(self):
        # Functionality 4: Scoring System
        self.game.update()  # Generate pipes
        self.game.pipes[0].x = -51  # Simulate passing a pipe
        initial_score = self.game.score
        self.game.update()
        self.assertEqual(self.game.score, initial_score + 1, "Score should increase by one point after passing a pipe")

    def test_game_over_conditions(self):
        # Functionality 5: Game Over Conditions
        # Test collision with pipe
        self.game.bird.y = self.game.pipes[0].height
        self.game.check_collision()
        self.assertTrue(self.game.game_over, "Game should end when bird collides with a pipe")

        # Test falling to the ground
        self.game.restart()
        self.game.bird.y = 601  # Simulate falling to the ground
        self.game.update()
        self.assertTrue(self.game.game_over, "Game should end when bird falls to the ground")

    def test_restart_game(self):
        # Functionality 6: Restart Game
        self.game.game_over = True
        self.game.restart()
        self.assertFalse(self.game.game_over, "Game should reset and not be over after restart")
        self.assertEqual(self.game.bird.y, 200, "Bird should be reset to starting position after restart")

    def test_high_score_storage(self):
        # Functionality 7: High Score Storage
        self.game.save_high_score(5)
        high_scores = self.game.load_high_scores()
        self.assertIn(5, high_scores, "High score of 5 should be saved in the local text file")

        # Test that a lower score does not overwrite a higher score
        self.game.save_high_score(3)
        high_scores = self.game.load_high_scores()
        self.assertIn(5, high_scores, "High score should remain at 5 and not be overwritten by a lower score")

if __name__ == '__main__':
    unittest.main()
