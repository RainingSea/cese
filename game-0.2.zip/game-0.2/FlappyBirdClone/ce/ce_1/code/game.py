import pygame
import random

class Bird:
    def __init__(self, x: int, y: int):
        self.x = x
        self.y = y
        self.gravity = 1
        self.flap_strength = -15
        self.velocity = 0

    def flap(self) -> None:
        self.velocity = self.flap_strength

    def update(self) -> None:
        self.velocity += self.gravity
        self.y += self.velocity

class Pipe:
    def __init__(self, x: int, height: int, gap: int):
        self.x = x
        self.height = height
        self.gap = gap

    def update(self) -> None:
        self.x -= 5  # Move pipe to the left

    def draw(self, screen) -> None:
        pygame.draw.rect(screen, (0, 255, 0), (self.x, 0, 50, self.height))
        pygame.draw.rect(screen, (0, 255, 0), (self.x, self.height + self.gap, 50, screen.get_height()))

    def is_off_screen(self) -> bool:
        return self.x < -50

class Game:
    def __init__(self):
        self.bird = Bird(100, 200)
        self.pipes = []
        self.score = 0
        self.game_over = False
        self.load_high_scores()

    def run(self) -> None:
        pygame.init()
        screen = pygame.display.set_mode((400, 600))
        clock = pygame.time.Clock()

        while True:
            self.update()
            self.draw(screen)
            clock.tick(60)

    def update(self) -> None:
        if not self.game_over:
            self.bird.update()
            if random.randint(1, 100) < 2:  # Randomly generate pipes
                height = random.randint(100, 400)
                self.pipes.append(Pipe(400, height, 150))
            for pipe in self.pipes:
                pipe.update()
                if pipe.is_off_screen():
                    self.pipes.remove(pipe)
                    self.score += 1
            self.check_collision()

    def draw(self, screen) -> None:
        screen.fill((135, 206, 250))  # Sky blue background
        self.bird.update()
        pygame.draw.circle(screen, (255, 255, 0), (self.bird.x, self.bird.y), 15)  # Draw bird
        for pipe in self.pipes:
            pipe.draw(screen)
        pygame.display.flip()

    def check_collision(self) -> bool:
        for pipe in self.pipes:
            if (self.bird.x + 15 > pipe.x and self.bird.x - 15 < pipe.x + 50 and
                (self.bird.y - 15 < pipe.height or self.bird.y + 15 > pipe.height + pipe.gap)):
                self.game_over = True
                return True
        return False

    def restart(self) -> None:
        self.bird = Bird(100, 200)
        self.pipes.clear()
        self.score = 0
        self.game_over = False

    def load_high_scores(self) -> list:
        try:
            with open('high_scores.txt', 'r') as file:
                return [int(line.strip()) for line in file.readlines()]
        except FileNotFoundError:
            return []

    def save_high_score(self, score: int) -> None:
        high_scores = self.load_high_scores()
        high_scores.append(score)
        high_scores.sort(reverse=True)
        with open('high_scores.txt', 'w') as file:
            for high_score in high_scores[:10]:  # Keep top 10 scores
                file.write(f"{high_score}\n")