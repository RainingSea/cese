import unittest
import pygame
from game import Game, Bird, Pipe

class TestFlappyBirdGame(unittest.TestCase):

    def setUp(self):
        # Initialize the game and its components
        self.game = Game()
        self.bird = self.game.bird
        self.pipes = self.game.pipes

    def test_bird_control(self):
        # Functionality 1: Bird Control
        initial_y = self.bird.y
        self.bird.update()
        self.assertGreater(self.bird.y, initial_y, "Bird should fall due to gravity")

        self.bird.flap()
        self.bird.update()
        self.assertLess(self.bird.y, initial_y, "Bird should move upward after flap")

    def test_pipe_navigation(self):
        # Functionality 2: Pipe Navigation
        self.assertGreater(len(self.pipes), 0, "Pipes should be generated at the start of the game")
        for pipe in self.pipes:
            self.assertTrue(pipe.gap_y > 0 and pipe.gap_y + pipe.gap_height < 600, 
                            "Pipes should have a gap for the bird to pass through")

    def test_pipe_movement(self):
        # Functionality 3: Pipe Movement
        initial_x = self.pipes[0].x
        self.pipes[0].update()
        self.assertLess(self.pipes[0].x, initial_x, "Pipes should move from right to left")

    def test_scoring_system(self):
        # Functionality 4: Scoring System
        initial_score = self.game.score
        self.pipes[0].x = -51  # Simulate pipe passing
        self.game.update()
        self.assertGreater(self.game.score, initial_score, "Score should increase after passing a pipe")

    def test_game_over_conditions(self):
        # Functionality 5: Game Over Conditions
        self.bird.y = self.pipes[0].gap_y - 16  # Simulate collision with pipe
        self.assertTrue(self.game.check_collision(), "Game should detect collision with pipe")

        self.bird.y = 601  # Simulate falling to the ground
        self.assertTrue(self.game.check_collision(), "Game should detect collision with ground")

    def test_restart_game(self):
        # Functionality 6: Restart Game
        self.game.restart()
        self.assertEqual(self.game.score, 0, "Score should reset to 0 after restart")
        self.assertEqual(self.bird.y, 300, "Bird should be reset to starting position after restart")

    def test_high_score_storage(self):
        # Functionality 7: High Score Storage
        self.game.score = 5
        self.game.save_high_score()
        self.game.load_high_score()
        self.assertEqual(self.game.high_score, 5, "High score should be saved and loaded correctly")

        self.game.score = 3
        self.game.save_high_score()
        self.game.load_high_score()
        self.assertEqual(self.game.high_score, 5, "High score should not be overwritten by a lower score")

if __name__ == '__main__':
    unittest.main()
