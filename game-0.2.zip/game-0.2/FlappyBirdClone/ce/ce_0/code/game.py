import pygame
import random

class Bird:
    def __init__(self, x: int, y: int):
        self.x = x
        self.y = y
        self.velocity = 0

    def flap(self) -> None:
        self.velocity = -10

    def update(self) -> None:
        self.velocity += 1
        self.y += self.velocity

class Pipe:
    def __init__(self, x: int, gap_y: int, gap_height: int):
        self.x = x
        self.gap_y = gap_y
        self.gap_height = gap_height

    def update(self) -> None:
        self.x -= 5

    def draw(self, surface) -> None:
        pygame.draw.rect(surface, (0, 255, 0), (self.x, 0, 50, self.gap_y))
        pygame.draw.rect(surface, (0, 255, 0), (self.x, self.gap_y + self.gap_height, 50, 600))

class Game:
    def __init__(self):
        self.bird = Bird(100, 300)
        self.pipes = []
        self.score = 0
        self.high_score = 0
        self.load_high_score()
        self.create_pipes()

    def create_pipes(self) -> None:
        gap_y = random.randint(100, 400)
        gap_height = 150
        self.pipes.append(Pipe(600, gap_y, gap_height))

    def run(self) -> None:
        pygame.init()
        screen = pygame.display.set_mode((600, 600))
        clock = pygame.time.Clock()
        running = True

        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
                    self.bird.flap()

            self.update()
            self.draw(screen)
            clock.tick(30)

        pygame.quit()

    def update(self) -> None:
        self.bird.update()
        for pipe in self.pipes:
            pipe.update()
            if pipe.x < -50:
                self.pipes.remove(pipe)
                self.create_pipes()
                self.score += 1

        if self.check_collision():
            self.restart()

    def draw(self, surface) -> None:
        surface.fill((255, 255, 255))
        self.bird.update()
        pygame.draw.circle(surface, (255, 0, 0), (self.bird.x, self.bird.y), 15)
        for pipe in self.pipes:
            pipe.draw(surface)
        font = pygame.font.Font(None, 36)
        score_text = font.render(f'Score: {self.score}', True, (0, 0, 0))
        surface.blit(score_text, (10, 10))
        pygame.display.flip()

    def check_collision(self) -> bool:
        for pipe in self.pipes:
            if (self.bird.x + 15 > pipe.x and self.bird.x - 15 < pipe.x + 50 and
                (self.bird.y - 15 < pipe.gap_y or self.bird.y + 15 > pipe.gap_y + pipe.gap_height)):
                return True
        return False

    def restart(self) -> None:
        if self.score > self.high_score:
            self.high_score = self.score
            self.save_high_score()
        self.score = 0
        self.bird = Bird(100, 300)
        self.pipes.clear()
        self.create_pipes()

    def load_high_score(self) -> None:
        try:
            with open('high_scores.txt', 'r') as file:
                scores = file.readlines()
                self.high_score = max([int(score.strip()) for score in scores], default=0)
        except FileNotFoundError:
            self.high_score = 0

    def save_high_score(self) -> None:
        with open('high_scores.txt', 'a') as file:
            file.write(f'{self.high_score}\n')