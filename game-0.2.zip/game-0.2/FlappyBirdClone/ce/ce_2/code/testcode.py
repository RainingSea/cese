import unittest
import pygame
from game import Game, Bird, Pipe

class TestFlappyBirdClone(unittest.TestCase):

    def setUp(self):
        # Initialize the game and its components
        self.game = Game()
        self.bird = self.game.bird
        self.pipes = self.game.pipes

    def test_bird_control(self):
        # Functionality 1: Bird Control
        # Test initial position and falling due to gravity
        initial_y = self.bird.y
        self.bird.update()
        self.assertGreater(self.bird.y, initial_y, "Bird should fall due to gravity")

        # Test bird flap
        self.bird.flap()
        self.bird.update()
        self.assertLess(self.bird.y, initial_y, "Bird should move upward when flapped")

    def test_pipe_navigation(self):
        # Functionality 2: Pipe Navigation
        # Test pipe generation
        self.assertEqual(len(self.pipes), 3, "Three pipes should be generated initially")

        # Test navigating through pipes
        self.bird.y = self.pipes[0].height + 75  # Position bird in the middle of the gap
        self.assertFalse(self.game.check_collision(), "Bird should pass through the gap without collision")

    def test_pipe_movement(self):
        # Functionality 3: Pipe Movement
        initial_x = self.pipes[0].x
        self.pipes[0].update()
        self.assertLess(self.pipes[0].x, initial_x, "Pipes should move from right to left")

        # Test scoring by passing through pipes
        self.game.score = 0
        self.pipes[0].x = -51  # Simulate pipe moving out of screen
        self.game.update()
        self.assertEqual(self.game.score, 1, "Score should increase when passing through pipes")

    def test_scoring_system(self):
        # Functionality 4: Scoring System
        self.game.score = 0
        self.pipes[0].x = -51  # Simulate passing through a pipe
        self.game.update()
        self.assertEqual(self.game.score, 1, "Score should increase by one after passing a pipe")

        self.pipes[0].x = -51  # Simulate passing another pipe
        self.game.update()
        self.assertEqual(self.game.score, 2, "Score should continue to increase with each pass")

    def test_game_over_conditions(self):
        # Functionality 5: Game Over Conditions
        # Test collision with pipe
        self.bird.y = self.pipes[0].height - 10  # Position bird to collide with pipe
        self.assertTrue(self.game.check_collision(), "Game should end when bird collides with pipe")

        # Test falling to the ground
        self.bird.y = 601  # Position bird below the screen
        self.assertTrue(self.game.check_collision(), "Game should end when bird falls to the ground")

    def test_restart_game(self):
        # Functionality 6: Restart Game
        self.game.restart()
        self.assertEqual(self.game.score, 0, "Game should reset score to 0 on restart")
        self.assertEqual(self.bird.y, 250, "Bird should reset to starting position on restart")

    def test_high_score_storage(self):
        # Functionality 7: High Score Storage
        self.game.score = 5
        self.game.save_high_score()
        self.assertEqual(self.game.high_score, 5, "High score should be saved as 5")

        self.game.score = 3
        self.game.save_high_score()
        self.assertEqual(self.game.high_score, 5, "High score should remain 5 after scoring 3")

if __name__ == '__main__':
    unittest.main()
