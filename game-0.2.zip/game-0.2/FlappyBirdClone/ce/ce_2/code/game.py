import pygame
import random

class Bird:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.velocity = 0

    def flap(self):
        self.velocity = -10

    def update(self):
        self.velocity += 1
        self.y += self.velocity

    def draw(self, screen):
        pygame.draw.circle(screen, (255, 255, 0), (self.x, self.y), 15)

class Pipe:
    def __init__(self, x, height):
        self.x = x
        self.height = height

    def update(self):
        self.x -= 5

    def draw(self, screen):
        pygame.draw.rect(screen, (0, 255, 0), (self.x, 0, 50, self.height))
        pygame.draw.rect(screen, (0, 255, 0), (self.x, self.height + 150, 50, 600 - self.height - 150))

class Game:
    def __init__(self):
        self.bird = Bird(100, 250)
        self.pipes = []
        self.score = 0
        self.high_score = 0
        self.load_high_score()
        self.create_pipes()

    def create_pipes(self):
        for i in range(3):
            height = random.randint(100, 400)
            self.pipes.append(Pipe(400 + i * 200, height))

    def start_game(self):
        self.score = 0
        self.bird.y = 250
        self.bird.velocity = 0
        self.pipes.clear()
        self.create_pipes()

    def update(self):
        self.bird.update()
        for pipe in self.pipes:
            pipe.update()
            if pipe.x < -50:
                self.pipes.remove(pipe)
                self.score += 1
                height = random.randint(100, 400)
                self.pipes.append(Pipe(400, height))

    def draw(self, screen):
        screen.fill((135, 206, 250))
        self.bird.draw(screen)
        for pipe in self.pipes:
            pipe.draw(screen)
        font = pygame.font.SysFont(None, 36)
        score_text = font.render(f'Score: {self.score}', True, (255, 255, 255))
        screen.blit(score_text, (10, 10))

    def check_collision(self):
        if self.bird.y > 600 or self.bird.y < 0:
            return True
        for pipe in self.pipes:
            if (self.bird.x + 15 > pipe.x and self.bird.x - 15 < pipe.x + 50):
                if (self.bird.y < pipe.height or self.bird.y > pipe.height + 150):
                    return True
        return False

    def restart(self):
        self.start_game()

    def load_high_score(self):
        try:
            with open('high_scores.txt', 'r') as file:
                self.high_score = int(file.readline().strip())
        except (FileNotFoundError, ValueError):
            self.high_score = 0

    def save_high_score(self):
        if self.score > self.high_score:
            self.high_score = self.score
            with open('high_scores.txt', 'w') as file:
                file.write(str(self.high_score))