import unittest
import pygame
from game import Game
from puzzle_generator import PuzzleGenerator
from timer import Timer
from score import Score

class TestPuzzleGame(unittest.TestCase):

    def setUp(self):
        # Initialize the game and its components
        pygame.init()
        self.game = Game()
        self.puzzle_generator = self.game.puzzle_generator
        self.timer = self.game.timer
        self.score = self.game.score

    def test_select_puzzle_category(self):
        # Functionalities 1: Select Puzzle Category
        category = "logic"
        puzzles = self.puzzle_generator.load_puzzles(category)
        self.assertTrue(len(puzzles) > 0, "Puzzles should be loaded for the selected category")

    def test_generate_new_puzzle(self):
        # Functionalities 2: Generate a New Puzzle
        category = "logic"
        puzzle = self.puzzle_generator.generate_puzzle(category)
        self.assertIn("|", puzzle, "Generated puzzle should be in the correct format")

    def test_start_timer(self):
        # Functionalities 3: Start the Timer
        self.timer.start()
        elapsed_time = self.timer.get_elapsed_time()
        self.assertGreaterEqual(elapsed_time, 0, "Timer should start and show elapsed time")

    def test_calculate_player_score(self):
        # Functionalities 4: Calculate Player’s Score
        self.score.calculate_score(200, True)  # 200 seconds, correct solution
        self.assertGreater(self.score.get_score(), 0, "Score should be calculated based on time and correctness")

    def test_submit_solution(self):
        # Functionalities 5: Submit Solution
        self.game.current_puzzle = "What has keys but can't open locks?|A piano"
        self.game.submit_solution("A piano")
        self.assertEqual(self.score.get_score(), 100, "Score should reflect correct solution submission")

    def test_view_puzzle_feedback(self):
        # Functionalities 6: View Puzzle Feedback
        # Placeholder test as feedback display logic is not implemented
        self.fail("Feedback display logic is not implemented in the codebase")

    def test_timer_stops_on_solution_submission(self):
        # Functionalities 7: Timer Stops on Solution Submission
        self.timer.start()
        self.game.submit_solution("A piano")
        elapsed_time = self.timer.get_elapsed_time()
        self.assertGreaterEqual(elapsed_time, 0, "Timer should stop and record the time on solution submission")

    def test_load_puzzle_data_from_file(self):
        # Functionalities 8: Load Puzzle Data from File
        category = "logic"
        puzzles = self.puzzle_generator.load_puzzles(category)
        self.assertTrue(len(puzzles) > 0, "Puzzle data should be loaded from file")

    def test_validate_puzzle_solution_format(self):
        # Functionalities 9: Validate Puzzle Solution Format
        self.game.current_puzzle = "What comes next in the sequence: 1, 1, 2, 3, 5?|8"
        self.game.submit_solution("eight")
        self.assertNotEqual(self.score.get_score(), 100, "Solution format validation should fail for incorrect format")

if __name__ == '__main__':
    unittest.main()
