import random

class PuzzleGenerator:
    def load_puzzles(self, category: str) -> list:
        puzzles = []
        try:
            with open(f'puzzles/{category}_puzzles.txt', 'r') as file:
                for line in file:
                    puzzles.append(line.strip())
        except FileNotFoundError:
            print(f"No puzzles found for category: {category}")
        return puzzles

    def generate_puzzle(self, category: str) -> str:
        puzzles = self.load_puzzles(category)
        if puzzles:
            return random.choice(puzzles)
        return "No puzzles available."