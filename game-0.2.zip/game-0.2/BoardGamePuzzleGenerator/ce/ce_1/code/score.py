import json

class Score:
    def __init__(self):
        self.points = 0

    def calculate_score(self, time_taken: float, is_correct: bool) -> int:
        if is_correct:
            self.points = max(100 - int(time_taken), 0)
        else:
            self.points = 0
        return self.points

    def save_score(self, player_name: str, score: int) -> None:
        with open("scores.txt", 'a') as file:
            file.write(f"{player_name}|{score}\n")