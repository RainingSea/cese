import pygame
from puzzle_generator import PuzzleGenerator
from timer import Timer
from score import Score

class Game:
    def __init__(self):
        self.puzzle_generator = PuzzleGenerator()
        self.timer = Timer()
        self.score = Score()
        self.current_puzzle = ""
        self.is_game_running = False

    def start_game(self, category: str = "Logic Puzzles"):
        self.current_puzzle = self.puzzle_generator.generate_puzzle(category)
        self.timer.start()
        self.is_game_running = True
        self.display_game_screen()

    def submit_solution(self, solution: str) -> bool:
        is_correct = solution == self.current_puzzle
        self.display_feedback(is_correct)
        time_taken = self.timer.get_elapsed_time()
        score = self.score.calculate_score(time_taken, is_correct)
        self.score.save_score("Player", score)
        return is_correct

    def display_feedback(self, is_correct: bool) -> None:
        if is_correct:
            print("Correct!")
        else:
            print("Incorrect! Try again.")

    def display_game_screen(self):
        # Placeholder for game screen rendering logic
        print(f"Puzzle: {self.current_puzzle}")