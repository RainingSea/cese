import random
import json

class PuzzleGenerator:
    def __init__(self):
        self.puzzles = {
            "Logic Puzzles": self.load_puzzles("puzzles/logic_puzzles.txt"),
            "Pattern Recognition": self.load_puzzles("puzzles/pattern_recognition.txt"),
            "Spatial Puzzles": self.load_puzzles("puzzles/spatial_puzzles.txt")
        }

    def generate_puzzle(self, category: str) -> str:
        return random.choice(self.puzzles.get(category, []))

    def load_puzzles(self, file_path: str) -> list:
        with open(file_path, 'r') as file:
            return [line.strip() for line in file.readlines()]