import unittest
from game import Game
from puzzle_generator import PuzzleGenerator
from timer import Timer
from score import Score

class TestBoardGamePuzzleGenerator(unittest.TestCase):

    def setUp(self):
        # Initialize the game and its components
        self.game = Game()
        self.puzzle_generator = self.game.puzzle_generator
        self.timer = self.game.timer
        self.score = self.game.score

    def test_select_puzzle_category(self):
        # Functionalities 1: Select Puzzle Category
        category = "Logic Puzzles"
        self.game.start_game(category)
        self.assertEqual(self.game.current_puzzle in self.puzzle_generator.puzzles[category], True, 
                         "The puzzle should be from the selected category.")

    def test_generate_new_puzzle(self):
        # Functionalities 2: Generate a New Puzzle
        category = "Logic Puzzles"
        self.game.start_game(category)
        self.assertIsNotNone(self.game.current_puzzle, "A new puzzle should be generated and displayed.")

    def test_start_timer(self):
        # Functionalities 3: Start the Timer
        self.timer.start()
        self.assertGreater(self.timer.get_elapsed_time(), 0, "Timer should start counting up.")

    def test_calculate_player_score(self):
        # Functionalities 4: Calculate Player’s Score
        self.timer.start()
        self.timer.start_time -= 60  # Simulate 1 minute has passed
        is_correct = True
        score = self.score.calculate_score(self.timer.get_elapsed_time(), is_correct)
        self.assertEqual(score, 40, "Score should be calculated based on time and correctness.")

    def test_submit_solution(self):
        # Functionalities 5: Submit Solution
        category = "Logic Puzzles"
        self.game.start_game(category)
        solution = self.game.current_puzzle
        is_correct = self.game.submit_solution(solution)
        self.assertTrue(is_correct, "The solution should be correct.")

    def test_view_puzzle_feedback(self):
        # Functionalities 6: View Puzzle Feedback
        category = "Logic Puzzles"
        self.game.start_game(category)
        solution = self.game.current_puzzle
        is_correct = self.game.submit_solution(solution)
        self.assertTrue(is_correct, "Feedback should indicate the solution is correct.")

    def test_timer_stops_on_solution_submission(self):
        # Functionalities 7: Timer Stops on Solution Submission
        category = "Logic Puzzles"
        self.game.start_game(category)
        self.timer.start()
        solution = self.game.current_puzzle
        self.game.submit_solution(solution)
        elapsed_time = self.timer.get_elapsed_time()
        self.assertGreater(elapsed_time, 0, "Timer should stop and record the time taken.")

    def test_load_puzzle_data_from_file(self):
        # Functionalities 8: Load Puzzle Data from File
        try:
            puzzles = self.puzzle_generator.load_puzzles("puzzles/logic_puzzles.txt")
            self.assertGreater(len(puzzles), 0, "Puzzles should be loaded from the file.")
        except FileNotFoundError:
            self.fail("Puzzle file not found.")

    def test_validate_puzzle_solution_format(self):
        # Functionalities 9: Validate Puzzle Solution Format
        category = "Logic Puzzles"
        self.game.start_game(category)
        solution = 123  # Incorrect format
        is_correct = self.game.submit_solution(str(solution))
        self.assertFalse(is_correct, "The solution format should be flagged as incorrect.")

if __name__ == '__main__':
    unittest.main()
