from timer import Timer
from score import Score
from puzzle_generator import PuzzleGenerator

class Game:
    def __init__(self):
        self.puzzle_generator = PuzzleGenerator()
        self.timer = Timer()
        self.score = Score()

    def start_game(self, category: str) -> None:
        self.timer.start()
        self.current_puzzle = self.puzzle_generator.generate_puzzle(category)
        print(f"Puzzle: {self.current_puzzle}")

    def submit_solution(self, solution: str) -> str:
        correct = self.check_solution(solution)
        time_taken = self.timer.get_elapsed_time()
        self.score.calculate_score(time_taken, correct)
        return "Correct!" if correct else "Incorrect!"

    def check_solution(self, solution: str) -> bool:
        # Placeholder for actual solution checking logic
        return solution.lower() == "correct solution"  # Example logic

    def update_score(self) -> None:
        print(f"Current Score: {self.score.get_score()}")