import random

class PuzzleGenerator:
    def __init__(self):
        self.puzzles = {
            "Logic": [],
            "Pattern Recognition": [],
            "Spatial": []
        }
        self.load_puzzles()

    def load_puzzles(self) -> None:
        with open('puzzles/logic_puzzles.txt', 'r') as file:
            self.puzzles["Logic"] = [line.strip() for line in file.readlines()]

        with open('puzzles/pattern_recognition.txt', 'r') as file:
            self.puzzles["Pattern Recognition"] = [line.strip() for line in file.readlines()]

        with open('puzzles/spatial_puzzles.txt', 'r') as file:
            self.puzzles["Spatial"] = [line.strip() for line in file.readlines()]

    def generate_puzzle(self, category: str) -> str:
        return random.choice(self.puzzles[category]) if category in self.puzzles else ""