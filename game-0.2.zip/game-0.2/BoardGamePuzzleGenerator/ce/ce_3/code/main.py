from game import Game

def main() -> str:
    game = Game()
    category = input("Select puzzle category (Logic, Pattern Recognition, Spatial): ")
    game.start_game(category)
    while True:
        solution = input("Submit your solution: ")
        feedback = game.submit_solution(solution)
        print(feedback)
        game.update_score()

if __name__ == "__main__":
    main()