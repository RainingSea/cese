class Score:
    def __init__(self):
        self.points = 0

    def calculate_score(self, time_taken: float, correct: bool) -> int:
        if correct:
            self.points += max(0, 100 - int(time_taken * 10))  # Example scoring logic
        return self.points

    def get_score(self) -> int:
        return self.points