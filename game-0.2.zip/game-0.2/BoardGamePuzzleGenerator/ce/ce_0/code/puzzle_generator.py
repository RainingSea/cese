import random

class PuzzleGenerator:
    def __init__(self):
        self.puzzles = {
            "Logic": ["Puzzle 1", "Puzzle 2", "Puzzle 3"],
            "Pattern Recognition": ["Pattern 1", "Pattern 2", "Pattern 3"],
            "Spatial": ["Spatial 1", "Spatial 2", "Spatial 3"]
        }

    def generate_puzzle(self, category: str) -> str:
        return random.choice(self.puzzles.get(category, []))