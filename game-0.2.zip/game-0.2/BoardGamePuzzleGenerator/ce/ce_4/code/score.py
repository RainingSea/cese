class Score:
    def __init__(self):
        self.score = 0

    def calculate_score(self, time_taken: float, is_correct: bool) -> int:
        if is_correct:
            self.score = max(0, 100 - int(time_taken))
        else:
            self.score = 0
        return self.score

    def save_score(self, file_path: str) -> None:
        with open(file_path, 'a') as file:
            file.write(f"{self.score}\n")