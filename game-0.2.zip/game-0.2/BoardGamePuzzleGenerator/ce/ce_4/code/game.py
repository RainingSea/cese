import pygame
from puzzle_generator import PuzzleGenerator
from timer import Timer
from score import Score

class Game:
    def __init__(self):
        self.puzzle_generator = PuzzleGenerator()
        self.timer = Timer()
        self.score = Score()
        self.current_puzzle = ""
    
    def start_game(self, category: str) -> None:
        self.puzzle_generator.load_puzzles('puzzles.txt')
        self.current_puzzle = self.puzzle_generator.generate_puzzle(category)
        self.timer.start()
        self.run_game_loop()

    def submit_solution(self, solution: str) -> None:
        elapsed_time = self.timer.get_elapsed_time()
        is_correct = self.current_puzzle == solution
        self.score.calculate_score(elapsed_time, is_correct)
        self.score.save_score('scores.txt')
    
    def run_game_loop(self):
        # Placeholder for the game loop logic
        pass