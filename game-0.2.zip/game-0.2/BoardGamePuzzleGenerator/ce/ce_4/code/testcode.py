import unittest
from game import Game
from puzzle_generator import PuzzleGenerator
from timer import Timer
from score import Score

class TestBoardGamePuzzleGenerator(unittest.TestCase):

    def setUp(self):
        # Initialize the game and its components
        self.game = Game()
        self.puzzle_generator = self.game.puzzle_generator
        self.timer = self.game.timer
        self.score = self.game.score

    def test_select_puzzle_category(self):
        # Functionalities 1: Select Puzzle Category
        self.puzzle_generator.load_puzzles('puzzles.txt')
        category = "Logic Puzzles"
        self.game.start_game(category)
        self.assertIn(category, self.puzzle_generator.puzzles, "Category should be loaded and available")

    def test_generate_new_puzzle(self):
        # Functionalities 2: Generate a New Puzzle
        category = "Logic Puzzles"
        self.puzzle_generator.load_puzzles('puzzles.txt')
        puzzle = self.puzzle_generator.generate_puzzle(category)
        self.assertIn(puzzle, self.puzzle_generator.puzzles[category], "Generated puzzle should be from the selected category")

    def test_start_timer(self):
        # Functionalities 3: Start the Timer
        self.timer.start()
        self.assertGreater(self.timer.get_elapsed_time(), 0, "Timer should start and show elapsed time")

    def test_calculate_player_score(self):
        # Functionalities 4: Calculate Player’s Score
        self.timer.start()
        time.sleep(1)  # Simulate time taken to solve the puzzle
        elapsed_time = self.timer.get_elapsed_time()
        score = self.score.calculate_score(elapsed_time, True)
        self.assertEqual(score, max(0, 100 - int(elapsed_time)), "Score should be calculated based on time and correctness")

    def test_submit_solution(self):
        # Functionalities 5: Submit Solution
        self.game.current_puzzle = "What is 2 + 2?"
        self.game.submit_solution("4")
        self.assertEqual(self.score.score, 100, "Score should reflect correct solution submission")

    def test_view_puzzle_feedback(self):
        # Functionalities 6: View Puzzle Feedback (not implemented in codebase)
        self.fail("View puzzle feedback functionality is not implemented in the codebase")

    def test_timer_stops_on_solution_submission(self):
        # Functionalities 7: Timer Stops on Solution Submission
        self.timer.start()
        time.sleep(1)  # Simulate time taken to solve the puzzle
        self.game.submit_solution("4")
        elapsed_time = self.timer.get_elapsed_time()
        self.assertGreater(elapsed_time, 0, "Timer should stop and record the time taken")

    def test_load_puzzle_data_from_file(self):
        # Functionalities 8: Load Puzzle Data from File
        self.puzzle_generator.load_puzzles('puzzles.txt')
        self.assertTrue(self.puzzle_generator.puzzles, "Puzzle data should be loaded from file")

    def test_validate_puzzle_solution_format(self):
        # Functionalities 9: Validate Puzzle Solution Format (not implemented in codebase)
        self.fail("Validate puzzle solution format functionality is not implemented in the codebase")

if __name__ == '__main__':
    unittest.main()
