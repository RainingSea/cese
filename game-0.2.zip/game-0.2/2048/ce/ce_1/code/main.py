import pygame
import sys
from game import Game

# Constants
WINDOW_SIZE = 400
GRID_SIZE = 4
TILE_SIZE = WINDOW_SIZE // GRID_SIZE
BACKGROUND_COLOR = (187, 173, 160)
TILE_COLOR = (255, 255, 255)
FONT_COLOR = (0, 0, 0)

class Game2048:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((WINDOW_SIZE, WINDOW_SIZE))
        pygame.display.set_caption("2048")
        self.font = pygame.font.Font(None, 55)
        self.game = Game()
        self.run_game()

    def run_game(self):
        while True:
            self.handle_events()
            self.draw_board()
            pygame.display.flip()

    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    self.game.move('up')
                elif event.key == pygame.K_DOWN:
                    self.game.move('down')
                elif event.key == pygame.K_LEFT:
                    self.game.move('left')
                elif event.key == pygame.K_RIGHT:
                    self.game.move('right')

    def draw_board(self):
        self.screen.fill(BACKGROUND_COLOR)
        for i in range(GRID_SIZE):
            for j in range(GRID_SIZE):
                value = self.game.board[i][j]
                self.draw_tile(i, j, value)

        if self.game.game_over:
            self.display_game_over()

    def draw_tile(self, row, col, value):
        x = col * TILE_SIZE
        y = row * TILE_SIZE
        pygame.draw.rect(self.screen, TILE_COLOR, (x, y, TILE_SIZE, TILE_SIZE))
        if value != 0:
            text = self.font.render(str(value), True, FONT_COLOR)
            text_rect = text.get_rect(center=(x + TILE_SIZE // 2, y + TILE_SIZE // 2))
            self.screen.blit(text, text_rect)

    def display_game_over(self):
        game_over_text = self.font.render("Game Over", True, FONT_COLOR)
        text_rect = game_over_text.get_rect(center=(WINDOW_SIZE // 2, WINDOW_SIZE // 2))
        self.screen.blit(game_over_text, text_rect)

if __name__ == "__main__":
    Game2048()