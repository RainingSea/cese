import random

class Tile:
    def __init__(self, value: int):
        self._value = value

    def get_value(self) -> int:
        return self._value

class Game:
    def __init__(self):
        self._board = [[0] * 4 for _ in range(4)]
        self._score = 0
        self.add_new_tile()
        self.add_new_tile()

    def start_game(self) -> None:
        self._board = [[0] * 4 for _ in range(4)]
        self._score = 0
        self.add_new_tile()
        self.add_new_tile()

    def move(self, direction: str) -> None:
        if direction in ['up', 'down', 'left', 'right']:
            self.combine_tiles(direction)
            self.add_new_tile()

    def combine_tiles(self, direction: str) -> None:
        # Implement tile movement and merging logic based on direction
        pass  # Placeholder for actual implementation

    def add_new_tile(self) -> None:
        empty_tiles = [(i, j) for i in range(4) for j in range(4) if self._board[i][j] == 0]
        if empty_tiles:
            i, j = random.choice(empty_tiles)
            self._board[i][j] = 4 if random.random() < 0.1 else 2

    def check_game_over(self) -> bool:
        for row in self._board:
            if 0 in row:
                return False
        for i in range(4):
            for j in range(4):
                if (i < 3 and self._board[i][j] == self._board[i + 1][j]) or \
                   (j < 3 and self._board[i][j] == self._board[i][j + 1]):
                    return False
        return True

    def save_game_state(self, filename: str) -> None:
        with open(filename, 'w') as f:
            f.write(f"{self._score}\n")
            for row in self._board:
                f.write('|'.join(map(str, row)) + '\n')

    def load_game_state(self, filename: str) -> None:
        with open(filename, 'r') as f:
            self._score = int(f.readline().strip())
            for i in range(4):
                row = list(map(int, f.readline().strip().split('|')))
                self._board[i] = row