import unittest
from game import Game

class Test2048Game(unittest.TestCase):

    def setUp(self):
        # Initialize the game
        self.game = Game()

    def test_initialize_game_board(self):
        # Functionalities 1: Initialize Game Board
        self.game.start_game()
        non_zero_tiles = sum(tile != 0 for row in self.game._board for tile in row)
        self.assertEqual(non_zero_tiles, 2, "The game board should start with exactly two tiles.")

    def test_move_tiles_up(self):
        # Functionalities 2: Move Tiles Up
        self.game._board = [
            [2, 0, 0, 2],
            [2, 0, 0, 2],
            [0, 0, 0, 0],
            [0, 0, 0, 0]
        ]
        self.game.move('up')
        expected_board = [
            [4, 0, 0, 4],
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0]
        ]
        self.assertEqual(self.game._board, expected_board, "Tiles should combine and move up correctly.")

    def test_move_tiles_down(self):
        # Functionalities 3: Move Tiles Down
        self.game._board = [
            [2, 0, 0, 2],
            [2, 0, 0, 2],
            [0, 0, 0, 0],
            [0, 0, 0, 0]
        ]
        self.game.move('down')
        expected_board = [
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [4, 0, 0, 4],
            [0, 0, 0, 0]
        ]
        self.assertEqual(self.game._board, expected_board, "Tiles should combine and move down correctly.")

    def test_move_tiles_left(self):
        # Functionalities 4: Move Tiles Left
        self.game._board = [
            [2, 2, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [2, 2, 0, 0]
        ]
        self.game.move('left')
        expected_board = [
            [4, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [4, 0, 0, 0]
        ]
        self.assertEqual(self.game._board, expected_board, "Tiles should combine and move left correctly.")

    def test_move_tiles_right(self):
        # Functionalities 5: Move Tiles Right
        self.game._board = [
            [2, 2, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [2, 2, 0, 0]
        ]
        self.game.move('right')
        expected_board = [
            [0, 0, 0, 4],
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 4]
        ]
        self.assertEqual(self.game._board, expected_board, "Tiles should combine and move right correctly.")

    def test_generate_new_tile(self):
        # Functionalities 6: Generate New Tile
        self.game._board = [
            [2, 2, 2, 2],
            [2, 2, 2, 2],
            [2, 2, 2, 2],
            [2, 2, 2, 0]
        ]
        self.game.add_new_tile()
        non_zero_tiles = sum(tile != 0 for row in self.game._board for tile in row)
        self.assertEqual(non_zero_tiles, 16, "A new tile should be added to the board.")

    def test_check_game_over_condition(self):
        # Functionalities 7: Check Game Over Condition
        self.game._board = [
            [2, 4, 2, 4],
            [4, 2, 4, 2],
            [2, 4, 2, 4],
            [4, 2, 4, 2]
        ]
        self.assertTrue(self.game.check_game_over(), "The game should be over when no moves are possible.")

    def test_save_game_state(self):
        # Functionalities 8: Save Game State
        self.game._board = [
            [2, 4, 2, 4],
            [4, 2, 4, 2],
            [2, 4, 2, 4],
            [4, 2, 4, 2]
        ]
        self.game._score = 100
        self.game.save_game_state('test_game_state.txt')
        with open('test_game_state.txt', 'r') as f:
            content = f.read()
        expected_content = "100\n2|4|2|4\n4|2|4|2\n2|4|2|4\n4|2|4|2\n"
        self.assertEqual(content, expected_content, "Game state should be saved correctly.")

    def test_load_game_state(self):
        # Functionalities 9: Load Game State
        with open('test_game_state.txt', 'w') as f:
            f.write("100\n2|4|2|4\n4|2|4|2\n2|4|2|4\n4|2|4|2\n")
        self.game.load_game_state('test_game_state.txt')
        expected_board = [
            [2, 4, 2, 4],
            [4, 2, 4, 2],
            [2, 4, 2, 4],
            [4, 2, 4, 2]
        ]
        self.assertEqual(self.game._board, expected_board, "Game board should be loaded correctly.")
        self.assertEqual(self.game._score, 100, "Score should be loaded correctly.")

if __name__ == '__main__':
    unittest.main()
