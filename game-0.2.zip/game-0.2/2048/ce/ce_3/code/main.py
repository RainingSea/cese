import pygame
from game import Game

def main():
    pygame.init()
    screen = pygame.display.set_mode((400, 400))
    pygame.display.set_caption("2048 Game")
    clock = pygame.time.Clock()
    game = Game()
    
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                return
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    game.move('up')
                elif event.key == pygame.K_DOWN:
                    game.move('down')
                elif event.key == pygame.K_LEFT:
                    game.move('left')
                elif event.key == pygame.K_RIGHT:
                    game.move('right')

        screen.fill((255, 255, 255))
        draw_board(screen, game)
        pygame.display.flip()
        clock.tick(60)

def draw_board(screen, game):
    for i in range(4):
        for j in range(4):
            value = game._board[i][j]
            color = (200, 200, 200) if value == 0 else (255, 255, 255)
            pygame.draw.rect(screen, color, (j * 100, i * 100, 100, 100))
            if value != 0:
                font = pygame.font.Font(None, 74)
                text = font.render(str(value), True, (0, 0, 0))
                screen.blit(text, (j * 100 + 30, i * 100 + 20))

if __name__ == "__main__":
    main()