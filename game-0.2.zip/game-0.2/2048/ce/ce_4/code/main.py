import pygame
from game import Game

# Constants
SCREEN_WIDTH = 400
SCREEN_HEIGHT = 500
GRID_SIZE = 4
TILE_SIZE = 100
BACKGROUND_COLOR = (187, 173, 160)
TEXT_COLOR = (255, 255, 255)

def draw_board(screen, game: Game):
    screen.fill(BACKGROUND_COLOR)
    for i in range(GRID_SIZE):
        for j in range(GRID_SIZE):
            tile_value = game.board[i][j].get_value() if game.board[i][j] != 0 else 0
            pygame.draw.rect(screen, (205, 193, 180), (j * TILE_SIZE, i * TILE_SIZE, TILE_SIZE, TILE_SIZE))
            if tile_value != 0:
                font = pygame.font.Font(None, 74)
                text = font.render(str(tile_value), True, TEXT_COLOR)
                text_rect = text.get_rect(center=(j * TILE_SIZE + TILE_SIZE // 2, i * TILE_SIZE + TILE_SIZE // 2))
                screen.blit(text, text_rect)
    score_text = font.render(f'Score: {game.score}', True, TEXT_COLOR)
    screen.blit(score_text, (10, SCREEN_HEIGHT - 50))

def main():
    pygame.init()
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption('2048 Game')
    game = Game()

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    game.move('up')
                elif event.key == pygame.K_DOWN:
                    game.move('down')
                elif event.key == pygame.K_LEFT:
                    game.move('left')
                elif event.key == pygame.K_RIGHT:
                    game.move('right')

        draw_board(screen, game)
        pygame.display.flip()

    pygame.quit()

if __name__ == '__main__':
    main()