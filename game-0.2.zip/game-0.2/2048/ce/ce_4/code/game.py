import random

class Tile:
    def __init__(self, value: int):
        self._value = value

    def get_value(self) -> int:
        return self._value

class Game:
    def __init__(self):
        self.board = [[0] * 4 for _ in range(4)]
        self.score = 0
        self.start_game()

    def start_game(self) -> None:
        self.generate_tile()
        self.generate_tile()

    def move(self, direction: str) -> None:
        if direction == 'up':
            self._move_up()
        elif direction == 'down':
            self._move_down()
        elif direction == 'left':
            self._move_left()
        elif direction == 'right':
            self._move_right()
        self.generate_tile()
        if self.check_game_over():
            print("Game Over!")

    def generate_tile(self) -> None:
        empty_tiles = [(i, j) for i in range(4) for j in range(4) if self.board[i][j] == 0]
        if empty_tiles:
            i, j = random.choice(empty_tiles)
            self.board[i][j] = Tile(random.choice([2, 4]))

    def check_game_over(self) -> bool:
        if any(0 in row for row in self.board):
            return False
        for i in range(4):
            for j in range(4):
                if (i < 3 and self.board[i][j].get_value() == self.board[i + 1][j].get_value()) or \
                   (j < 3 and self.board[i][j].get_value() == self.board[i][j + 1].get_value()):
                    return False
        return True

    def save_game_state(self) -> None:
        with open('game_state.txt', 'w') as f:
            for row in self.board:
                f.write('|'.join(str(tile.get_value()) if tile else '0' for tile in row) + '\n')
            f.write(str(self.score) + '\n')

    def load_game_state(self) -> None:
        with open('game_state.txt', 'r') as f:
            lines = f.readlines()
            for i in range(4):
                values = list(map(int, lines[i].strip().split('|')))
                self.board[i] = [Tile(value) if value != 0 else 0 for value in values]
            self.score = int(lines[4].strip())

    def display(self) -> None:
        for row in self.board:
            print(' | '.join(str(tile.get_value()) if tile else '0' for tile in row))
        print(f'Score: {self.score}')

    def _move_up(self) -> None:
        for j in range(4):
            stack = []
            for i in range(4):
                if self.board[i][j] != 0:
                    stack.append(self.board[i][j])
            self._merge(stack)
            for i in range(4):
                self.board[i][j] = stack[i] if i < len(stack) else 0

    def _move_down(self) -> None:
        for j in range(4):
            stack = []
            for i in range(3, -1, -1):
                if self.board[i][j] != 0:
                    stack.append(self.board[i][j])
            self._merge(stack)
            for i in range(4):
                self.board[3 - i][j] = stack[i] if i < len(stack) else 0

    def _move_left(self) -> None:
        for i in range(4):
            stack = []
            for j in range(4):
                if self.board[i][j] != 0:
                    stack.append(self.board[i][j])
            self._merge(stack)
            for j in range(4):
                self.board[i][j] = stack[j] if j < len(stack) else 0

    def _move_right(self) -> None:
        for i in range(4):
            stack = []
            for j in range(3, -1, -1):
                if self.board[i][j] != 0:
                    stack.append(self.board[i][j])
            self._merge(stack)
            for j in range(4):
                self.board[i][3 - j] = stack[j] if j < len(stack) else 0

    def _merge(self, stack: list) -> None:
        merged = []
        skip = False
        for i in range(len(stack)):
            if skip:
                skip = False
                continue
            if i + 1 < len(stack) and stack[i].get_value() == stack[i + 1].get_value():
                merged.append(Tile(stack[i].get_value() * 2))
                self.score += stack[i].get_value() * 2
                skip = True
            else:
                merged.append(stack[i])
        stack.clear()
        stack.extend(merged)