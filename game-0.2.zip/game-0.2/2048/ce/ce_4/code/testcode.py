import unittest
from game import Game, Tile

class Test2048Game(unittest.TestCase):

    def setUp(self):
        # Initialize the game
        self.game = Game()

    def test_initialize_game_board(self):
        # Functionalities 1: Initialize Game Board
        non_empty_tiles = sum(tile != 0 for row in self.game.board for tile in row)
        self.assertEqual(non_empty_tiles, 2, "The game board should start with exactly two tiles.")

    def test_move_tiles_up(self):
        # Functionalities 2: Move Tiles Up
        self.game.board = [
            [Tile(2), 0, 0, 0],
            [Tile(2), 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0]
        ]
        self.game.move('up')
        self.assertEqual(self.game.board[0][0].get_value(), 4, "Tiles should combine to form 4.")
        self.assertEqual(self.game.board[1][0], 0, "The second row should be empty after moving up.")

    def test_move_tiles_down(self):
        # Functionalities 3: Move Tiles Down
        self.game.board = [
            [Tile(2), 0, 0, 0],
            [Tile(2), 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0]
        ]
        self.game.move('down')
        self.assertEqual(self.game.board[3][0].get_value(), 4, "Tiles should combine to form 4.")
        self.assertEqual(self.game.board[2][0], 0, "The third row should be empty after moving down.")

    def test_move_tiles_left(self):
        # Functionalities 4: Move Tiles Left
        self.game.board = [
            [0, Tile(2), Tile(2), 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0]
        ]
        self.game.move('left')
        self.assertEqual(self.game.board[0][0].get_value(), 4, "Tiles should combine to form 4.")
        self.assertEqual(self.game.board[0][1], 0, "The second column should be empty after moving left.")

    def test_move_tiles_right(self):
        # Functionalities 5: Move Tiles Right
        self.game.board = [
            [0, Tile(2), Tile(2), 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0]
        ]
        self.game.move('right')
        self.assertEqual(self.game.board[0][3].get_value(), 4, "Tiles should combine to form 4.")
        self.assertEqual(self.game.board[0][2], 0, "The third column should be empty after moving right.")

    def test_generate_new_tile(self):
        # Functionalities 6: Generate New Tile
        self.game.board = [
            [Tile(2), Tile(4), Tile(8), Tile(16)],
            [Tile(32), Tile(64), Tile(128), Tile(256)],
            [Tile(512), Tile(1024), Tile(2048), 0],
            [0, 0, 0, 0]
        ]
        self.game.move('right')
        non_empty_tiles = sum(tile != 0 for row in self.game.board for tile in row)
        self.assertEqual(non_empty_tiles, 14, "A new tile should be generated after a move.")

    def test_check_game_over_condition(self):
        # Functionalities 7: Check Game Over Condition
        self.game.board = [
            [Tile(2), Tile(4), Tile(2), Tile(4)],
            [Tile(4), Tile(2), Tile(4), Tile(2)],
            [Tile(2), Tile(4), Tile(2), Tile(4)],
            [Tile(4), Tile(2), Tile(4), Tile(2)]
        ]
        self.assertTrue(self.game.check_game_over(), "The game should be over when no moves are possible.")

    def test_save_game_state(self):
        # Functionalities 8: Save Game State
        self.game.board = [
            [Tile(2), Tile(4), Tile(8), Tile(16)],
            [Tile(32), Tile(64), Tile(128), Tile(256)],
            [Tile(512), Tile(1024), Tile(2048), 0],
            [0, 0, 0, 0]
        ]
        self.game.save_game_state()
        with open('game_state.txt', 'r') as f:
            lines = f.readlines()
        self.assertEqual(lines[0].strip(), "2|4|8|16", "The first row should match the saved state.")
        self.assertEqual(lines[4].strip(), "0", "The score should be saved as 0 initially.")

    def test_load_game_state(self):
        # Functionalities 9: Load Game State
        with open('game_state.txt', 'w') as f:
            f.write("2|4|8|16\n32|64|128|256\n512|1024|2048|0\n0|0|0|0\n0\n")
        self.game.load_game_state()
        self.assertEqual(self.game.board[0][0].get_value(), 2, "The first tile should be 2 after loading.")
        self.assertEqual(self.game.board[2][2].get_value(), 2048, "The tile should be 2048 after loading.")
        self.assertEqual(self.game.score, 0, "The score should be 0 after loading.")

if __name__ == '__main__':
    unittest.main()
