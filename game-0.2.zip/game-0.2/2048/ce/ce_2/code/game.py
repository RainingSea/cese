import json
import random
from tile import Tile

class Game:
    def __init__(self):
        self._board = [[0] * 4 for _ in range(4)]
        self._score = 0
        self.generate_tile()
        self.generate_tile()

    def start_game(self) -> None:
        self._board = [[0] * 4 for _ in range(4)]
        self._score = 0
        self.generate_tile()
        self.generate_tile()

    def move(self, direction: str) -> None:
        if direction == 'up':
            self._move_up()
        elif direction == 'down':
            self._move_down()
        elif direction == 'left':
            self._move_left()
        elif direction == 'right':
            self._move_right()
        self.generate_tile()

    def generate_tile(self) -> None:
        empty_tiles = [(i, j) for i in range(4) for j in range(4) if self._board[i][j] == 0]
        if empty_tiles:
            i, j = random.choice(empty_tiles)
            self._board[i][j] = Tile(2 if random.random() < 0.9 else 4)

    def check_game_over(self) -> bool:
        if any(0 in row for row in self._board):
            return False
        for i in range(4):
            for j in range(4):
                if (i < 3 and self._board[i][j] == self._board[i + 1][j]) or (j < 3 and self._board[i][j] == self._board[i][j + 1]):
                    return False
        return True

    def save_game_state(self) -> None:
        game_state = {
            'board': [[tile.get_value() for tile in row] for row in self._board],
            'score': self._score
        }
        with open('game_state.txt', 'w') as f:
            json.dump(game_state, f)

    def load_game_state(self) -> None:
        try:
            with open('game_state.txt', 'r') as f:
                game_state = json.load(f)
                self._board = [[Tile(value) for value in row] for row in game_state['board']]
                self._score = game_state['score']
        except FileNotFoundError:
            self.start_game()

    def _move_up(self) -> None:
        for j in range(4):
            stack = []
            for i in range(4):
                if self._board[i][j] != 0:
                    stack.append(self._board[i][j])
            self._merge(stack)
            for i in range(4):
                self._board[i][j] = stack[i] if i < len(stack) else 0

    def _move_down(self) -> None:
        for j in range(4):
            stack = []
            for i in range(3, -1, -1):
                if self._board[i][j] != 0:
                    stack.append(self._board[i][j])
            self._merge(stack)
            for i in range(3, -1, -1):
                self._board[i][j] = stack[3 - i] if 3 - i < len(stack) else 0

    def _move_left(self) -> None:
        for i in range(4):
            stack = []
            for j in range(4):
                if self._board[i][j] != 0:
                    stack.append(self._board[i][j])
            self._merge(stack)
            for j in range(4):
                self._board[i][j] = stack[j] if j < len(stack) else 0

    def _move_right(self) -> None:
        for i in range(4):
            stack = []
            for j in range(3, -1, -1):
                if self._board[i][j] != 0:
                    stack.append(self._board[i][j])
            self._merge(stack)
            for j in range(3, -1, -1):
                self._board[i][j] = stack[3 - j] if 3 - j < len(stack) else 0

    def _merge(self, stack: list) -> None:
        for i in range(len(stack) - 1):
            if stack[i].get_value() == stack[i + 1].get_value():
                new_value = stack[i].get_value() * 2
                self._score += new_value
                stack[i] = Tile(new_value)
                stack[i + 1] = Tile(0)
        stack[:] = [tile for tile in stack if tile.get_value() != 0]