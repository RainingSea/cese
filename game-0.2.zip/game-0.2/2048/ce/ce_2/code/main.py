import pygame
import sys
from game import Game

# Constants
WINDOW_SIZE = 400
GRID_SIZE = 4
TILE_SIZE = WINDOW_SIZE // GRID_SIZE
BACKGROUND_COLOR = (187, 173, 160)
TEXT_COLOR = (255, 255, 255)

def draw_board(screen, game):
    screen.fill(BACKGROUND_COLOR)
    for i in range(GRID_SIZE):
        for j in range(GRID_SIZE):
            tile_value = game._board[i][j].get_value()
            if tile_value != 0:
                pygame.draw.rect(screen, (255, 255, 255), (j * TILE_SIZE, i * TILE_SIZE, TILE_SIZE, TILE_SIZE))
                font = pygame.font.Font(None, 74)
                text = font.render(str(tile_value), True, TEXT_COLOR)
                text_rect = text.get_rect(center=(j * TILE_SIZE + TILE_SIZE // 2, i * TILE_SIZE + TILE_SIZE // 2))
                screen.blit(text, text_rect)

def main():
    pygame.init()
    screen = pygame.display.set_mode((WINDOW_SIZE, WINDOW_SIZE))
    pygame.display.set_caption('2048 Game')
    game = Game()
    game.load_game_state()

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                game.save_game_state()
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    game.move('up')
                elif event.key == pygame.K_DOWN:
                    game.move('down')
                elif event.key == pygame.K_LEFT:
                    game.move('left')
                elif event.key == pygame.K_RIGHT:
                    game.move('right')

        draw_board(screen, game)
        pygame.display.flip()

if __name__ == '__main__':
    main()