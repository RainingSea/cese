[OUTPUT]
## general overview of the project
Design a simple 2048 game.

## software functional requirements
1. The game board must be divided into a 4x4 grid.
2. Players must be able to control the game using the arrow keys on the keyboard.
3. The system must automatically generate two random tiles ("2" or "4") on the board at the start of the game.
4. Tiles must move in the direction pressed (up, down, left, or right) and combine according to the game rules.
5. A new tile ("2" or "4") must be generated in an empty cell after each valid move.
6. The system must detect and display a "Game Over" message when no more moves are possible.
7. The system must save the current game state (board layout and score) to a local text file.
8. The system must load a saved game state from a local text file to continue gameplay.
9. The system must keep track of the player's score during the game.
[/OUTPUT]