import unittest
from game import Game

class Test2048Game(unittest.TestCase):

    def setUp(self):
        # Initialize the game
        self.game = Game()

    def test_initialize_game_board(self):
        # Functionalities 1: Initialize Game Board
        self.game.start_game()
        non_empty_tiles = sum(tile != 0 for row in self.game.board for tile in row)
        self.assertEqual(non_empty_tiles, 2, "Game board should start with exactly two non-empty tiles")

    def test_move_tiles_up(self):
        # Functionalities 2: Move Tiles Up
        self.game.board = [
            [2, 0, 0, 2],
            [2, 0, 0, 2],
            [0, 0, 0, 0],
            [0, 0, 0, 0]
        ]
        self.game.move('up')
        expected_board = [
            [4, 0, 0, 4],
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0]
        ]
        self.assertEqual(self.game.board, expected_board, "Tiles should combine and move up correctly")

    def test_move_tiles_down(self):
        # Functionalities 3: Move Tiles Down
        self.game.board = [
            [2, 0, 0, 2],
            [2, 0, 0, 2],
            [0, 0, 0, 0],
            [0, 0, 0, 0]
        ]
        self.game.move('down')
        expected_board = [
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [4, 0, 0, 4]
        ]
        self.assertEqual(self.game.board, expected_board, "Tiles should combine and move down correctly")

    def test_move_tiles_left(self):
        # Functionalities 4: Move Tiles Left
        self.game.board = [
            [2, 2, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [2, 2, 0, 0]
        ]
        self.game.move('left')
        expected_board = [
            [4, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [4, 0, 0, 0]
        ]
        self.assertEqual(self.game.board, expected_board, "Tiles should combine and move left correctly")

    def test_move_tiles_right(self):
        # Functionalities 5: Move Tiles Right
        self.game.board = [
            [0, 0, 2, 2],
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 2, 2]
        ]
        self.game.move('right')
        expected_board = [
            [0, 0, 0, 4],
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 4]
        ]
        self.assertEqual(self.game.board, expected_board, "Tiles should combine and move right correctly")

    def test_generate_new_tile(self):
        # Functionalities 6: Generate New Tile
        self.game.board = [
            [2, 2, 2, 2],
            [2, 2, 2, 2],
            [2, 2, 2, 2],
            [2, 2, 2, 0]
        ]
        self.game.generate_tile()
        non_empty_tiles = sum(tile != 0 for row in self.game.board for tile in row)
        self.assertEqual(non_empty_tiles, 16, "A new tile should be generated in an empty space")

    def test_check_game_over(self):
        # Functionalities 7: Check Game Over Condition
        self.game.board = [
            [2, 4, 2, 4],
            [4, 2, 4, 2],
            [2, 4, 2, 4],
            [4, 2, 4, 2]
        ]
        game_over = self.game.check_game_over()
        self.assertTrue(game_over, "Game should be over when no moves are possible")

    def test_save_game_state(self):
        # Functionalities 8: Save Game State
        self.game.board = [
            [2, 0, 0, 2],
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0]
        ]
        self.game.score = 4
        self.game.save_game('test_save.txt')
        with open('test_save.txt', 'r') as f:
            saved_data = f.read()
        expected_data = "2|0|0|2\n0|0|0|0\n0|0|0|0\n0|0|0|0\n4\n"
        self.assertEqual(saved_data, expected_data, "Game state should be saved correctly")

    def test_load_game_state(self):
        # Functionalities 9: Load Game State
        with open('test_load.txt', 'w') as f:
            f.write("2|0|0|2\n0|0|0|0\n0|0|0|0\n0|0|0|0\n4\n")
        self.game.load_game('test_load.txt')
        expected_board = [
            [2, 0, 0, 2],
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0]
        ]
        self.assertEqual(self.game.board, expected_board, "Game board should be loaded correctly")
        self.assertEqual(self.game.score, 4, "Game score should be loaded correctly")

if __name__ == '__main__':
    unittest.main()
