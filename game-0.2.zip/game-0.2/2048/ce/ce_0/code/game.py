import random

class Tile:
    def __init__(self, value: int):
        self.value = value

    def draw(self):
        # Placeholder for drawing the tile, to be implemented in the UI
        pass

class Game:
    def __init__(self):
        self.board = [[0] * 4 for _ in range(4)]
        self.score = 0
        self.game_over = False
        self.generate_tile()
        self.generate_tile()

    def start_game(self) -> None:
        self.board = [[0] * 4 for _ in range(4)]
        self.score = 0
        self.game_over = False
        self.generate_tile()
        self.generate_tile()

    def move(self, direction: str) -> None:
        # Implement the logic for moving tiles in the specified direction
        pass

    def generate_tile(self) -> None:
        empty_tiles = [(i, j) for i in range(4) for j in range(4) if self.board[i][j] == 0]
        if empty_tiles:
            i, j = random.choice(empty_tiles)
            self.board[i][j] = 2 if random.random() < 0.9 else 4

    def check_game_over(self) -> bool:
        if any(0 in row for row in self.board):
            return False
        for i in range(4):
            for j in range(4):
                if (i < 3 and self.board[i][j] == self.board[i + 1][j]) or (j < 3 and self.board[i][j] == self.board[i][j + 1]):
                    return False
        self.game_over = True
        return True

    def save_game(self, filename: str) -> None:
        with open(filename, 'w') as f:
            for row in self.board:
                f.write('|'.join(map(str, row)) + '\n')
            f.write(str(self.score) + '\n')

    def load_game(self, filename: str) -> None:
        with open(filename, 'r') as f:
            lines = f.readlines()
            self.board = [list(map(int, line.strip().split('|'))) for line in lines[:-1]]
            self.score = int(lines[-1].strip())

    def draw_board(self) -> None:
        # Placeholder for drawing the board, to be implemented in the UI
        pass