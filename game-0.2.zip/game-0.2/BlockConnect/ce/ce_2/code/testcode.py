import unittest
import os
import json
from game import Game, Block

class TestBlockConnectGame(unittest.TestCase):

    def setUp(self):
        # Initialize the game
        self.game = Game()

    def test_select_and_connect_blocks(self):
        # Functionalities 1: Select and Connect Blocks of the Same Color
        # Simulate selecting blocks and clearing them
        self.game.select_block(0, 0)
        self.game.select_block(0, 1)
        self.game.clear_blocks()
        # Check if the blocks are cleared (assuming clear_blocks updates the grid)
        blocks = self.game.grid.get_blocks()
        self.assertNotEqual(blocks[0][0].color, "red", "Block should be cleared")
        self.assertNotEqual(blocks[0][1].color, "red", "Block should be cleared")

    def test_display_game_grid(self):
        # Functionalities 2: Display the Game Grid
        # Check if the grid is initialized with blocks
        blocks = self.game.grid.get_blocks()
        self.assertEqual(len(blocks), 10, "Grid should have 10 rows")
        self.assertEqual(len(blocks[0]), 10, "Grid should have 10 columns")

    def test_score_calculation_after_block_clearing(self):
        # Functionalities 3: Score Calculation After Block Clearing
        initial_score = self.game.score.get_score()
        self.game.select_block(0, 0)
        self.game.select_block(0, 1)
        self.game.select_block(0, 2)
        self.game.clear_blocks()
        new_score = self.game.score.get_score()
        self.assertEqual(new_score, initial_score + 3, "Score should increase by 3 points")

    def test_blocks_fall_to_occupy_spaces(self):
        # Functionalities 4: Blocks Fall to Occupy Spaces
        self.game.select_block(0, 0)
        self.game.clear_blocks()
        self.game.fall_blocks()
        # Check if blocks have fallen (assuming fall_blocks updates the grid)
        blocks = self.game.grid.get_blocks()
        self.assertNotEqual(blocks[0][0].color, "red", "Block should have fallen")

    def test_undo_last_move(self):
        # Functionalities 5: Undo Last Move
        self.game.select_block(0, 0)
        self.game.clear_blocks()
        self.game.undo_move()
        # Check if the move was undone (assuming undo_move restores the grid)
        blocks = self.game.grid.get_blocks()
        self.assertEqual(blocks[0][0].color, "red", "Block should be restored")

    def test_save_game_state(self):
        # Functionalities 6: Save Game State to a Local File
        self.game.save_state()
        self.assertTrue(os.path.exists('game_state.txt'), "Game state file should exist")

    def test_load_game_state(self):
        # Functionalities 7: Load Game State from a Local File
        self.game.save_state()
        self.game.grid.blocks[0][0] = Block("blue")  # Change a block color
        self.game.load_state()
        blocks = self.game.grid.get_blocks()
        self.assertEqual(blocks[0][0].color, "red", "Block color should be restored from saved state")

if __name__ == '__main__':
    unittest.main()
