import pygame
from game import Game

class GameUI:
    def __init__(self, game: Game):
        self.game = game
        self.screen = pygame.display.set_mode((400, 400))
        pygame.display.set_caption('Block Connect Puzzle')

    def draw_grid(self):
        for row in range(len(self.game.grid)):
            for col in range(len(self.game.grid[row])):
                block = self.game.grid[row][col]
                pygame.draw.rect(self.screen, self.get_color(block.color), (col * 80, row * 80, 80, 80))

    def draw_score(self, score: int):
        font = pygame.font.Font(None, 36)
        text = font.render(f'Score: {score}', True, (255, 255, 255))
        self.screen.blit(text, (10, 10))

    def draw_undo_button(self):
        font = pygame.font.Font(None, 36)
        text = font.render('Undo', True, (255, 255, 255))
        self.screen.blit(text, (320, 10))

    def handle_click(self, position: tuple):
        # Logic to handle user clicks
        pass

    def get_color(self, color: str):
        colors = {
            'red': (255, 0, 0),
            'green': (0, 255, 0),
            'blue': (0, 0, 255),
            'yellow': (255, 255, 0),
            'purple': (128, 0, 128)
        }
        return colors.get(color, (255, 255, 255))