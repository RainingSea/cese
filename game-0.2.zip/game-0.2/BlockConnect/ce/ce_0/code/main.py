import pygame
from game import Game
from ui import GameUI

def main():
    pygame.init()
    game = Game()
    game_ui = GameUI(game)
    
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                position = pygame.mouse.get_pos()
                game_ui.handle_click(position)

        game_ui.screen.fill((0, 0, 0))
        game_ui.draw_grid()
        game_ui.draw_score(game.score)
        game_ui.draw_undo_button()
        pygame.display.flip()

    game.save_game_state()
    pygame.quit()

if __name__ == '__main__':
    main()