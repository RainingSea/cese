import pygame
from typing import List

class Block:
    def __init__(self, color: str) -> None:
        self.color = color

class Move:
    def __init__(self, action: str, blocks: List[Block]) -> None:
        self.action = action
        self.blocks = blocks

class Score:
    def __init__(self) -> None:
        self.score = 0

    def add_points(self, points: int) -> None:
        self.score += points

    def get_score(self) -> int:
        return self.score

class Grid:
    def __init__(self, width: int, height: int) -> None:
        self.blocks = [[Block("white") for _ in range(width)] for _ in range(height)]

    def initialize_grid(self) -> None:
        for row in self.blocks:
            for block in row:
                block.color = "white"

    def get_block(self, x: int, y: int) -> Block:
        return self.blocks[y][x]

    def remove_blocks(self, blocks: List[Block]) -> None:
        for block in blocks:
            block.color = "white"

    def update_grid(self) -> None:
        # Logic to update the grid after blocks are removed
        pass

class Game:
    def __init__(self) -> None:
        self.grid = Grid(10, 10)
        self.score = Score()
        self.move_history = []

    def start_game(self) -> None:
        self.grid.initialize_grid()

    def select_block(self, x: int, y: int) -> None:
        block = self.grid.get_block(x, y)
        # Logic for selecting a block
        pass

    def clear_blocks(self) -> None:
        # Logic to clear selected blocks
        pass

    def fall_blocks(self) -> None:
        # Logic to make blocks fall down
        pass

    def undo_move(self) -> None:
        if self.move_history:
            last_move = self.move_history.pop()
            # Logic to undo the last move
            pass

    def save_high_score(self, score: int) -> None:
        with open('high_scores.txt', 'a') as f:
            f.write(f"{score}\n")

    def load_high_scores(self) -> List[int]:
        try:
            with open('high_scores.txt', 'r') as f:
                return [int(line.strip()) for line in f.readlines()]
        except FileNotFoundError:
            return []