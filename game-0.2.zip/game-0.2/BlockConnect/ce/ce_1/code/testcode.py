import unittest
import pygame
from game import Game

class TestBlockConnectGame(unittest.TestCase):

    def setUp(self):
        # Initialize the game
        self.game = Game()
        self.game.start_game()

    def test_select_and_connect_blocks(self):
        # Functionalities 1: Select and Connect Blocks of the Same Color
        # Select a block and simulate connected blocks
        self.game.grid.blocks[0][0].color = 'red'
        self.game.grid.blocks[0][1].color = 'red'
        self.game.grid.blocks[0][2].color = 'red'
        
        self.game.grid.get_connected_blocks = lambda x, y: [(0, 0), (0, 1), (0, 2)]
        self.game.select_block(0, 0)
        
        # Check if the blocks are cleared
        self.assertNotEqual(self.game.grid.blocks[0][0].color, 'red')
        self.assertNotEqual(self.game.grid.blocks[0][1].color, 'red')
        self.assertNotEqual(self.game.grid.blocks[0][2].color, 'red')

    def test_display_game_grid(self):
        # Functionalities 2: Display the Game Grid
        # Check if the grid is initialized with blocks
        self.assertEqual(len(self.game.grid.blocks), 10)
        self.assertEqual(len(self.game.grid.blocks[0]), 10)

    def test_score_calculation_after_block_clearing(self):
        # Functionalities 3: Score Calculation After Block Clearing
        initial_score = self.game.score.get_score()
        
        # Simulate clearing of three blocks
        self.game.clear_blocks([(0, 0), (0, 1), (0, 2)])
        
        # Check if the score increased by 30 points (3 blocks * 10 points each)
        self.assertEqual(self.game.score.get_score(), initial_score + 30)

    def test_blocks_fall_to_occupy_spaces(self):
        # Functionalities 4: Blocks Fall to Occupy Spaces
        # This functionality is not implemented in the codebase
        self.fail("Blocks fall logic is not implemented in the codebase")

    def test_undo_last_move(self):
        # Functionalities 5: Undo Last Move
        # Simulate a move and then undo it
        self.game.grid.blocks[0][0].color = 'red'
        self.game.grid.blocks[0][1].color = 'red'
        self.game.grid.blocks[0][2].color = 'red'
        
        self.game.grid.get_connected_blocks = lambda x, y: [(0, 0), (0, 1), (0, 2)]
        self.game.select_block(0, 0)
        
        # Undo the move
        self.game.undo_move()
        
        # Check if the blocks are restored
        self.assertEqual(self.game.grid.blocks[0][0].color, 'red')
        self.assertEqual(self.game.grid.blocks[0][1].color, 'red')
        self.assertEqual(self.game.grid.blocks[0][2].color, 'red')

    def test_save_game_state(self):
        # Functionalities 6: Save Game State to a Local File
        self.game.save_game_state()
        
        # Check if the file is created and contains the correct score
        with open('game_state.txt', 'r') as f:
            lines = f.readlines()
            self.assertEqual(lines[0].strip(), f"Score: {self.game.score.get_score()}")

    def test_load_game_state(self):
        # Functionalities 7: Load Game State from a Local File
        # Save the current state
        self.game.save_game_state()
        
        # Modify the score and load the saved state
        self.game.score.increment(50)
        self.game.load_game_state()
        
        # Check if the score is restored
        with open('game_state.txt', 'r') as f:
            lines = f.readlines()
            saved_score = int(lines[0].split(': ')[1])
            self.assertEqual(self.game.score.get_score(), saved_score)

if __name__ == '__main__':
    unittest.main()
