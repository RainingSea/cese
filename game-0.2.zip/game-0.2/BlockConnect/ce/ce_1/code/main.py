import pygame
from game import Game

def main() -> None:
    pygame.init()
    screen = pygame.display.set_mode((800, 600))
    pygame.display.set_caption("Block Connect Puzzle Game")

    game = Game()
    game.start_game()

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                x, y = event.pos
                game.select_block(x // 60, y // 60)  # Assuming each block is 60x60 pixels

        screen.fill((255, 255, 255))
        # Draw game grid and score
        pygame.display.flip()

    game.save_game_state()
    pygame.quit()

if __name__ == "__main__":
    main()