from grid import Grid
from player import Player
from enemy import Enemy

class Game:
    def __init__(self):
        self.grid = Grid(13)
        self.player = Player(health=3)
        self.enemies = [Enemy(health=1, x=1, y=1), Enemy(health=1, x=2, y=2)]
        self.score = 0
        self.player_health = self.player.health

    def run(self) -> None:
        while True:
            self.handle_input()
            self.update()
            self.draw()

    def update(self) -> None:
        for enemy in self.enemies:
            enemy.move()

    def draw(self) -> None:
        self.grid.draw()
        print(f"Player position: ({self.player.x}, {self.player.y})")
        print(f"Score: {self.score}, Player Health: {self.player_health}")

    def handle_input(self) -> None:
        direction = input("Enter direction (up, down, left, right): ")
        self.player.move(direction)

    def check_collisions(self) -> None:
        # Collision logic to be implemented
        pass

    def save_game_state(self) -> None:
        with open('game_state.txt', 'w') as f:
            f.write(f"score|{self.score}\n")
            f.write(f"player_health|{self.player_health}\n")

    def load_game_state(self) -> None:
        try:
            with open('game_state.txt', 'r') as f:
                for line in f:
                    key, value = line.strip().split('|')
                    if key == 'score':
                        self.score = int(value)
                    elif key == 'player_health':
                        self.player_health = int(value)
        except FileNotFoundError:
            print("No saved game state found.")