class Enemy:
    def __init__(self, health: int, x: int, y: int):
        self.health = health
        self.x = x
        self.y = y

    def move(self) -> None:
        import random
        direction = random.choice(['up', 'down', 'left', 'right'])
        if direction == 'up' and self.x > 0:
            self.x -= 1
        elif direction == 'down' and self.x < 12:
            self.x += 1
        elif direction == 'left' and self.y > 0:
            self.y -= 1
        elif direction == 'right' and self.y < 12:
            self.y += 1