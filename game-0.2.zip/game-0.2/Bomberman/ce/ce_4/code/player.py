class Player:
    def __init__(self, health: int):
        self.health = health
        self.x = 0
        self.y = 0

    def move(self, direction: str) -> None:
        if direction == 'up' and self.x > 0:
            self.x -= 1
        elif direction == 'down' and self.x < 12:
            self.x += 1
        elif direction == 'left' and self.y > 0:
            self.y -= 1
        elif direction == 'right' and self.y < 12:
            self.y += 1

    def place_bomb(self) -> None:
        print(f"Bomb placed at ({self.x}, {self.y})")