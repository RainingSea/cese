class Grid:
    def __init__(self, size: int):
        self.size = size
        self.cells = [[' ' for _ in range(size)] for _ in range(size)]
        self.update_obstacles()

    def draw(self) -> None:
        for row in self.cells:
            print(' '.join(row))

    def update_obstacles(self) -> None:
        # Example of placing obstacles randomly
        import random
        for _ in range(int(self.size * self.size * 0.2)):  # 20% obstacles
            x, y = random.randint(0, self.size - 1), random.randint(0, self.size - 1)
            self.cells[x][y] = '#'