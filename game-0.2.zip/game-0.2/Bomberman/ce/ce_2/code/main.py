import pygame
from game import Game

def main() -> None:
    pygame.init()
    screen = pygame.display.set_mode((640, 640))
    pygame.display.set_caption("2D Game")
    clock = pygame.time.Clock()
    
    game = Game()
    game.start()

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    game.place_bomb()

        game.update()
        game.render()
        pygame.display.flip()
        clock.tick(60)

    pygame.quit()

if __name__ == "__main__":
    main()