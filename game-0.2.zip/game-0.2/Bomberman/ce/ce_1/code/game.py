import pygame
from grid import Grid
from player import Player
from enemy import Enemy

class Game:
    def __init__(self):
        self.grid = Grid()
        self.player = Player()
        self.enemies = [Enemy() for _ in range(5)]
        self.score = 0
        self.player_health = self.player.health

    def run(self):
        pygame.init()
        screen = pygame.display.set_mode((520, 520))
        pygame.display.set_caption("Grid Game")
        clock = pygame.time.Clock()
        running = True

        while running:
            self.handle_events()
            self.update()
            self.draw(screen)
            pygame.display.flip()
            clock.tick(60)

        pygame.quit()

    def update(self):
        # Update game state logic will be implemented here
        pass

    def draw(self, screen):
        self.grid.draw(screen)
        # Draw player and enemies here

    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()

    def check_collisions(self):
        # Collision detection logic will be implemented here
        pass

    def save_data(self):
        with open('game_data.txt', 'w') as f:
            f.write(f"{self.player_health}|{self.score}\n")
        with open('enemies_data.txt', 'w') as f:
            for enemy in self.enemies:
                f.write(f"{enemy.health}\n")