class Grid:
    def __init__(self):
        self.cells = [[' ' for _ in range(13)] for _ in range(13)]
        self.update_obstacles()

    def draw(self, screen):
        for row in range(13):
            for col in range(13):
                color = (255, 255, 255) if self.cells[row][col] == ' ' else (0, 0, 0)
                pygame.draw.rect(screen, color, (col * 40, row * 40, 40, 40))

    def update_obstacles(self):
        for row in range(0, 13, 2):
            for col in range(0, 13, 2):
                self.cells[row][col] = '#'