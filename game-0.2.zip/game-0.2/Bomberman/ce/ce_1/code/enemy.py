class Enemy:
    def __init__(self):
        self.health = 50

    def move(self):
        # Enemy movement logic will be implemented here
        pass