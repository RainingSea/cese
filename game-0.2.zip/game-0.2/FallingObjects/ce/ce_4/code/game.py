import pygame
from object import Object

class Game:
    def __init__(self):
        self.score = 0
        self.missed_objects = 0
        self.max_missed = 5
        self.time_limit = 60.0  # Game duration in seconds
        self.objects = []
        self.basket_x = 400  # Starting position of the basket
        self.basket_width = 100
        self.basket_height = 20
        self.clock = pygame.time.Clock()
        self.start_time = pygame.time.get_ticks() / 1000  # Get current time in seconds

    def run(self):
        pygame.init()
        screen = pygame.display.set_mode((800, 600))
        pygame.display.set_caption("Catch the Falling Objects")
        self.objects.append(Object(random.randint(0, 800), random.randint(1, 5)))

        running = True
        while running:
            self.update()
            self.draw(screen)
            running = self.check_game_over()
            self.clock.tick(60)  # Limit to 60 frames per second

        self.save_data()

    def update(self):
        for obj in self.objects:
            obj.fall()
            if obj.y > 600:  # If object falls below the screen
                self.missed_objects += 1
                obj.reset_position()

    def draw(self, screen):
        screen.fill((255, 255, 255))  # Clear the screen with white
        for obj in self.objects:
            pygame.draw.circle(screen, (255, 0, 0), (obj.x, obj.y), 10)  # Draw falling objects
        pygame.draw.rect(screen, (0, 0, 255), (self.basket_x, 580, self.basket_width, self.basket_height))  # Draw basket
        pygame.display.flip()  # Update the display

    def check_game_over(self) -> bool:
        current_time = pygame.time.get_ticks() / 1000
        if self.missed_objects >= self.max_missed or (current_time - self.start_time) >= self.time_limit:
            return False
        return True

    def save_data(self):
        with open('game_data.txt', 'w') as f:
            f.write(f'score={self.score}\n')
            f.write(f'missed={self.missed_objects}\n')