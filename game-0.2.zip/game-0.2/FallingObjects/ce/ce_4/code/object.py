import random

class Object:
    def __init__(self, x: int, speed: int):
        self.x = x
        self.y = 0  # Start at the top of the screen
        self.speed = speed

    def fall(self):
        self.y += self.speed

    def reset_position(self):
        self.x = random.randint(0, 800)  # Assuming screen width is 800
        self.y = 0  # Reset to the top of the screen