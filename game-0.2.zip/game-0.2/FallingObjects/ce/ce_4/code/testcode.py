import unittest
import pygame
from game import Game
from object import Object

class TestFallingObjectsGame(unittest.TestCase):

    def setUp(self):
        # Initialize the game
        self.game = Game()
        pygame.init()
        self.screen = pygame.display.set_mode((800, 600))

    def test_player_controls_basket(self):
        # Functionality 1: Player Controls the Basket
        # Initial position of the basket
        initial_x = self.game.basket_x
        self.assertEqual(initial_x, 400, "Basket should start at the bottom center of the screen")

        # Simulate left arrow key press
        pygame.event.post(pygame.event.Event(pygame.KEYDOWN, key=pygame.K_LEFT))
        self.game.basket_x -= 10  # Simulate movement
        self.assertLess(self.game.basket_x, initial_x, "Basket should move left")

        # Simulate right arrow key press
        pygame.event.post(pygame.event.Event(pygame.KEYDOWN, key=pygame.K_RIGHT))
        self.game.basket_x += 10  # Simulate movement
        self.assertGreater(self.game.basket_x, initial_x, "Basket should move right")

    def test_catching_falling_objects(self):
        # Functionality 2: Catching Falling Objects
        obj = Object(400, 5)
        self.game.objects.append(obj)
        initial_score = self.game.score

        # Simulate object falling and being caught
        obj.y = 580  # Position object at basket level
        if self.game.basket_x <= obj.x <= self.game.basket_x + self.game.basket_width:
            self.game.score += 1
            obj.reset_position()

        self.assertEqual(self.game.score, initial_score + 1, "Score should increase by 1 when object is caught")

        # Simulate object falling without being caught
        obj.y = 601  # Position object below screen
        self.game.missed_objects += 1
        obj.reset_position()

        self.assertEqual(self.game.missed_objects, 1, "Missed objects should increase by 1 when object hits the ground")

    def test_scoring_system(self):
        # Functionality 3: Scoring System
        self.game.score = 0
        self.game.missed_objects = 0

        # Simulate catching multiple objects
        for _ in range(3):
            self.game.score += 1

        self.assertEqual(self.game.score, 3, "Score should reflect the total number of objects caught")

        # Simulate missing objects
        for _ in range(3):
            self.game.missed_objects += 1

        self.assertEqual(self.game.missed_objects, 3, "Missed objects should reflect the total number of objects missed")

    def test_game_end_conditions(self):
        # Functionality 4: Game End Conditions
        self.game.missed_objects = 5
        self.assertFalse(self.game.check_game_over(), "Game should end when maximum missed objects are reached")

        self.game.start_time = pygame.time.get_ticks() / 1000 - 60
        self.assertFalse(self.game.check_game_over(), "Game should end when time limit is reached")

    def test_data_storage(self):
        # Functionality 5: Data Storage
        self.game.score = 10
        self.game.save_data()

        with open('game_data.txt', 'r') as f:
            data = f.read()

        self.assertIn('score=10', data, "Score should be correctly saved in the local text file")

        # Test loading score (not implemented in codebase)
        self.fail("Loading score functionality is not implemented in the codebase")

if __name__ == '__main__':
    unittest.main()
