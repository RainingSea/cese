import unittest
import pygame
from game import Game
import os

class TestFallingObjectsGame(unittest.TestCase):

    def setUp(self):
        # Initialize the game
        self.game = Game()

    def test_player_controls_basket(self):
        # Functionality 1: Player Controls the Basket
        # Initial position of the basket
        initial_x = self.game.basket_x
        self.assertEqual(initial_x, self.game.screen_width // 2 - self.game.basket_width // 2, "Basket should be at the bottom center of the screen initially")

        # Simulate left arrow key press
        self.game.basket_x -= 10  # Simulate movement
        self.assertLess(self.game.basket_x, initial_x, "Basket should move left")

        # Simulate right arrow key press
        self.game.basket_x += 20  # Simulate movement
        self.assertGreater(self.game.basket_x, initial_x, "Basket should move right")

        # Simulate holding left arrow key
        self.game.basket_x = 0  # Move to the left edge
        self.assertGreaterEqual(self.game.basket_x, 0, "Basket should not move off the screen to the left")

        # Simulate holding right arrow key
        self.game.basket_x = self.game.screen_width - self.game.basket_width  # Move to the right edge
        self.assertLessEqual(self.game.basket_x, self.game.screen_width - self.game.basket_width, "Basket should not move off the screen to the right")

    def test_catching_falling_objects(self):
        # Functionality 2: Catching Falling Objects
        initial_score = self.game.score
        initial_missed = self.game.missed_objects

        # Simulate catching an object
        self.game.falling_objects.append(Object(self.game.basket_x + 10, self.game.screen_height - self.game.basket_height - 1, 1))
        self.game.check_collision()
        self.assertEqual(self.game.score, initial_score + 1, "Score should increase by 1 when an object is caught")

        # Simulate missing an object
        self.game.falling_objects.append(Object(0, self.game.screen_height + 1, 1))
        self.game.update()
        self.assertEqual(self.game.missed_objects, initial_missed + 1, "Missed objects should increase by 1 when an object is missed")

    def test_scoring_system(self):
        # Functionality 3: Scoring System
        self.game.score = 0
        self.game.falling_objects.append(Object(self.game.basket_x + 10, self.game.screen_height - self.game.basket_height - 1, 1))
        self.game.check_collision()
        self.assertEqual(self.game.score, 1, "Score should reflect the total number of objects caught")

        # Simulate missing objects
        self.game.missed_objects = 0
        self.game.falling_objects.append(Object(0, self.game.screen_height + 1, 1))
        self.game.update()
        self.assertEqual(self.game.missed_objects, 1, "Missed objects should increase correctly")

    def test_game_end_conditions(self):
        # Functionality 4: Game End Conditions
        # Simulate missing maximum allowed objects
        self.game.missed_objects = self.game.max_missed
        self.game.update()
        self.assertFalse(pygame.get_init(), "Game should end when maximum missed objects is reached")

    def test_data_storage(self):
        # Functionality 5: Data Storage
        self.game.score = 5
        self.game.save_data()
        with open('score.txt', 'r') as score_file:
            saved_score = int(score_file.read())
        self.assertEqual(saved_score, 5, "Score should be correctly saved in the local text file")

        # Check if the missed objects are saved correctly
        self.game.missed_objects = 3
        self.game.save_data()
        with open('missed_objects.txt', 'r') as missed_file:
            saved_missed = int(missed_file.read())
        self.assertEqual(saved_missed, 3, "Missed objects should be correctly saved in the local text file")

if __name__ == '__main__':
    unittest.main()
