import pygame
from object import Object

class Game:
    def __init__(self):
        self.score = 0
        self.missed_objects = 0
        self.max_missed = 5
        self.falling_objects = []
        self.basket_x = 300
        self.basket_width = 100
        self.basket_height = 20
        self.screen_width = 600
        self.screen_height = 400
        self.clock = pygame.time.Clock()
        self.font = pygame.font.Font(None, 36)

    def run(self) -> None:
        pygame.init()
        screen = pygame.display.set_mode((self.screen_width, self.screen_height))
        pygame.display.set_caption("Catch the Falling Objects")
        self.spawn_object()

        running = True
        while running:
            self.update()
            self.draw(screen)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False

        self.save_data()
        pygame.quit()

    def update(self) -> None:
        for obj in self.falling_objects:
            obj.fall()
            if obj.y > self.screen_height:
                self.missed_objects += 1
                self.falling_objects.remove(obj)
                if self.missed_objects >= self.max_missed:
                    self.save_data()
                    pygame.quit()

        if random.randint(1, 30) == 1:  # Randomly spawn objects
            self.spawn_object()

    def draw(self, screen) -> None:
        screen.fill((255, 255, 255))
        for obj in self.falling_objects:
            pygame.draw.rect(screen, (255, 0, 0), (obj.x, obj.y, 20, 20))
        pygame.draw.rect(screen, (0, 0, 255), (self.basket_x, self.screen_height - self.basket_height, self.basket_width, self.basket_height))
        score_text = self.font.render(f'Score: {self.score}', True, (0, 0, 0))
        missed_text = self.font.render(f'Missed: {self.missed_objects}', True, (0, 0, 0))
        screen.blit(score_text, (10, 10))
        screen.blit(missed_text, (10, 40))
        pygame.display.flip()
        self.clock.tick(60)

    def check_collision(self) -> None:
        for obj in self.falling_objects:
            if (self.basket_x < obj.x < self.basket_x + self.basket_width) and (self.screen_height - self.basket_height < obj.y < self.screen_height):
                self.score += 1
                self.falling_objects.remove(obj)

    def spawn_object(self) -> None:
        x = random.randint(0, self.screen_width - 20)
        speed = random.randint(1, 5)
        new_object = Object(x, 0, speed)
        self.falling_objects.append(new_object)

    def save_data(self) -> None:
        with open('score.txt', 'w') as score_file:
            score_file.write(str(self.score))
        with open('missed_objects.txt', 'w') as missed_file:
            missed_file.write(str(self.missed_objects))