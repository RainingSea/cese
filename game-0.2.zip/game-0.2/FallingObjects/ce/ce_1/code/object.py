import random

class Object:
    def __init__(self, x: int, y: int, speed: int):
        self.x = x
        self.y = y
        self.speed = speed

    def fall(self) -> None:
        self.y += self.speed