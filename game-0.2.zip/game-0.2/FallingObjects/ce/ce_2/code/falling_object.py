import random

class FallingObject:
    def __init__(self):
        self.position = random.randint(0, 800)  # Assuming the width of the window is 800
        self.speed = random.randint(1, 5)  # Speed of falling object

    def fall(self):
        self.position += self.speed

    def reset_position(self):
        self.position = random.randint(0, 800)