class Basket:
    def __init__(self):
        self.position = 400  # Starting position in the middle of the screen

    def move_left(self):
        if self.position > 0:
            self.position -= 10  # Move left by 10 pixels

    def move_right(self):
        if self.position < 800:  # Assuming the width of the window is 800
            self.position += 10  # Move right by 10 pixels