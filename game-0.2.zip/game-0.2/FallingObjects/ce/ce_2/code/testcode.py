import unittest
import pygame
from game import Game
from basket import Basket
from falling_object import FallingObject

class TestFallingObjectsGame(unittest.TestCase):

    def setUp(self):
        # Initialize the game and its components
        self.game = Game()
        self.basket = self.game.basket
        self.falling_objects = self.game.falling_objects

    def test_player_controls_basket(self):
        # Functionalities 1: Test initial position of the basket
        self.assertEqual(self.basket.position, 400, "Basket should start at position 400")

        # Test basket movement to the left
        initial_position = self.basket.position
        self.basket.move_left()
        self.assertLess(self.basket.position, initial_position, "Basket should move left")

        # Test basket movement to the right
        initial_position = self.basket.position
        self.basket.move_right()
        self.assertGreater(self.basket.position, initial_position, "Basket should move right")

        # Test basket does not move off the screen to the left
        self.basket.position = 0
        self.basket.move_left()
        self.assertEqual(self.basket.position, 0, "Basket should not move off the screen to the left")

        # Test basket does not move off the screen to the right
        self.basket.position = 800
        self.basket.move_right()
        self.assertEqual(self.basket.position, 800, "Basket should not move off the screen to the right")

    def test_catching_falling_objects(self):
        # Functionalities 2: Test catching falling objects
        initial_score = self.game.score
        self.falling_objects[0].position = 600  # Simulate object at basket level
        self.game.update_game()
        self.assertEqual(self.game.score, initial_score, "Score should increase when object is caught")

        # Test missing falling objects
        initial_missed = self.game.missed_objects
        self.falling_objects[0].position = 601  # Simulate object missed
        self.game.update_game()
        self.assertEqual(self.game.missed_objects, initial_missed + 1, "Missed objects should increase when object is missed")

    def test_scoring_system(self):
        # Functionalities 3: Test scoring system
        self.game.score = 0
        for _ in range(3):
            self.game.update_score()
        self.assertEqual(self.game.score, 3, "Score should reflect the total number of objects caught")

        # Test game over condition when missed objects reach maximum
        self.game.missed_objects = self.game.max_missed
        self.assertTrue(self.game.check_game_over(), "Game should end when missed objects reach maximum")

    def test_game_end_conditions(self):
        # Functionalities 4: Test game end conditions
        self.game.timer = 0
        self.assertTrue(self.game.check_game_over(), "Game should end when timer reaches zero")

        # Test game ends when maximum missed objects are reached
        self.game.missed_objects = self.game.max_missed
        self.assertTrue(self.game.check_game_over(), "Game should end when maximum missed objects are reached")

    def test_data_storage(self):
        # Functionalities 5: Test data storage
        self.game.score = 10
        self.game.missed_objects = 2
        self.game.save_data()

        with open('game_data.txt', 'r') as f:
            data = f.read().strip()
            self.assertEqual(data, "10,2", "Score and missed objects should be saved correctly in the local text file")

        # Test loading saved score (not implemented in codebase)
        self.fail("Loading saved score functionality is not implemented in the codebase")

if __name__ == '__main__':
    unittest.main()
