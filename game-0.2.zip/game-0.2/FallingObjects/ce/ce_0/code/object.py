import random

class Object:
    def __init__(self, position: int, speed: int):
        self.position = position
        self.speed = speed

    def fall(self):
        self.position += self.speed