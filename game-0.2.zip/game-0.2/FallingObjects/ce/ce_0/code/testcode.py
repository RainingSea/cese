import unittest
import pygame
from game import Game
from basket import Basket
from object import Object

class TestFallingObjectsGame(unittest.TestCase):

    def setUp(self):
        # Initialize the game and its components
        pygame.init()
        self.game = Game()
        self.basket = self.game.basket

    def test_player_controls_basket(self):
        # Functionality 1: Player Controls the Basket

        # Initial position of the basket
        initial_position = self.basket.position
        self.assertEqual(initial_position, 300, "Basket should start at position 300")

        # Simulate moving the basket left
        self.basket.move_left()
        self.assertEqual(self.basket.position, initial_position - 10, "Basket should move left by 10 pixels")

        # Simulate moving the basket right
        self.basket.move_right()
        self.basket.move_right()
        self.assertEqual(self.basket.position, initial_position + 10, "Basket should move right by 10 pixels")

        # Simulate holding the left arrow key
        for _ in range(5):
            self.basket.move_left()
        self.assertGreaterEqual(self.basket.position, 0, "Basket should not move off the screen to the left")

        # Simulate holding the right arrow key
        for _ in range(50):
            self.basket.move_right()
        self.assertLessEqual(self.basket.position, 540, "Basket should not move off the screen to the right")

    def test_catching_falling_objects(self):
        # Functionality 2: Catching Falling Objects

        # Create a falling object directly above the basket
        falling_object = Object(position=self.basket.position, speed=5)
        self.game.falling_objects.append(falling_object)

        # Simulate the object falling and being caught
        self.game.check_collision()
        self.assertEqual(self.game.score, 1, "Score should increase by 1 when object is caught")

        # Simulate an object falling and missing the basket
        falling_object = Object(position=600, speed=5)
        self.game.falling_objects.append(falling_object)
        falling_object.position = 401  # Simulate object falling below the screen
        self.game.update()
        self.assertEqual(self.game.missed_objects, 1, "Missed objects should increase by 1 when object is missed")

    def test_scoring_system(self):
        # Functionality 3: Scoring System

        # Catch multiple objects
        for _ in range(3):
            falling_object = Object(position=self.basket.position, speed=5)
            self.game.falling_objects.append(falling_object)
            self.game.check_collision()
        self.assertEqual(self.game.score, 3, "Score should reflect the total number of objects caught")

        # Miss multiple objects
        for _ in range(3):
            falling_object = Object(position=600, speed=5)
            self.game.falling_objects.append(falling_object)
            falling_object.position = 401
            self.game.update()
        self.assertEqual(self.game.missed_objects, 4, "Missed objects should reflect the total number of objects missed")

    def test_game_end_conditions(self):
        # Functionality 4: Game End Conditions

        # Simulate game ending after missing a certain number of objects
        self.game.missed_objects = 3
        self.game.end_game()
        with open('missed.txt', 'r') as missed_file:
            missed_count = int(missed_file.read())
        self.assertEqual(missed_count, 3, "Game should end and save missed objects count")

    def test_data_storage(self):
        # Functionality 5: Data Storage

        # Simulate ending the game and saving the score
        self.game.score = 5
        self.game.end_game()
        with open('score.txt', 'r') as score_file:
            saved_score = int(score_file.read())
        self.assertEqual(saved_score, 5, "Score should be correctly saved in the local text file")

        # Simulate restarting the game and loading the score
        self.game.score = 0
        with open('score.txt', 'r') as score_file:
            loaded_score = int(score_file.read())
        self.assertEqual(loaded_score, 5, "Previously saved score should be loaded correctly from the local text file")

if __name__ == '__main__':
    unittest.main()
