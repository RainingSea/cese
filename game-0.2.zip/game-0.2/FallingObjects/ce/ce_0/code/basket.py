class Basket:
    def __init__(self, position: int):
        self.position = position

    def move_left(self):
        self.position -= 10  # Move left by 10 pixels

    def move_right(self):
        self.position += 10  # Move right by 10 pixels