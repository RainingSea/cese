import pygame
from object import Object
from basket import Basket

class Game:
    def __init__(self):
        self.score = 0
        self.missed_objects = 0
        self.basket = Basket(position=300)
        self.falling_objects = []
        self.screen = pygame.display.set_mode((600, 400))
        pygame.display.set_caption("Catch the Falling Objects")
        self.clock = pygame.time.Clock()

    def run(self):
        running = True
        while running:
            self.update()
            self.draw()
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
            self.clock.tick(60)
        self.end_game()

    def update(self):
        if random.randint(1, 20) == 1:  # Randomly spawn objects
            new_object = Object(position=0, speed=random.randint(1, 5))
            self.falling_objects.append(new_object)
        
        for obj in self.falling_objects:
            obj.fall()
            if obj.position > 400:  # If object falls below the screen
                self.missed_objects += 1
                self.falling_objects.remove(obj)

    def draw(self):
        self.screen.fill((255, 255, 255))  # Clear screen with white
        for obj in self.falling_objects:
            pygame.draw.rect(self.screen, (255, 0, 0), (obj.position, obj.position, 20, 20))  # Draw falling objects
        pygame.draw.rect(self.screen, (0, 0, 255), (self.basket.position, 350, 60, 20))  # Draw basket
        pygame.display.flip()  # Update the display

    def check_collision(self):
        for obj in self.falling_objects:
            if self.basket.position < obj.position < self.basket.position + 60:
                self.score += 1
                self.falling_objects.remove(obj)

    def end_game(self):
        with open('score.txt', 'w') as score_file:
            score_file.write(str(self.score))
        with open('missed.txt', 'w') as missed_file:
            missed_file.write(str(self.missed_objects))
        pygame.quit()