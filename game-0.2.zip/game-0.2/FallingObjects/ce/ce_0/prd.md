[OUTPUT]
## general overview of the project
Develop a Catch the Falling Objects game. You must design a GUI.

## software functional requirements
1. The system shall allow the player to control a basket or container at the bottom of the screen using the left and right arrow keys to move it horizontally.
2. The system shall enable falling objects to drop from the top of the screen that the player must catch with the basket or container.
3. The system shall increase the player's score by one point for each object successfully caught.
4. The system shall track and display the number of missed objects, counting an object as missed if it hits the ground without being caught.
5. The system shall implement a scoring system that reflects the total number of objects caught by the player.
6. The system shall end the game if the player misses a specified number of objects (e.g., 3 missed objects) or after a predetermined amount of time, depending on the selected game mode.
[/OUTPUT]