import pygame
import random

class Object:
    def __init__(self, position: int, speed: int):
        self.position = position
        self.speed = speed

    def fall(self):
        self.position += self.speed

class Basket:
    def __init__(self, position: int):
        self.position = position

    def move_left(self):
        self.position -= 10

    def move_right(self):
        self.position += 10

class Game:
    def __init__(self):
        self.basket = Basket(300)
        self.falling_objects = []
        self.score = 0
        self.missed_objects = 0
        self.load_data()

    def run(self):
        pygame.init()
        screen = pygame.display.set_mode((600, 400))
        clock = pygame.time.Clock()
        running = True

        while running:
            self.handle_input()
            self.update()
            self.draw(screen)
            pygame.display.flip()
            clock.tick(60)

        pygame.quit()

    def update(self):
        if random.randint(1, 20) == 1:  # Randomly generate falling objects
            new_object = Object(random.randint(0, 580), 5)
            self.falling_objects.append(new_object)

        for obj in self.falling_objects:
            obj.fall()
            if obj.position > 400:  # If object falls below the screen
                self.missed_objects += 1
                self.falling_objects.remove(obj)

        # Check for collisions
        for obj in self.falling_objects:
            if self.basket.position <= obj.position <= self.basket.position + 60:
                self.score += 1
                self.falling_objects.remove(obj)

    def draw(self, screen):
        screen.fill((255, 255, 255))  # Clear screen with white
        pygame.draw.rect(screen, (0, 0, 255), (self.basket.position, 350, 60, 10))  # Draw basket

        for obj in self.falling_objects:
            pygame.draw.circle(screen, (255, 0, 0), (obj.position + 10, obj.position), 10)  # Draw falling objects

        # Draw score and missed objects
        font = pygame.font.Font(None, 36)
        score_text = font.render(f'Score: {self.score}', True, (0, 0, 0))
        missed_text = font.render(f'Missed: {self.missed_objects}', True, (0, 0, 0))
        screen.blit(score_text, (10, 10))
        screen.blit(missed_text, (10, 40))

    def handle_input(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    self.basket.move_left()
                if event.key == pygame.K_RIGHT:
                    self.basket.move_right()

    def save_data(self):
        with open('game_data.txt', 'w') as f:
            f.write(f'score|{self.score}\n')
            f.write(f'missed|{self.missed_objects}\n')

    def load_data(self):
        try:
            with open('game_data.txt', 'r') as f:
                for line in f:
                    key, value = line.strip().split('|')
                    if key == 'score':
                        self.score = int(value)
                    elif key == 'missed':
                        self.missed_objects = int(value)
        except FileNotFoundError:
            self.score = 0
            self.missed_objects = 0