import unittest
import pygame
from game import Game, Basket, Object

class TestFallingObjectsGame(unittest.TestCase):

    def setUp(self):
        # Initialize the game and its components
        self.game = Game()
        self.basket = self.game.basket

    def test_player_controls_basket(self):
        # Functionality 1: Test initial position of the basket
        self.assertEqual(self.basket.position, 300, "Basket should start at position 300")

        # Test basket movement to the left
        initial_position = self.basket.position
        self.basket.move_left()
        self.assertLess(self.basket.position, initial_position, "Basket should move left")

        # Test basket movement to the right
        initial_position = self.basket.position
        self.basket.move_right()
        self.assertGreater(self.basket.position, initial_position, "Basket should move right")

    def test_catching_falling_objects(self):
        # Functionality 2: Simulate catching a falling object
        falling_object = Object(self.basket.position, 5)
        self.game.falling_objects.append(falling_object)
        self.game.update()
        self.assertEqual(self.game.score, 1, "Score should increase by 1 when object is caught")

        # Simulate missing a falling object
        falling_object = Object(0, 5)
        self.game.falling_objects.append(falling_object)
        for _ in range(81):  # Move object below the screen
            falling_object.fall()
        self.game.update()
        self.assertEqual(self.game.missed_objects, 1, "Missed objects should increase by 1 when object is missed")

    def test_scoring_system(self):
        # Functionality 3: Simulate catching multiple objects
        for _ in range(3):
            falling_object = Object(self.basket.position, 5)
            self.game.falling_objects.append(falling_object)
        self.game.update()
        self.assertEqual(self.game.score, 3, "Score should reflect the total number of objects caught")

        # Simulate missing multiple objects
        for _ in range(3):
            falling_object = Object(0, 5)
            self.game.falling_objects.append(falling_object)
            for _ in range(81):  # Move object below the screen
                falling_object.fall()
        self.game.update()
        self.assertEqual(self.game.missed_objects, 3, "Missed objects should reflect the total number of objects missed")

    def test_game_end_conditions(self):
        # Functionality 4: Test game end condition by missing objects
        for _ in range(3):
            falling_object = Object(0, 5)
            self.game.falling_objects.append(falling_object)
            for _ in range(81):  # Move object below the screen
                falling_object.fall()
        self.game.update()
        self.assertEqual(self.game.missed_objects, 3, "Game should end when maximum missed objects is reached")

    def test_data_storage(self):
        # Functionality 5: Test saving and loading game data
        self.game.score = 5
        self.game.missed_objects = 2
        self.game.save_data()

        new_game = Game()
        new_game.load_data()
        self.assertEqual(new_game.score, 5, "Loaded score should match saved score")
        self.assertEqual(new_game.missed_objects, 2, "Loaded missed objects should match saved missed objects")

if __name__ == '__main__':
    unittest.main()
