class Story:
    def __init__(self, title: str, content: str):
        self.title = title
        self.content = content

    def save(self) -> None:
        pass  # Saving is handled in main.py
    
    def edit(self, title: str, content: str) -> None:
        self.title = title
        self.content = content