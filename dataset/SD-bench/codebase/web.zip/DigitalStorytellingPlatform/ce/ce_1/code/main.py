from flask import Flask, request, redirect, render_template, session
from user import User
from story import Story

app = Flask(__name__)
app.secret_key = 'supersecretkey'

def load_users():
    users = {}
    with open('users.txt', 'r') as f:
        for line in f:
            username, password, email = line.strip().split('|')
            users[username] = User(username, password, email)
    return users

def load_stories():
    stories = {}
    with open('stories.txt', 'r') as f:
        for line in f:
            title, content = line.strip().split('|')
            stories[title] = Story(title, content)
    return stories

users = load_users()
stories = load_stories()

@app.route('/')
def login():
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        email = request.form['email']
        users[username] = User(username, password, email)
        with open('users.txt', 'a') as f:
            f.write(f"{username}|{password}|{email}\n")
        return redirect('/')
    return render_template('register.html')

@app.route('/story_creation', methods=['GET', 'POST'])
def create_story():
    if request.method == 'POST':
        title = request.form['title']
        content = request.form['content']
        save_story(title, content)
        return redirect('/story_creation')
    return render_template('story_creation.html')

def save_story(title, content):
    stories[title] = Story(title, content)
    with open('stories.txt', 'a') as f:
        f.write(f"{title}|{content}\n")

if __name__ == '__main__':
    app.run(port=8289, debug=False)
