class Story:
    def __init__(self, title: str, content: str):
        self.title = title
        self.content = content

    def save(self):
        pass  # Not implemented, as we save stories in the main file

    def edit(self, title: str, content: str):
        self.title = title
        self.content = content