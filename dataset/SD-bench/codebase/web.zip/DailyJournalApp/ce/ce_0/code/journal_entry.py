from datetime import datetime

class JournalEntry:
    def __init__(self, title: str, content: str):
        self.title = title
        self.content = content
        self.date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    def save(self) -> None:
        with open('journal_entries.txt', 'a') as file:
            file.write(f"{self.title}|{self.content}|{self.date}\n")

    @staticmethod
    def load_entries() -> list:
        entries = []
        try:
            with open('journal_entries.txt', 'r') as file:
                for line in file:
                    title, content, date = line.strip().split('|')
                    entries.append(JournalEntry(title, content))
                    entries[-1].date = date  # Set the date for the entry
        except FileNotFoundError:
            pass
        return entries