from flask import Flask, render_template, request, redirect, url_for, session
from user import User
from journal_entry import JournalEntry

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# Load users and journal entries from files
users = User.load_users()
journal_entries = JournalEntry.load_entries()

@app.route('/')
def login():
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        new_user = User(username, password)
        new_user.save()
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/dashboard', methods=['GET'])
def dashboard():
    return render_template('dashboard.html', entries=journal_entries)

@app.route('/new_entry', methods=['GET', 'POST'])
def new_entry():
    if request.method == 'POST':
        title = request.form['title']
        content = request.form['content']
        new_journal_entry = JournalEntry(title, content)
        new_journal_entry.save()
        return redirect(url_for('dashboard'))
    return render_template('new_entry.html')

if __name__ == '__main__':
    app.run(port=8283, debug=False)
