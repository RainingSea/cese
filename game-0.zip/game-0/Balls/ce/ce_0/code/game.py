import pygame
import random

class PlayerBall:
    def __init__(self, size: int):
        self.size = size
        self.position_x = 400  # Center of the screen
        self.position_y = 300  # Center of the screen

    def move(self, direction: str):
        if direction == 'UP':
            self.position_y -= 5
        elif direction == 'DOWN':
            self.position_y += 5
        elif direction == 'LEFT':
            self.position_x -= 5
        elif direction == 'RIGHT':
            self.position_x += 5

    def grow(self, amount: int):
        self.size += amount

class EnemyBall:
    def __init__(self, size: int):
        self.size = size
        self.position_x = random.randint(0, 800)
        self.position_y = random.randint(0, 600)

    def move_randomly(self):
        self.position_x += random.choice([-1, 1]) * random.randint(1, 3)
        self.position_y += random.choice([-1, 1]) * random.randint(1, 3)

class Game:
    def __init__(self):
        self.player_ball = PlayerBall(size=20)
        self.enemy_balls = [EnemyBall(size=random.randint(10, 30)) for _ in range(5)]
        self.score = 0

    def run(self):
        pygame.init()
        screen = pygame.display.set_mode((800, 600))
        clock = pygame.time.Clock()
        running = True

        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False

            keys = pygame.key.get_pressed()
            if keys[pygame.K_UP]:
                self.player_ball.move('UP')
            if keys[pygame.K_DOWN]:
                self.player_ball.move('DOWN')
            if keys[pygame.K_LEFT]:
                self.player_ball.move('LEFT')
            if keys[pygame.K_RIGHT]:
                self.player_ball.move('RIGHT')

            self.update()
            self.check_collisions()

            screen.fill((0, 0, 0))
            pygame.draw.circle(screen, (0, 255, 0), (self.player_ball.position_x, self.player_ball.position_y), self.player_ball.size)
            for enemy in self.enemy_balls:
                pygame.draw.circle(screen, (255, 0, 0), (enemy.position_x, enemy.position_y), enemy.size)
            pygame.display.flip()
            clock.tick(60)

        self.save_game_data()
        pygame.quit()

    def update(self):
        for enemy in self.enemy_balls:
            enemy.move_randomly()

    def check_collisions(self):
        for enemy in self.enemy_balls:
            if (self.player_ball.position_x - enemy.position_x) ** 2 + (self.player_ball.position_y - enemy.position_y) ** 2 < (self.player_ball.size + enemy.size) ** 2:
                self.player_ball.grow(5)
                self.score += 1

    def save_game_data(self):
        with open('game_data.txt', 'w') as f:
            f.write(f'score|{self.score}\n')
            f.write(f'player_size|{self.player_ball.size}\n')
            for i, enemy in enumerate(self.enemy_balls):
                f.write(f'enemy_{i}_size|{enemy.size}\n')
                f.write(f'enemy_{i}_position|{enemy.position_x}|{enemy.position_y}\n')