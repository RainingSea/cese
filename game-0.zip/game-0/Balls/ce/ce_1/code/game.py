import pygame
import random

class PlayerBall:
    def __init__(self, size, position):
        self.size = size
        self.position = position

    def move(self, direction):
        if direction == 'UP':
            self.position = (self.position[0], self.position[1] - 5)
        elif direction == 'DOWN':
            self.position = (self.position[0], self.position[1] + 5)
        elif direction == 'LEFT':
            self.position = (self.position[0] - 5, self.position[1])
        elif direction == 'RIGHT':
            self.position = (self.position[0] + 5, self.position[1])

    def grow(self, amount):
        self.size += amount

class EnemyBall:
    def __init__(self, size, position):
        self.size = size
        self.position = position

    def spawn(self):
        self.position = (random.randint(0, 800), random.randint(0, 600))

class Game:
    def __init__(self):
        self.player_ball = PlayerBall(size=20, position=(400, 300))
        self.enemy_balls = [EnemyBall(size=10, position=(random.randint(0, 800), random.randint(0, 600))) for _ in range(5)]
        self.score = 0

    def run(self):
        pygame.init()
        screen = pygame.display.set_mode((800, 600))
        pygame.display.set_caption("Battle of Balls")
        clock = pygame.time.Clock()
        running = True

        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False

            keys = pygame.key.get_pressed()
            if keys[pygame.K_UP]:
                self.player_ball.move('UP')
            if keys[pygame.K_DOWN]:
                self.player_ball.move('DOWN')
            if keys[pygame.K_LEFT]:
                self.player_ball.move('LEFT')
            if keys[pygame.K_RIGHT]:
                self.player_ball.move('RIGHT')

            self.check_collisions()
            self.update_game_state()

            screen.fill((255, 255, 255))
            pygame.draw.circle(screen, (0, 0, 255), self.player_ball.position, self.player_ball.size)
            for enemy in self.enemy_balls:
                pygame.draw.circle(screen, (255, 0, 0), enemy.position, enemy.size)
            pygame.display.flip()
            clock.tick(60)

        pygame.quit()

    def check_collisions(self):
        for enemy in self.enemy_balls:
            distance = ((self.player_ball.position[0] - enemy.position[0]) ** 2 + 
                         (self.player_ball.position[1] - enemy.position[1]) ** 2) ** 0.5
            if distance < self.player_ball.size + enemy.size:
                self.player_ball.grow(5)
                self.score += 1
                enemy.spawn()

    def update_game_state(self):
        with open('game_data.txt', 'w') as f:
            f.write(f'score|{self.score}\n')
            f.write(f'player_size|{self.player_ball.size}\n')