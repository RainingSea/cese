import unittest
import pygame
from game import Game, PlayerBall, EnemyBall

class TestBattleOfBallsGame(unittest.TestCase):

    def setUp(self):
        # Initialize the game and its components
        self.game = Game()
        self.player_ball = self.game.player_ball
        self.enemy_balls = self.game.enemy_balls

    def test_player_ball_movement(self):
        # Functionalities 1: Simulate pressing the up arrow key to move the player's ball
        initial_position = self.player_ball.position
        self.player_ball.move('UP')
        self.assertEqual(self.player_ball.position, (initial_position[0], initial_position[1] - 5),
                         "Player's ball should move upward by 5 units")

    def test_enemy_ball_collision(self):
        # Functionalities 2: Position the player's ball to collide with a smaller enemy ball
        self.player_ball.position = (100, 100)
        self.player_ball.size = 20
        enemy_ball = EnemyBall(size=10, position=(105, 105))
        self.enemy_balls.append(enemy_ball)
        
        self.game.check_collisions()
        
        self.assertGreater(self.player_ball.size, 20, "Player's ball should grow in size after collision")
        self.assertNotIn(enemy_ball, self.enemy_balls, "Enemy ball should be removed after collision")

    def test_player_ball_consumption(self):
        # Functionalities 3: Simulate a scenario where the player's ball is surrounded by larger enemy balls
        self.fail("Player's ball consumption functionality is not implemented in the codebase")

    def test_initialize_game_entities(self):
        # Functionalities 4: Trigger the game initialization function
        self.assertEqual(len(self.enemy_balls), 5, "There should be 5 enemy balls initialized")
        self.assertGreater(self.player_ball.size, self.enemy_balls[0].size, "Player's ball should be larger than enemy balls")

    def test_enemy_ball_spawning(self):
        # Functionalities 5: Call the function responsible for spawning enemy balls
        enemy_ball = EnemyBall(size=10, position=(0, 0))
        enemy_ball.spawn()
        self.assertTrue(0 <= enemy_ball.position[0] <= 800 and 0 <= enemy_ball.position[1] <= 600,
                        "Enemy ball should spawn within the screen bounds")

    def test_data_storage_functionality(self):
        # Functionalities 6: Save the game state to a local text file
        self.game.update_game_state()
        with open('game_data.txt', 'r') as f:
            data = f.read()
        self.assertIn('score|', data, "Game state should include score")
        self.assertIn('player_size|', data, "Game state should include player size")

if __name__ == '__main__':
    unittest.main()
