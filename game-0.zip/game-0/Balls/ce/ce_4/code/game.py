import pygame
import random
from player_ball import PlayerBall
from enemy_ball import EnemyBall

class Game:
    def __init__(self):
        self.player_ball = PlayerBall(size=20, position=(400, 300))
        self.enemy_balls = []
        self.score = 0
        self.load_game_state()

    def run(self) -> None:
        pygame.init()
        screen = pygame.display.set_mode((800, 600))
        clock = pygame.time.Clock()
        running = True

        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_UP:
                        self.player_ball.move('up')
                    elif event.key == pygame.K_DOWN:
                        self.player_ball.move('down')
                    elif event.key == pygame.K_LEFT:
                        self.player_ball.move('left')
                    elif event.key == pygame.K_RIGHT:
                        self.player_ball.move('right')

            self.update()
            screen.fill((255, 255, 255))
            self.draw(screen)
            pygame.display.flip()
            clock.tick(60)

        self.save_game_state()
        pygame.quit()

    def update(self) -> None:
        self.check_collisions()
        self.spawn_enemy_balls()

    def check_collisions(self) -> None:
        for enemy in self.enemy_balls:
            if self.is_colliding(self.player_ball, enemy):
                self.player_ball.grow(5)
                self.score += 1
                self.enemy_balls.remove(enemy)

    def is_colliding(self, player: PlayerBall, enemy: EnemyBall) -> bool:
        distance = ((player.position[0] - enemy.position[0]) ** 2 + 
                    (player.position[1] - enemy.position[1]) ** 2) ** 0.5
        return distance < (player.size + enemy.size)

    def spawn_enemy_balls(self) -> None:
        if len(self.enemy_balls) < 5:
            new_enemy = EnemyBall.spawn_random_ball(max_size=30, canvas_width=800, canvas_height=600)
            self.enemy_balls.append(new_enemy)

    def load_game_state(self) -> None:
        try:
            with open('game_state.txt', 'r') as file:
                for line in file:
                    key, value = line.strip().split('=')
                    if key == 'score':
                        self.score = int(value)
        except FileNotFoundError:
            self.score = 0

    def save_game_state(self) -> None:
        with open('game_state.txt', 'w') as file:
            file.write(f'score={self.score}\n')