import unittest
import pygame
from game import Game
from player_ball import PlayerBall
from enemy_ball import EnemyBall

class TestBallGame(unittest.TestCase):

    def setUp(self):
        # Initialize the game and its components
        self.game = Game()
        self.player_ball = self.game.player_ball
        self.enemy_balls = self.game.enemy_balls

    def test_player_ball_movement(self):
        # Functionalities 1: Simulate pressing the up arrow key to move the player's ball
        initial_position = self.player_ball.position
        self.player_ball.move('up')
        self.assertEqual(self.player_ball.position, (initial_position[0], initial_position[1] - 5), 
                         "Player's ball should move upward by 5 units")

    def test_enemy_ball_collision(self):
        # Functionalities 2: Position the player's ball to collide with a smaller enemy ball
        enemy_ball = EnemyBall(size=10, position=self.player_ball.position)
        self.enemy_balls.append(enemy_ball)
        self.game.check_collisions()
        self.assertEqual(self.player_ball.size, 25, "Player's ball should grow in size after collision")
        self.assertNotIn(enemy_ball, self.enemy_balls, "Enemy ball should be removed after collision")

    def test_player_ball_consumption(self):
        # Functionalities 3: Simulate a scenario where the player's ball is surrounded by larger enemy balls
        self.fail("Player's ball consumption logic is not implemented in the codebase")

    def test_initialize_game_entities(self):
        # Functionalities 4: Trigger the game initialization function
        self.assertEqual(len(self.enemy_balls), 0, "Initially, there should be no enemy balls")
        self.assertEqual(self.player_ball.size, 20, "Player's ball should be initialized with size 20")

    def test_enemy_ball_spawning(self):
        # Functionalities 5: Call the function responsible for spawning enemy balls
        self.game.spawn_enemy_balls()
        self.assertEqual(len(self.enemy_balls), 1, "A new enemy ball should appear on the map")
        self.assertLess(self.enemy_balls[0].size, self.player_ball.size, "Enemy ball should be smaller than player's ball")

    def test_data_storage_functionality(self):
        # Functionalities 6: Save the game state to a local text file
        self.game.save_game_state()
        with open('game_state.txt', 'r') as file:
            content = file.read()
        self.assertIn('score=0', content, "Game state should be successfully written to the text file")

if __name__ == '__main__':
    unittest.main()
