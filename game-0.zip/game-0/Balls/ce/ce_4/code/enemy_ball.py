import random

class EnemyBall:
    def __init__(self, size: float, position: tuple):
        self.size = size
        self.position = position

    @staticmethod
    def spawn_random_ball(max_size: float, canvas_width: int, canvas_height: int):
        size = random.uniform(10, max_size)
        position = (random.randint(0, canvas_width), random.randint(0, canvas_height))
        return EnemyBall(size, position)