import pygame
import random

class PlayerBall:
    def __init__(self, size: float, position: tuple):
        self.size = size
        self.position = position

    def move(self, direction: str):
        if direction == 'UP':
            self.position = (self.position[0], self.position[1] - 5)
        elif direction == 'DOWN':
            self.position = (self.position[0], self.position[1] + 5)
        elif direction == 'LEFT':
            self.position = (self.position[0] - 5, self.position[1])
        elif direction == 'RIGHT':
            self.position = (self.position[0] + 5, self.position[1])

    def grow(self, amount: float):
        self.size += amount

class EnemyBall:
    def __init__(self, size: float, position: tuple):
        self.size = size
        self.position = position

    def move(self):
        self.position = (self.position[0] + random.choice([-1, 1]), self.position[1] + random.choice([-1, 1]))

class Game:
    def __init__(self):
        self.player_ball = PlayerBall(size=20, position=(400, 300))
        self.enemy_balls = []

    def run(self):
        pygame.init()
        screen = pygame.display.set_mode((800, 600))
        pygame.display.set_caption("Battle of Balls")
        clock = pygame.time.Clock()
        running = True

        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_UP:
                        self.player_ball.move('UP')
                    elif event.key == pygame.K_DOWN:
                        self.player_ball.move('DOWN')
                    elif event.key == pygame.K_LEFT:
                        self.player_ball.move('LEFT')
                    elif event.key == pygame.K_RIGHT:
                        self.player_ball.move('RIGHT')

            self.update()
            screen.fill((255, 255, 255))
            self.draw(screen)
            pygame.display.flip()
            clock.tick(60)

        pygame.quit()

    def update(self):
        self.check_collisions()
        self.spawn_enemy_balls()

    def check_collisions(self):
        # Collision logic can be implemented here
        pass

    def spawn_enemy_balls(self):
        if len(self.enemy_balls) < 5:
            size = random.randint(10, 30)
            position = (random.randint(0, 800), random.randint(0, 600))
            self.enemy_balls.append(EnemyBall(size, position))

    def draw(self, screen):
        pygame.draw.circle(screen, (0, 0, 255), self.player_ball.position, int(self.player_ball.size))
        for enemy in self.enemy_balls:
            pygame.draw.circle(screen, (255, 0, 0), enemy.position, int(enemy.size))