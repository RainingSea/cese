import random

class EnemyBall:
    def __init__(self, size: float, position: tuple):
        self.size = size
        self.position = position

    @staticmethod
    def spawn_random_ball(canvas_width: int, canvas_height: int) -> 'EnemyBall':
        size = random.uniform(10, 30)  # Random size between 10 and 30
        position = (random.randint(0, canvas_width), random.randint(0, canvas_height))
        return EnemyBall(size, position)