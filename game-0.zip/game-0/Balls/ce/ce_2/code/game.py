import pygame
from player_ball import PlayerBall
from enemy_ball import EnemyBall

class Game:
    def __init__(self):
        self.player_ball = PlayerBall(size=20, position=(400, 300))
        self.enemy_balls = []
        self.load_game_state()

    def run(self) -> None:
        pygame.init()
        screen = pygame.display.set_mode((800, 600))
        clock = pygame.time.Clock()
        running = True

        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_UP:
                        self.player_ball.move('up')
                    elif event.key == pygame.K_DOWN:
                        self.player_ball.move('down')
                    elif event.key == pygame.K_LEFT:
                        self.player_ball.move('left')
                    elif event.key == pygame.K_RIGHT:
                        self.player_ball.move('right')

            self.update()
            screen.fill((255, 255, 255))
            self.draw(screen)
            pygame.display.flip()
            clock.tick(60)

        self.save_game_state()
        pygame.quit()

    def update(self) -> None:
        self.check_collisions()
        if len(self.enemy_balls) < 5:  # Limit the number of enemy balls
            self.spawn_enemy_balls()

    def check_collisions(self) -> None:
        for enemy in self.enemy_balls:
            if self._is_colliding(self.player_ball, enemy):
                self.player_ball.grow(5)  # Grow the player ball on collision
                self.enemy_balls.remove(enemy)  # Remove the enemy ball

    def _is_colliding(self, player: PlayerBall, enemy: EnemyBall) -> bool:
        distance = ((player.position[0] - enemy.position[0]) ** 2 + 
                    (player.position[1] - enemy.position[1]) ** 2) ** 0.5
        return distance < (player.size + enemy.size)

    def spawn_enemy_balls(self) -> None:
        new_enemy = EnemyBall.spawn_random_ball(800, 600)
        self.enemy_balls.append(new_enemy)

    def load_game_state(self) -> None:
        try:
            with open('game_state.txt', 'r') as file:
                data = file.readlines()
                self.player_ball.size = float(data[0].strip().split('=')[1])
                self.player_ball.position = tuple(map(int, data[1].strip().split('=')[1].strip('()').split(',')))
                self.enemy_balls = [EnemyBall(float(line.split('=')[1]), 
                                              tuple(map(int, line.split('=')[2].strip().strip('()').split(','))))
                                   for line in data[2:]]
        except FileNotFoundError:
            pass

    def save_game_state(self) -> None:
        with open('game_state.txt', 'w') as file:
            file.write(f'size={self.player_ball.size}\n')
            file.write(f'position={self.player_ball.position}\n')
            for enemy in self.enemy_balls:
                file.write(f'enemy_size={enemy.size} enemy_position={enemy.position}\n')