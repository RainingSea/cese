class PlayerBall:
    def __init__(self, size: float, position: tuple):
        self.size = size
        self.position = position

    def move(self, direction: str) -> None:
        if direction == 'up':
            self.position = (self.position[0], self.position[1] - 5)
        elif direction == 'down':
            self.position = (self.position[0], self.position[1] + 5)
        elif direction == 'left':
            self.position = (self.position[0] - 5, self.position[1])
        elif direction == 'right':
            self.position = (self.position[0] + 5, self.position[1])

    def grow(self, amount: float) -> None:
        self.size += amount