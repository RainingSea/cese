import pygame
from game import Game

def main():
    """Initialize the game and run the main loop."""
    pygame.init()
    game = Game()
    game.run()
    pygame.quit()

if __name__ == "__main__":
    main()