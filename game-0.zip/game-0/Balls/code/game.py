import pygame
import json
import os
from random import randint

class PlayerBall:
    def __init__(self, size: int, position_x: int, position_y: int):
        """Initialize the player ball with size and position."""
        self.size = size
        self.position_x = position_x
        self.position_y = position_y

    def move(self, direction: str) -> None:
        """Move the player ball in the specified direction."""
        if direction == "UP":
            self.position_y -= 5
        elif direction == "DOWN":
            self.position_y += 5
        elif direction == "LEFT":
            self.position_x -= 5
        elif direction == "RIGHT":
            self.position_x += 5

    def grow(self, amount: int) -> None:
        """Grow the player ball by the specified amount."""
        self.size += amount


class EnemyBall:
    def __init__(self, size: int, position_x: int, position_y: int):
        """Initialize the enemy ball with size and position."""
        self.size = size
        self.position_x = position_x
        self.position_y = position_y

    def move(self) -> None:
        """Randomly move the enemy ball within a small range."""
        self.position_x += randint(-2, 2)
        self.position_y += randint(-2, 2)

    @staticmethod
    def spawn() -> 'EnemyBall':
        """Spawn an enemy ball at a random position."""
        return EnemyBall(size=randint(5, 30), position_x=randint(0, 600), position_y=randint(0, 600))


class Game:
    def __init__(self):
        """Initialize the game entities and load the game state."""
        self.player_ball = PlayerBall(size=20, position_x=400, position_y=300)
        self.enemy_balls = [EnemyBall.spawn() for _ in range(5)]
        self.is_game_over = False
        self.score = 0
        self.load_game_state()

    def run(self) -> None:
        """Run the main game loop."""
        screen = pygame.display.set_mode((600, 600))
        pygame.display.set_caption("Ball Game")
        clock = pygame.time.Clock()

        while not self.is_game_over:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.is_game_over = True

            keys = pygame.key.get_pressed()
            if keys[pygame.K_UP]:
                self.player_ball.move("UP")
            if keys[pygame.K_DOWN]:
                self.player_ball.move("DOWN")
            if keys[pygame.K_LEFT]:
                self.player_ball.move("LEFT")
            if keys[pygame.K_RIGHT]:
                self.player_ball.move("RIGHT")

            self.check_collisions()
            self.update_game_state()

            screen.fill((255, 255, 255))
            pygame.draw.circle(screen, (0, 0, 255), (self.player_ball.position_x, self.player_ball.position_y), self.player_ball.size)
            for enemy in self.enemy_balls:
                pygame.draw.circle(screen, (255, 0, 0), (enemy.position_x, enemy.position_y), enemy.size)

            pygame.display.flip()
            clock.tick(60)

        self.save_game_state()

    def check_collisions(self) -> None:
        """Check for collisions between the player ball and enemy balls."""
        for enemy in self.enemy_balls[:]:  # Iterate over a copy of the list
            distance = ((self.player_ball.position_x - enemy.position_x) ** 2 + (self.player_ball.position_y - enemy.position_y) ** 2) ** 0.5
            if distance < (self.player_ball.size + enemy.size):
                if enemy.size > self.player_ball.size:  # Ensure player can only consume smaller enemies
                    self.player_ball.grow(5)
                    self.score += 1
                    self.enemy_balls.remove(enemy)  # Remove enemy ball after collision

    def update_game_state(self) -> None:
        """Update the game state and check for game over conditions."""
        if self.player_ball.size > 50:  # Example game over condition
            self.is_game_over = True

    def load_game_state(self) -> None:
        """Load the game state from a file."""
        if os.path.exists('game_state.json'):
            with open('game_state.json', 'r') as file:
                data = json.load(file)
                self.player_ball.size = data['player_size']
                self.player_ball.position_x = data['position_x']
                self.player_ball.position_y = data['position_y']
                self.enemy_balls = [EnemyBall(size=enemy['size'], position_x=enemy['position'][0], position_y=enemy['position'][1]) for enemy in data['enemies']]

    def save_game_state(self) -> None:
        """Save the current game state to a file."""
        data = {
            'player_size': self.player_ball.size,
            'position_x': self.player_ball.position_x,
            'position_y': self.player_ball.position_y,
            'enemies': [{'size': enemy.size, 'position': (enemy.position_x, enemy.position_y)} for enemy in self.enemy_balls]
        }
        with open('game_state.json', 'w') as file:
            json.dump(data, file)