import pygame

class Ball:
    def __init__(self, position: int, velocity: int):
        self.x = position
        self.y = 300  # Starting at the center vertically
        self.dx = velocity
        self.dy = -velocity
        self.radius = 10
        self.color = (255, 255, 255)

    def move(self):
        self.x += self.dx
        self.y += self.dy

    def draw(self, screen):
        pygame.draw.circle(screen, self.color, (self.x, self.y), self.radius)

    def bounce(self):
        self.dy = -self.dy