import pygame
from game import Game

def main():
    game = Game()
    game.start_game()
    
    running = True
    clock = pygame.time.Clock()  # Control frame rate
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    game.paddle.move('left')
                if event.key == pygame.K_RIGHT:
                    game.paddle.move('right')

        game.update()
        game.draw()
        clock.tick(60)  # Limit to 60 frames per second
    
    game.save_game_data()
    pygame.quit()

if __name__ == "__main__":
    main()