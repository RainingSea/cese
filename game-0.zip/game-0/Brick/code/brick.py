import pygame

class Brick:
    def __init__(self, lives: int):
        self.lives = lives
        self.width = 75
        self.height = 30
        self.color = (255, 0, 0)
        self.position = (0, 0)  # Initialize position

    def hit(self):
        self.lives -= 1

    def is_destroyed(self) -> bool:
        return self.lives <= 0

    def draw(self, screen, position):
        self.position = position  # Update position
        if not self.is_destroyed():
            pygame.draw.rect(screen, self.color, (self.position[0], self.position[1], self.width, self.height))