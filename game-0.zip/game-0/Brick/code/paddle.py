import pygame

class Paddle:
    def __init__(self, position: int, width: int = 100):
        self.position = position
        self.width = width
        self.height = 20
        self.color = (255, 255, 255)

    def move(self, direction: str):
        if direction == 'left' and self.position > 0:
            self.position -= 10
        elif direction == 'right' and self.position < 800 - self.width:  # Assuming the screen width is 800
            self.position += 10

    def draw(self, screen):
        pygame.draw.rect(screen, self.color, (self.position, 580, self.width, self.height))  # Assuming the screen height is 600