import pygame
import json
from paddle import Paddle
from ball import Ball
from brick import Brick

class Game:
    def __init__(self):
        self.paddle = Paddle(350)
        self.ball = Ball(400, 5)
        self.bricks = [Brick(1) for _ in range(10)]  # 10 bricks
        self.score = 0
        self.state = "running"
        self.width = 800
        self.height = 600
        self.load_game_data()

    def start_game(self):
        pygame.init()
        self.screen = pygame.display.set_mode((self.width, self.height))
        pygame.display.set_caption("Brick Breaker")

    def update(self):
        self.ball.move()
        self.check_collisions()
        self.check_end_game_condition()

    def draw(self):
        self.screen.fill((0, 0, 0))
        self.paddle.draw(self.screen)
        self.ball.draw(self.screen)
        for i, brick in enumerate(self.bricks):
            brick.draw(self.screen, (i * 80 + 10, 50))  # Positioning bricks
        pygame.display.flip()

    def check_collisions(self):
        # Check ball collision with paddle
        if (self.ball.y + self.ball.radius >= 580 and
                self.paddle.position <= self.ball.x <= self.paddle.position + self.paddle.width):
            self.ball.bounce()

        # Check ball collision with bricks
        for i in range(len(self.bricks)):
            brick = self.bricks[i]
            if not brick.is_destroyed():
                if (brick.position[1] <= self.ball.y <= brick.position[1] + brick.height and
                        brick.position[0] <= self.ball.x <= brick.position[0] + brick.width):
                    brick.hit()
                    self.ball.bounce()
                    if brick.is_destroyed():
                        self.score += 1
                        self.bricks[i] = None  # Mark brick for removal

        # Remove destroyed bricks
        self.bricks = [brick for brick in self.bricks if brick is not None]

    def check_end_game_condition(self):
        if self.ball.y >= self.height:
            self.state = "game_over"  # Set game state to game over
            self.ball = Ball(self.width // 2, 5)  # Reset ball position

    def load_game_data(self):
        try:
            with open('game_data.json', 'r') as f:
                data = json.load(f)
                self.score = data.get('score', 0)
        except FileNotFoundError:
            self.score = 0  # Default score if no file exists

    def save_game_data(self):
        with open('game_data.json', 'w') as f:
            json.dump({'score': self.score}, f)

    def load_game_state(self):
        try:
            with open('game_state.json', 'r') as f:
                data = json.load(f)
                self.paddle.position = data.get('paddle_position', 350)
                self.ball.x = data.get('ball_x', 400)
                self.ball.y = data.get('ball_y', 300)
                self.score = data.get('score', 0)
                self.bricks = [Brick(lives) for lives in data.get('bricks', [1]*10)]
        except FileNotFoundError:
            pass  # No saved state to load