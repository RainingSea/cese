import pygame
from paddle import Paddle
from ball import Ball
from brick import Brick

class Game:
    def __init__(self):
        self.width = 800
        self.height = 600
        self.screen = pygame.display.set_mode((self.width, self.height))
        self.clock = pygame.time.Clock()
        self.paddle = Paddle(self.width // 2, self.height - 30)
        self.ball = Ball(self.width // 2, self.height - 50)
        self.bricks = self.create_bricks()
        self.lives = 3

    def create_bricks(self):
        bricks = []
        for i in range(5):
            for j in range(10):
                bricks.append(Brick(70 * j + 35, 30 * i + 30, 1))
        return bricks

    def start_game(self):
        running = True
        while running:
            self.update()
            self.draw()
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
            self.clock.tick(60)

    def update(self):
        self.paddle.move_left() if pygame.key.get_pressed()[pygame.K_LEFT] else None
        self.paddle.move_right() if pygame.key.get_pressed()[pygame.K_RIGHT] else None
        self.ball.move()
        self.check_collisions()

    def draw(self):
        self.screen.fill((0, 0, 0))
        self.paddle.draw(self.screen)
        self.ball.draw(self.screen)
        for brick in self.bricks:
            brick.draw(self.screen)
        pygame.display.flip()

    def check_collisions(self):
        # Check for collisions with paddle
        if self.ball.position_y >= self.height - 30:
            self.lives -= 1
            self.ball.reset_position()
        # Check for collisions with bricks
        for brick in self.bricks:
            if self.ball.position_x in range(brick.position_x, brick.position_x + 70) and \
               self.ball.position_y in range(brick.position_y, brick.position_y + 20):
                brick.hit()
                self.ball.velocity_y *= -1
                if brick.life <= 0:
                    self.bricks.remove(brick)