import pygame

class Ball:
    def __init__(self, position_x, position_y):
        self.position_x = position_x
        self.position_y = position_y
        self.velocity_x = 5
        self.velocity_y = -5
        self.radius = 10

    def move(self):
        self.position_x += self.velocity_x
        self.position_y += self.velocity_y
        if self.position_x <= 0 or self.position_x >= 800:
            self.velocity_x *= -1
        if self.position_y <= 0:
            self.velocity_y *= -1

    def draw(self, screen):
        pygame.draw.circle(screen, (255, 255, 255), (self.position_x, self.position_y), self.radius)

    def reset_position(self):
        self.position_x = 400
        self.position_y = 300
        self.velocity_y *= -1