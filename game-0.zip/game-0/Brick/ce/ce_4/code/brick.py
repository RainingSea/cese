import pygame

class Brick:
    def __init__(self, position_x, position_y, life):
        self.position_x = position_x
        self.position_y = position_y
        self.life = life

    def hit(self):
        self.life -= 1

    def draw(self, screen):
        color = (255, 0, 0) if self.life > 0 else (0, 0, 0)
        pygame.draw.rect(screen, color, (self.position_x, self.position_y, 70, 20))