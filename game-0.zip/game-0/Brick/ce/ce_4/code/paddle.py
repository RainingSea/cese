import pygame

class Paddle:
    def __init__(self, position_x, height):
        self.position_x = position_x
        self.width = 100
        self.height = height

    def move_left(self):
        if self.position_x > 0:
            self.position_x -= 5

    def move_right(self):
        if self.position_x < 800 - self.width:
            self.position_x += 5

    def draw(self, screen):
        pygame.draw.rect(screen, (255, 255, 255), (self.position_x, self.height, self.width, 10))