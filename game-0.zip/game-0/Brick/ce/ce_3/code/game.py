import pygame
from paddle import Paddle
from ball import Ball
from brick import Brick

class Game:
    def __init__(self):
        self.paddle = Paddle(300, 100)
        self.ball = Ball(320, 500)
        self.bricks = [Brick(i, 1) for i in range(10)]
        self.score = 0
        self.load_game_data()

    def run(self):
        pygame.init()
        screen = pygame.display.set_mode((800, 600))
        clock = pygame.time.Clock()
        running = True

        while running:
            self.handle_input()
            self.update()
            self.draw(screen)
            pygame.display.flip()
            clock.tick(60)

        pygame.quit()

    def handle_input(self):
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            self.paddle.move('left')
        if keys[pygame.K_RIGHT]:
            self.paddle.move('right')

    def update(self):
        self.ball.move()
        # Add collision detection and game logic here

    def draw(self, surface):
        surface.fill((0, 0, 0))
        self.paddle.draw(surface)
        self.ball.draw(surface)
        for brick in self.bricks:
            brick.draw(surface)

    def load_game_data(self):
        try:
            with open('game_data.txt', 'r') as file:
                for line in file:
                    brick_id, life = map(int, line.strip().split(':'))
                    self.bricks[brick_id].life = life
        except FileNotFoundError:
            pass

    def save_game_data(self):
        with open('game_data.txt', 'w') as file:
            for brick in self.bricks:
                file.write(f"{brick.id}:{brick.life}\n")