import pygame

class Brick:
    def __init__(self, id: int, life: int):
        self.id = id
        self.life = life

    def hit(self):
        self.life -= 1

    def draw(self, surface):
        color = (255, 0, 0) if self.life > 0 else (0, 0, 0)
        pygame.draw.rect(surface, color, (self.id * 60, 50, 50, 20))