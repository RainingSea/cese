import pygame
import os

class Paddle:
    def __init__(self, x: int, y: int, width: int, height: int):
        self.x = x
        self.y = y
        self.width = width
        self.height = height

    def move_left(self):
        self.x -= 10

    def move_right(self):
        self.x += 10

    def draw(self, screen):
        pygame.draw.rect(screen, (255, 255, 255), (self.x, self.y, self.width, self.height))


class Ball:
    def __init__(self, x: int, y: int, radius: int):
        self.x = x
        self.y = y
        self.radius = radius
        self.dx = 5
        self.dy = -5

    def move(self):
        self.x += self.dx
        self.y += self.dy

    def draw(self, screen):
        pygame.draw.circle(screen, (255, 255, 255), (self.x, self.y), self.radius)


class Brick:
    def __init__(self, x: int, y: int, width: int, height: int, lives: int):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.lives = lives

    def hit(self):
        self.lives -= 1

    def draw(self, screen):
        color = (255, 0, 0) if self.lives > 0 else (0, 0, 0)
        pygame.draw.rect(screen, color, (self.x, self.y, self.width, self.height))


class Game:
    def __init__(self, width: int, height: int):
        self.width = width
        self.height = height
        self.paddle = Paddle(width // 2 - 50, height - 30, 100, 10)
        self.ball = Ball(width // 2, height // 2, 10)
        self.bricks = self.load_game_data()

    def run(self):
        pygame.init()
        screen = pygame.display.set_mode((self.width, self.height))
        clock = pygame.time.Clock()
        running = True

        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False

            keys = pygame.key.get_pressed()
            if keys[pygame.K_LEFT] and self.paddle.x > 0:
                self.paddle.move_left()
            if keys[pygame.K_RIGHT] and self.paddle.x < self.width - self.paddle.width:
                self.paddle.move_right()

            self.ball.move()
            self.check_collisions()
            self.draw(screen)
            pygame.display.flip()
            clock.tick(60)

        self.save_game_data()
        pygame.quit()

    def draw(self, screen):
        screen.fill((0, 0, 0))
        self.paddle.draw(screen)
        self.ball.draw(screen)
        for brick in self.bricks:
            brick.draw(screen)

    def check_collisions(self):
        if self.ball.x <= 0 or self.ball.x >= self.width:
            self.ball.dx *= -1
        if self.ball.y <= 0:
            self.ball.dy *= -1
        if self.ball.y >= self.height:
            self.ball.dy *= -1  # Ball falls below the paddle

        # Paddle collision
        if (self.paddle.x < self.ball.x < self.paddle.x + self.paddle.width and
                self.paddle.y < self.ball.y + self.ball.radius < self.paddle.y + self.paddle.height):
            self.ball.dy *= -1

        # Brick collision
        for brick in self.bricks:
            if (brick.x < self.ball.x < brick.x + brick.width and
                    brick.y < self.ball.y + self.ball.radius < brick.y + brick.height and brick.lives > 0):
                brick.hit()
                self.ball.dy *= -1

    def load_game_data(self):
        bricks = []
        if os.path.exists('game_data.txt'):
            with open('game_data.txt', 'r') as file:
                for line in file:
                    x, y, lives = map(int, line.strip().split('|'))
                    bricks.append(Brick(x, y, 60, 20, lives))
        else:
            for i in range(5):
                for j in range(10):
                    bricks.append(Brick(j * 62, i * 22, 60, 20, 1))
        return bricks

    def save_game_data(self):
        with open('game_data.txt', 'w') as file:
            for brick in self.bricks:
                file.write(f"{brick.x}|{brick.y}|{brick.lives}\n")