import pygame
import os

class Brick:
    def __init__(self, x: int, y: int, lives: int):
        self.x = x
        self.y = y
        self.lives = lives

    def hit(self):
        self.lives -= 1

    def draw(self, screen):
        if self.lives > 0:
            pygame.draw.rect(screen, (255, 0, 0), (self.x, self.y, 60, 20))

class Paddle:
    def __init__(self, x: int, width: int):
        self.x = x
        self.width = width

    def move_left(self):
        self.x -= 10

    def move_right(self):
        self.x += 10

    def draw(self, screen):
        pygame.draw.rect(screen, (0, 0, 255), (self.x, 580, self.width, 10))

class Ball:
    def __init__(self, x: int, y: int):
        self.x = x
        self.y = y
        self.dx = 5
        self.dy = -5

    def update(self):
        self.x += self.dx
        self.y += self.dy

    def draw(self, screen):
        pygame.draw.circle(screen, (0, 255, 0), (self.x, self.y), 10)

    def bounce(self):
        self.dy = -self.dy

class Game:
    def __init__(self, width: int, height: int):
        self.width = width
        self.height = height
        self.paddle = Paddle(width // 2 - 30, 60)
        self.ball = Ball(width // 2, height // 2)
        self.bricks = []
        self.load_bricks()

    def run(self):
        pygame.init()
        screen = pygame.display.set_mode((self.width, self.height))
        clock = pygame.time.Clock()
        running = True

        while running:
            self.handle_input()
            self.update()
            self.draw(screen)
            pygame.display.flip()
            clock.tick(60)

        pygame.quit()

    def handle_input(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()

        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] and self.paddle.x > 0:
            self.paddle.move_left()
        if keys[pygame.K_RIGHT] and self.paddle.x < self.width - self.paddle.width:
            self.paddle.move_right()

    def update(self):
        self.ball.update()
        if self.ball.x <= 0 or self.ball.x >= self.width:
            self.ball.dx = -self.ball.dx
        if self.ball.y <= 0:
            self.ball.bounce()
        if self.ball.y >= self.height:
            self.ball = Ball(self.width // 2, self.height // 2)  # Reset ball position

        # Check for collision with paddle
        if (self.paddle.x < self.ball.x < self.paddle.x + self.paddle.width and
                self.ball.y >= 570):
            self.ball.bounce()

        # Check for collision with bricks
        for brick in self.bricks:
            if (brick.x < self.ball.x < brick.x + 60 and
                    brick.y < self.ball.y < brick.y + 20):
                brick.hit()
                self.ball.bounce()

    def draw(self, screen):
        screen.fill((0, 0, 0))
        self.paddle.draw(screen)
        self.ball.draw(screen)
        for brick in self.bricks:
            brick.draw(screen)

    def load_bricks(self):
        if os.path.exists('bricks.txt'):
            with open('bricks.txt', 'r') as file:
                for line in file:
                    x, y, lives = map(int, line.strip().split('|'))
                    self.bricks.append(Brick(x, y, lives))

    def save_bricks(self):
        with open('bricks.txt', 'w') as file:
            for brick in self.bricks:
                file.write(f"{brick.x}|{brick.y}|{brick.lives}\n")