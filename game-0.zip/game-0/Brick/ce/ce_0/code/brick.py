class Brick:
    def __init__(self, id: int, life: int):
        self.id = id
        self.life = life

    def hit(self):
        if self.life > 0:
            self.life -= 1

    def draw(self, surface):
        color = (255, 0, 0) if self.life > 0 else (0, 0, 0)
        width = 60
        height = 20
        x = (self.id % 10) * (width + 5) + 20
        y = (self.id // 10) * (height + 5) + 20
        pygame.draw.rect(surface, color, (x, y, width, height))