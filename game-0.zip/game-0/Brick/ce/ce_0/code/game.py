import pygame
from paddle import Paddle
from ball import Ball
from brick import Brick

class Game:
    def __init__(self):
        self.paddle = Paddle(300, 100)
        self.ball = Ball(400, 300)
        self.bricks = [Brick(i, 1) for i in range(30)]

    def run(self):
        pygame.init()
        screen = pygame.display.set_mode((800, 600))
        clock = pygame.time.Clock()
        running = True

        while running:
            self.handle_input()
            self.update()
            self.draw(screen)
            pygame.display.flip()
            clock.tick(60)

        pygame.quit()

    def handle_input(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()

        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            self.paddle.move('left')
        if keys[pygame.K_RIGHT]:
            self.paddle.move('right')

    def update(self):
        self.ball.move()
        if self.ball.x <= 0 or self.ball.x >= 800:
            self.ball.dx *= -1
        if self.ball.y <= 0:
            self.ball.dy *= -1
        if self.ball.y >= 600:
            self.ball = Ball(400, 300)  # Reset ball position

    def draw(self, surface):
        surface.fill((0, 0, 0))
        self.paddle.draw(surface)
        self.ball.draw(surface)
        for brick in self.bricks:
            brick.draw(surface)