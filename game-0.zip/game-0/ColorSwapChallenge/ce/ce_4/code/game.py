import pygame
import random

class Block:
    def __init__(self, color: str):
        self.color = color

class Grid:
    def __init__(self):
        self.blocks = []

    def initialize_grid(self, size: int, colors: list) -> None:
        self.blocks = [[Block(random.choice(colors)) for _ in range(size)] for _ in range(size)]

    def get_block(self, pos: tuple) -> Block:
        x, y = pos
        return self.blocks[y][x]

    def set_block(self, pos: tuple, block: Block) -> None:
        x, y = pos
        self.blocks[y][x] = block

class Score:
    def __init__(self):
        self.points = 0

    def add_points(self, points: int) -> None:
        self.points += points

    def get_score(self) -> int:
        return self.points

class Level:
    def __init__(self):
        self.level_data = {}

    def load_level_data(self, file_path: str) -> dict:
        with open(file_path, 'r') as file:
            data = file.readlines()
            for line in data:
                level_info = line.strip().split('|')
                self.level_data[int(level_info[0])] = {
                    'size': int(level_info[1]),
                    'colors': level_info[2].split(','),
                    'moves': int(level_info[3])
                }
        return self.level_data

class Game:
    def __init__(self):
        self.grid = Grid()
        self.score = Score()
        self.level = Level()

    def start_game(self, level_number: int) -> None:
        level_data = self.level.load_level_data('levels.txt')
        level_info = level_data[level_number]
        self.grid.initialize_grid(level_info['size'], level_info['colors'])
        self.moves_left = level_info['moves']

    def swap_blocks(self, pos1: tuple, pos2: tuple) -> bool:
        block1 = self.grid.get_block(pos1)
        block2 = self.grid.get_block(pos2)
        self.grid.set_block(pos1, block2)
        self.grid.set_block(pos2, block1)
        return True

    def check_matches(self) -> list:
        # Placeholder for match checking logic
        return []

    def clear_matches(self, matches: list) -> None:
        for match in matches:
            for pos in match:
                self.grid.set_block(pos, Block(random.choice(['red', 'green', 'blue', 'yellow', 'purple'])))

    def load_level(self, level_number: int) -> None:
        self.start_game(level_number)

    def save_score(self, player_name: str, score: int) -> None:
        with open('scores.txt', 'a') as file:
            file.write(f"{player_name}|{score}\n")