import pygame
from game import Game

def main() -> str:
    pygame.init()
    game = Game()
    game.load_level(1)  # Load the first level
    # Main game loop and event handling would go here
    return "Game started"

if __name__ == "__main__":
    main()