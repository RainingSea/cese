[OUTPUT]
## general overview of the project
Develop a Color Swap Challenge game. You must design a GUI.

## software functional requirements
1. The game shall allow the player to control a grid of colored blocks.
2. The player shall be able to swap adjacent blocks to create matches of three or more blocks of the same color.
3. The game shall set an objective to clear the board by eliminating a certain number of blocks within a limited number of moves.
4. The game shall automatically clear matches when three or more blocks of the same color are aligned horizontally or vertically.
5. The game shall include multiple levels with increasing difficulty, such as larger grids, more complex block arrangements, and additional color types.
6. The game shall allow players to earn bonus points by creating combos (clearing multiple matches in a single move) or activating power-ups that clear blocks in specific patterns.
7. The game shall track the number of moves used to complete each level, and players must complete the level within the move limit.
8. The game shall allow players to use power-ups strategically to help clear the board, and players can earn or unlock new power-ups as they progress.
9. The game shall feature a scoring system based on the number of blocks cleared, combos achieved, and the number of moves used to complete each level.
[/OUTPUT]