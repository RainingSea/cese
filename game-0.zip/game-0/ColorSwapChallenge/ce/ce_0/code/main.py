import pygame
from game import Game, Score, Level

def main():
    pygame.init()
    screen = pygame.display.set_mode((800, 600))
    pygame.display.set_caption("Color Block Game")

    # Load level data
    level_data = {'objective': 100, 'grid_size': 8}
    level = Level(level_data['objective'], level_data['grid_size'])
    score = Score(0, 20)
    game = Game(level, score)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        # Game logic would go here

        pygame.display.flip()

    pygame.quit()

if __name__ == "__main__":
    main()