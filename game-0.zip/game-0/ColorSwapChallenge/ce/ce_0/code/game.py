import random

class Score:
    def __init__(self, initial_points: int, move_limit: int) -> None:
        self.points = initial_points
        self.moves_left = move_limit

    def add_points(self, points: int) -> None:
        self.points += points

    def decrement_move(self) -> None:
        self.moves_left -= 1

class Level:
    def __init__(self, objective: int, grid_size: int) -> None:
        self.objective = objective
        self.grid_size = grid_size

    def load_level(self, level_data: dict) -> None:
        self.objective = level_data['objective']
        self.grid_size = level_data['grid_size']

class Grid:
    def __init__(self, size: int, colors: list) -> None:
        self.blocks = [[random.choice(colors) for _ in range(size)] for _ in range(size)]

    def swap(self, pos1: tuple, pos2: tuple) -> bool:
        x1, y1 = pos1
        x2, y2 = pos2
        if abs(x1 - x2) + abs(y1 - y2) == 1:  # Check if positions are adjacent
            self.blocks[x1][y1], self.blocks[x2][y2] = self.blocks[x2][y2], self.blocks[x1][y1]
            return True
        return False

    def get_matches(self) -> list:
        matches = []
        # Check for horizontal matches
        for row in self.blocks:
            for i in range(len(row) - 2):
                if row[i] == row[i + 1] == row[i + 2]:
                    matches.append((self.blocks.index(row), i))
        # Check for vertical matches
        for col in range(len(self.blocks[0])):
            for i in range(len(self.blocks) - 2):
                if self.blocks[i][col] == self.blocks[i + 1][col] == self.blocks[i + 2][col]:
                    matches.append((i, col))
        return matches

class Game:
    def __init__(self, level: Level, score: Score) -> None:
        self.grid = Grid(level.grid_size, ['red', 'green', 'blue', 'yellow', 'purple'])
        self.score = score
        self.level = level

    def run(self) -> None:
        # Game loop would go here
        pass

    def swap_blocks(self, pos1: tuple, pos2: tuple) -> bool:
        return self.grid.swap(pos1, pos2)

    def check_matches(self) -> list:
        return self.grid.get_matches()

    def clear_matches(self, matches: list) -> None:
        for match in matches:
            x, y = match
            self.grid.blocks[x][y] = None  # Clear the matched block
            self.score.add_points(10)  # Add points for clearing a match

    def update_score(self, points: int) -> None:
        self.score.add_points(points)