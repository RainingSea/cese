import pygame
import random
import json
from typing import List, Tuple

class Block:
    def __init__(self, color: str) -> None:
        self.color = color

class Score:
    def __init__(self) -> None:
        self.points = 0

    def add_points(self, points: int) -> None:
        self.points += points

    def get_score(self) -> int:
        return self.points

class Level:
    def __init__(self) -> None:
        self.difficulty = 0
        self.objective = 0
        self.grid_size = 0
        self.colors = []

    def load_level(self, level_number: int) -> None:
        with open('levels.json', 'r') as file:
            levels = json.load(file)
            self.difficulty = levels[str(level_number)]['difficulty']
            self.objective = levels[str(level_number)]['objective']
            self.grid_size = levels[str(level_number)]['grid_size']
            self.colors = levels[str(level_number)]['colors']

    def next_level(self) -> None:
        self.difficulty += 1

class Grid:
    def __init__(self) -> None:
        self.blocks = []

    def create_grid(self, size: int, colors: List[str]) -> None:
        self.blocks = [[Block(random.choice(colors)) for _ in range(size)] for _ in range(size)]

    def get_block(self, pos: Tuple[int, int]) -> Block:
        x, y = pos
        return self.blocks[y][x]

    def set_block(self, pos: Tuple[int, int], block: Block) -> None:
        x, y = pos
        self.blocks[y][x] = block

    def clear_matches(self) -> None:
        matches = self.find_matches()
        self.remove_matches(matches)

    def find_matches(self) -> List[List[Tuple[int, int]]]:
        matches = []
        for y in range(len(self.blocks)):
            for x in range(len(self.blocks[y])):
                if x < len(self.blocks[y]) - 2 and self.blocks[y][x].color == self.blocks[y][x + 1].color == self.blocks[y][x + 2].color:
                    matches.append([(x, y), (x + 1, y), (x + 2, y)])
                if y < len(self.blocks) - 2 and self.blocks[y][x].color == self.blocks[y + 1][x].color == self.blocks[y + 2][x].color:
                    matches.append([(x, y), (x, y + 1), (x, y + 2)])
        return matches

    def remove_matches(self, matches: List[List[Tuple[int, int]]]) -> int:
        for match in matches:
            for pos in match:
                self.set_block(pos, Block(random.choice(self.colors)))
        return len(matches)

class Game:
    def __init__(self) -> None:
        self.grid = Grid()
        self.score = Score()
        self.level = Level()
        self.moves_left = 20  # Initialize moves left

    def start_game(self) -> None:
        self.level.load_level(1)
        self.grid.create_grid(self.level.grid_size, self.level.colors)
        self.run_game_loop()

    def run_game_loop(self) -> None:
        while self.moves_left > 0:
            # Placeholder for the game loop logic
            pass

    def swap_blocks(self, pos1: Tuple[int, int], pos2: Tuple[int, int]) -> None:
        block1 = self.grid.get_block(pos1)
        block2 = self.grid.get_block(pos2)
        self.grid.set_block(pos1, block2)
        self.grid.set_block(pos2, block1)
        matches = self.check_matches()
        if matches:
            self.clear_matches(matches)
        self.moves_left -= 1  # Decrement moves left after a swap

    def check_matches(self) -> List[List[Tuple[int, int]]]:
        return self.grid.find_matches()

    def clear_matches(self, matches: List[List[Tuple[int, int]]]) -> None:
        cleared_count = self.grid.remove_matches(matches)
        self.score.add_points(cleared_count * 10)

    def save_score(self, player_name: str) -> None:
        with open('scores.txt', 'a') as file:
            file.write(f"{player_name}|{self.score.get_score()}\n")

    def load_scores(self) -> List[Tuple[str, int]]:
        scores = []
        with open('scores.txt', 'r') as file:
            for line in file:
                name, score = line.strip().split('|')
                scores.append((name, int(score)))
        return scores