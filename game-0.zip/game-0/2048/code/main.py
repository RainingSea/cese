import pygame
from game import Game

# Constants
WINDOW_SIZE = 400
GRID_SIZE = 4
TILE_SIZE = WINDOW_SIZE // GRID_SIZE
BACKGROUND_COLOR = (187, 173, 160)
FONT_COLOR = (255, 255, 255)

class GameUI:
    def __init__(self):
        pygame.init()
        self.window = pygame.display.set_mode((WINDOW_SIZE, WINDOW_SIZE))
        pygame.display.set_caption("2048 Game")
        self.game = Game()
        self.font = pygame.font.Font(None, 36)
        self.running = True

    def draw_board(self):
        self.window.fill(BACKGROUND_COLOR)
        for i in range(GRID_SIZE):
            for j in range(GRID_SIZE):
                tile_value = self.game.board.get_grid()[i][j]
                self.draw_tile(i, j, tile_value)
        score_text = self.font.render(f'Score: {self.game.score}', True, FONT_COLOR)
        self.window.blit(score_text, (10, 10))
        pygame.display.flip()

    def draw_tile(self, i, j, value):
        if value == 0:
            return
        color = self.get_tile_color(value)
        pygame.draw.rect(self.window, color, (j * TILE_SIZE, i * TILE_SIZE, TILE_SIZE, TILE_SIZE))
        text = self.font.render(str(value), True, FONT_COLOR)
        text_rect = text.get_rect(center=(j * TILE_SIZE + TILE_SIZE // 2, i * TILE_SIZE + TILE_SIZE // 2))
        self.window.blit(text, text_rect)

    def get_tile_color(self, value):
        colors = {
            2: (238, 228, 218),
            4: (237, 224, 200),
            8: (242, 177, 121),
            16: (245, 149, 99),
            32: (246, 124, 95),
            64: (246, 94, 59),
            128: (237, 207, 114),
            256: (237, 204, 97),
            512: (237, 200, 80),
            1024: (237, 197, 63),
            2048: (237, 194, 46),
        }
        return colors.get(value, (60, 58, 50))  # Default color for larger tiles

    def run(self):
        while self.running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_LEFT:
                        self.game.move('left')
                    elif event.key == pygame.K_RIGHT:
                        self.game.move('right')
                    elif event.key == pygame.K_UP:
                        self.game.move('up')
                    elif event.key == pygame.K_DOWN:
                        self.game.move('down')
                    if self.game.check_game_over():
                        print("Game Over!")
            self.draw_board()
        pygame.quit()

if __name__ == "__main__":
    game_ui = GameUI()
    game_ui.run()