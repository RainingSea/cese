import random

class Board:
    def __init__(self):
        self.grid = [[0] * 4 for _ in range(4)]  # Initialize a 4x4 grid with zeroes.
        self.initialize_board()                   # Call method to set up the initial board.

    def initialize_board(self) -> None:
        for _ in range(2):                       # Generate two initial tiles.
            self.add_random_tile()

    def add_random_tile(self) -> None:
        empty_cells = [(i, j) for i in range(4) for j in range(4) if self.grid[i][j] == 0]
        if empty_cells:
            i, j = random.choice(empty_cells)
            self.grid[i][j] = 4 if random.random() < 0.1 else 2  # 10% chance for a 4, otherwise 2.

    def move_tiles(self, direction: str) -> None:
        if direction == 'left':
            self.merge_tiles('left')
        elif direction == 'right':
            self.grid = [row[::-1] for row in self.grid]
            self.merge_tiles('left')
            self.grid = [row[::-1] for row in self.grid]
        elif direction == 'up':
            self.grid = list(map(list, zip(*self.grid)))  # Transpose the grid
            self.merge_tiles('left')
            self.grid = list(map(list, zip(*self.grid)))  # Transpose back
        elif direction == 'down':
            self.grid = list(map(list, zip(*self.grid)))  # Transpose the grid
            self.grid = [row[::-1] for row in self.grid]
            self.merge_tiles('left')
            self.grid = [row[::-1] for row in self.grid]  # Transpose back

    def merge_tiles(self, direction: str) -> None:
        for i in range(4):
            if direction == 'left':
                self.grid[i] = self._merge_row(self.grid[i])
            elif direction == 'right':
                self.grid[i] = self._merge_row(self.grid[i][::-1])[::-1]
            elif direction == 'up':
                self.grid[i] = self._merge_row([self.grid[j][i] for j in range(4)])
            elif direction == 'down':
                self.grid[i] = self._merge_row([self.grid[j][i] for j in range(4)][::-1])[::-1]

    def _merge_row(self, row: list) -> list:
        new_row = [num for num in row if num != 0]  # Remove zeroes
        merged_row = []
        skip = False
        for j in range(len(new_row)):
            if skip:
                skip = False
                continue
            if j < len(new_row) - 1 and new_row[j] == new_row[j + 1]:
                merged_row.append(new_row[j] * 2)
                skip = True
            else:
                merged_row.append(new_row[j])
        merged_row += [0] * (4 - len(merged_row))  # Fill the rest with zeroes
        return merged_row

    def is_move_possible(self) -> bool:
        for i in range(4):
            for j in range(4):
                if self.grid[i][j] == 0:
                    return True
                if j < 3 and self.grid[i][j] == self.grid[i][j + 1]:
                    return True
                if i < 3 and self.grid[i][j] == self.grid[i + 1][j]:
                    return True
        return False

    def get_grid(self) -> list:
        return self.grid


class Game:
    def __init__(self):
        self.board = Board()  # Initialize the board
        self.score = 0        # Initialize the score
        self.start_game()     # Start the game with initial tiles

    def start_game(self) -> None:
        self.board.add_random_tile()  # Generate the first tile
        self.board.add_random_tile()  # Generate the second tile

    def move(self, direction: str) -> None:
        if self.board.is_move_possible():  # Check if a move is possible before moving
            self.board.move_tiles(direction)  # Move tiles in the specified direction
            self.board.add_random_tile()      # Add a new tile after the move
            self.score = self.calculate_score()  # Update the score

    def calculate_score(self) -> int:
        return sum(sum(row) for row in self.board.get_grid())  # Calculate score based on the grid

    def save_game_state(self, filename: str) -> None:
        with open(filename, 'w') as f:
            f.write(f"{self.score}\n")
            for row in self.board.get_grid():
                f.write(' '.join(map(str, row)) + '\n')

    def load_game_state(self, filename: str) -> None:
        with open(filename, 'r') as f:
            self.score = int(f.readline().strip())
            for i in range(4):
                self.board.grid[i] = list(map(int, f.readline().strip().split()))

    def check_game_over(self) -> bool:
        return not self.board.is_move_possible()  # Returns True if no valid moves left