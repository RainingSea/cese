import random

class Tile:
    def __init__(self, value: int):
        self.value = value

    def draw(self, surface) -> None:
        # Placeholder for drawing the tile on the surface
        pass

class Game:
    def __init__(self):
        self.board = [[0] * 4 for _ in range(4)]
        self.score = 0
        self.start_game()

    def start_game(self) -> None:
        self.generate_new_tile()
        self.generate_new_tile()

    def move(self, direction: str) -> None:
        # Implement move logic based on direction
        pass

    def generate_new_tile(self) -> None:
        empty_tiles = [(i, j) for i in range(4) for j in range(4) if self.board[i][j] == 0]
        if empty_tiles:
            i, j = random.choice(empty_tiles)
            self.board[i][j] = 2 if random.random() < 0.9 else 4

    def check_game_over(self) -> bool:
        # Check if there are no valid moves left
        return not any(self.can_move())

    def can_move(self) -> list:
        # Check for possible moves
        return [self.can_merge(i, j) for i in range(4) for j in range(4)]

    def can_merge(self, i: int, j: int) -> bool:
        # Check if a tile can merge with another
        return False  # Placeholder for actual logic

    def save_game_state(self, filename: str) -> None:
        with open(filename, 'w') as f:
            f.write(f"{self.score}\n")
            for row in self.board:
                f.write(' '.join(map(str, row)) + '\n')

    def load_game_state(self, filename: str) -> None:
        with open(filename, 'r') as f:
            self.score = int(f.readline().strip())
            for i in range(4):
                self.board[i] = list(map(int, f.readline().strip().split()))

    def display(self) -> None:
        # Placeholder for displaying the game state
        pass