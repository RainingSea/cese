import unittest
from game import Game

class Test2048Game(unittest.TestCase):

    def setUp(self):
        # Initialize the game
        self.game = Game()

    def test_initialize_game_board(self):
        # Functionalities 1: Initialize Game Board
        non_empty_tiles = sum(tile != 0 for row in self.game.board for tile in row)
        self.assertEqual(non_empty_tiles, 2, "Game should start with exactly two tiles")

    def test_move_tiles_up(self):
        # Functionalities 2: Move Tiles Up
        initial_board = [row[:] for row in self.game.board]
        self.game.move('up')
        self.assertNotEqual(self.game.board, initial_board, "Board should change after moving up")

    def test_move_tiles_down(self):
        # Functionalities 3: Move Tiles Down
        initial_board = [row[:] for row in self.game.board]
        self.game.move('down')
        self.assertNotEqual(self.game.board, initial_board, "Board should change after moving down")

    def test_move_tiles_left(self):
        # Functionalities 4: Move Tiles Left
        initial_board = [row[:] for row in self.game.board]
        self.game.move('left')
        self.assertNotEqual(self.game.board, initial_board, "Board should change after moving left")

    def test_move_tiles_right(self):
        # Functionalities 5: Move Tiles Right
        initial_board = [row[:] for row in self.game.board]
        self.game.move('right')
        self.assertNotEqual(self.game.board, initial_board, "Board should change after moving right")

    def test_generate_new_tile(self):
        # Functionalities 6: Generate New Tile
        self.game.move('up')  # Make a move to trigger new tile generation
        non_empty_tiles = sum(tile != 0 for row in self.game.board for tile in row)
        self.assertEqual(non_empty_tiles, 3, "A new tile should be generated after a move")

    def test_check_game_over_condition(self):
        # Functionalities 7: Check Game Over Condition
        self.game.board = [
            [2, 4, 2, 4],
            [4, 2, 4, 2],
            [2, 4, 2, 4],
            [4, 2, 4, 2]
        ]
        self.assertTrue(self.game.check_game_over(), "Game should be over when no moves are possible")

    def test_save_game_state(self):
        # Functionalities 8: Save Game State
        self.game.save_game_state('test_game_state.txt')
        with open('test_game_state.txt', 'r') as f:
            lines = f.readlines()
        self.assertEqual(int(lines[0].strip()), self.game.score, "Score should be saved correctly")
        for i, line in enumerate(lines[1:]):
            self.assertEqual(list(map(int, line.strip().split())), self.game.board[i], "Board state should be saved correctly")

    def test_load_game_state(self):
        # Functionalities 9: Load Game State
        self.game.save_game_state('test_game_state.txt')
        new_game = Game()
        new_game.load_game_state('test_game_state.txt')
        self.assertEqual(new_game.score, self.game.score, "Score should be loaded correctly")
        self.assertEqual(new_game.board, self.game.board, "Board state should be loaded correctly")

if __name__ == '__main__':
    unittest.main()
