import random
from tile import Tile

class Game:
    def __init__(self):
        self._board = [[0] * 4 for _ in range(4)]
        self._score = 0
        self._game_over = False
        self.generate_tile()
        self.generate_tile()

    def start_game(self) -> None:
        self._board = [[0] * 4 for _ in range(4)]
        self._score = 0
        self._game_over = False
        self.generate_tile()
        self.generate_tile()

    def move(self, direction: str) -> None:
        if direction == 'up':
            self._move_up()
        elif direction == 'down':
            self._move_down()
        elif direction == 'left':
            self._move_left()
        elif direction == 'right':
            self._move_right()
        self.generate_tile()
        self.check_game_over()

    def generate_tile(self) -> None:
        empty_tiles = [(i, j) for i in range(4) for j in range(4) if self._board[i][j] == 0]
        if empty_tiles:
            i, j = random.choice(empty_tiles)
            self._board[i][j] = Tile(2 if random.random() < 0.9 else 4)

    def check_game_over(self) -> bool:
        if any(0 in row for row in self._board):
            return False
        for i in range(4):
            for j in range(4):
                if (i < 3 and self._board[i][j] == self._board[i + 1][j]) or (j < 3 and self._board[i][j] == self._board[i][j + 1]):
                    return False
        self._game_over = True
        return True

    def save_game_state(self, filename: str) -> None:
        with open(filename, 'w') as f:
            f.write(f"{self._score}\n")
            for row in self._board:
                f.write(' '.join(str(tile.get_value()) if tile != 0 else '0' for tile in row) + '\n')

    def load_game_state(self, filename: str) -> None:
        with open(filename, 'r') as f:
            self._score = int(f.readline().strip())
            for i in range(4):
                row = list(map(int, f.readline().strip().split()))
                self._board[i] = [Tile(value) if value != 0 else 0 for value in row]

    def _move_up(self) -> None:
        # Implement the logic for moving tiles up
        pass

    def _move_down(self) -> None:
        # Implement the logic for moving tiles down
        pass

    def _move_left(self) -> None:
        # Implement the logic for moving tiles left
        pass

    def _move_right(self) -> None:
        # Implement the logic for moving tiles right
        pass