class Tile:
    def __init__(self, value: int):
        self._value = value

    def get_value(self) -> int:
        return self._value