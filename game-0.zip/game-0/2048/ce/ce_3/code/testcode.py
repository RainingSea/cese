import unittest
from game import Game
from tile import Tile

class Test2048Game(unittest.TestCase):

    def setUp(self):
        # Initialize the game
        self.game = Game()

    def test_initialize_game_board(self):
        # Functionalities 1: Initialize Game Board
        self.game.start_game()
        non_empty_tiles = sum(tile != 0 for row in self.game._board for tile in row)
        self.assertEqual(non_empty_tiles, 2, "Game board should start with exactly two non-empty tiles")

    def test_move_tiles_up(self):
        # Functionalities 2: Move Tiles Up
        self.game._board = [
            [Tile(2), Tile(0), Tile(0), Tile(2)],
            [Tile(2), Tile(0), Tile(0), Tile(2)],
            [Tile(0), Tile(0), Tile(0), Tile(0)],
            [Tile(0), Tile(0), Tile(0), Tile(0)]
        ]
        self.game._move_up()
        self.assertEqual(self.game._board[0][0].get_value(), 4, "Tiles should combine when moved up")
        self.assertEqual(self.game._board[0][3].get_value(), 4, "Tiles should combine when moved up")

    def test_move_tiles_down(self):
        # Functionalities 3: Move Tiles Down
        self.game._board = [
            [Tile(2), Tile(0), Tile(0), Tile(2)],
            [Tile(2), Tile(0), Tile(0), Tile(2)],
            [Tile(0), Tile(0), Tile(0), Tile(0)],
            [Tile(0), Tile(0), Tile(0), Tile(0)]
        ]
        self.game._move_down()
        self.assertEqual(self.game._board[3][0].get_value(), 4, "Tiles should combine when moved down")
        self.assertEqual(self.game._board[3][3].get_value(), 4, "Tiles should combine when moved down")

    def test_move_tiles_left(self):
        # Functionalities 4: Move Tiles Left
        self.game._board = [
            [Tile(2), Tile(2), Tile(0), Tile(0)],
            [Tile(0), Tile(0), Tile(0), Tile(0)],
            [Tile(0), Tile(0), Tile(0), Tile(0)],
            [Tile(0), Tile(0), Tile(0), Tile(0)]
        ]
        self.game._move_left()
        self.assertEqual(self.game._board[0][0].get_value(), 4, "Tiles should combine when moved left")

    def test_move_tiles_right(self):
        # Functionalities 5: Move Tiles Right
        self.game._board = [
            [Tile(0), Tile(0), Tile(2), Tile(2)],
            [Tile(0), Tile(0), Tile(0), Tile(0)],
            [Tile(0), Tile(0), Tile(0), Tile(0)],
            [Tile(0), Tile(0), Tile(0), Tile(0)]
        ]
        self.game._move_right()
        self.assertEqual(self.game._board[0][3].get_value(), 4, "Tiles should combine when moved right")

    def test_generate_new_tile(self):
        # Functionalities 6: Generate New Tile
        self.game._board = [
            [Tile(2), Tile(2), Tile(2), Tile(2)],
            [Tile(2), Tile(2), Tile(2), Tile(2)],
            [Tile(2), Tile(2), Tile(2), Tile(2)],
            [Tile(2), Tile(2), Tile(2), 0]
        ]
        self.game.generate_tile()
        non_empty_tiles = sum(tile != 0 for row in self.game._board for tile in row)
        self.assertEqual(non_empty_tiles, 16, "A new tile should be generated in an empty space")

    def test_check_game_over_condition(self):
        # Functionalities 7: Check Game Over Condition
        self.game._board = [
            [Tile(2), Tile(4), Tile(2), Tile(4)],
            [Tile(4), Tile(2), Tile(4), Tile(2)],
            [Tile(2), Tile(4), Tile(2), Tile(4)],
            [Tile(4), Tile(2), Tile(4), Tile(2)]
        ]
        game_over = self.game.check_game_over()
        self.assertTrue(game_over, "Game should be over when no moves are left")

    def test_save_game_state(self):
        # Functionalities 8: Save Game State
        self.fail("Save game state functionality is not implemented in the codebase")

    def test_load_game_state(self):
        # Functionalities 9: Load Game State
        self.fail("Load game state functionality is not implemented in the codebase")

if __name__ == '__main__':
    unittest.main()
