import random

class Tile:
    def __init__(self, value: int):
        self._value = value

    def get_value(self) -> int:
        return self._value

class Game:
    def __init__(self):
        self._board = [[0] * 4 for _ in range(4)]
        self._score = 0
        self.generate_tile()
        self.generate_tile()

    def start_game(self) -> None:
        while True:
            self.display_board()
            direction = input("Enter direction (w/a/s/d): ")
            if direction in ['w', 'a', 's', 'd']:
                self.move(direction)
                if self.check_game_over():
                    print("Game Over!")
                    break
            else:
                print("Invalid input. Please use w/a/s/d.")

    def move(self, direction: str) -> None:
        if direction == 'w':
            self._board = self._move_up(self._board)
        elif direction == 's':
            self._board = self._move_down(self._board)
        elif direction == 'a':
            self._board = self._move_left(self._board)
        elif direction == 'd':
            self._board = self._move_right(self._board)
        self.generate_tile()

    def generate_tile(self) -> None:
        empty_tiles = [(i, j) for i in range(4) for j in range(4) if self._board[i][j] == 0]
        if empty_tiles:
            i, j = random.choice(empty_tiles)
            self._board[i][j] = random.choice([2, 4])

    def check_game_over(self) -> bool:
        if any(0 in row for row in self._board):
            return False
        for i in range(4):
            for j in range(4):
                if (i < 3 and self._board[i][j] == self._board[i + 1][j]) or (j < 3 and self._board[i][j] == self._board[i][j + 1]):
                    return False
        return True

    def save_game_state(self, file_path: str) -> None:
        with open(file_path, 'w') as f:
            f.write(f"{self._score}\n")
            for row in self._board:
                f.write(" ".join(map(str, row)) + "\n")

    def load_game_state(self, file_path: str) -> None:
        with open(file_path, 'r') as f:
            self._score = int(f.readline().strip())
            for i in range(4):
                self._board[i] = list(map(int, f.readline().strip().split()))

    def display_board(self) -> None:
        print(f"Score: {self._score}")
        for row in self._board:
            print("\t".join(str(x) if x != 0 else '.' for x in row))
        print()

    def _move_up(self, board):
        # Implement the logic for moving tiles up
        return board

    def _move_down(self, board):
        # Implement the logic for moving tiles down
        return board

    def _move_left(self, board):
        # Implement the logic for moving tiles left
        return board

    def _move_right(self, board):
        # Implement the logic for moving tiles right
        return board