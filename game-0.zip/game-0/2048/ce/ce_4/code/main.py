import pygame
from game import Game

def main():
    pygame.init()
    screen = pygame.display.set_mode((400, 400))
    pygame.display.set_caption("2048 Game")
    game = Game()
    game.start_game()
    pygame.quit()

if __name__ == "__main__":
    main()