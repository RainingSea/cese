import unittest
from game import Game
import os

class Test2048Game(unittest.TestCase):

    def setUp(self):
        # Initialize the game
        self.game = Game()

    def test_initialize_game_board(self):
        # Functionalities 1: Initialize Game Board
        non_empty_tiles = sum(tile != 0 for row in self.game._board for tile in row)
        self.assertEqual(non_empty_tiles, 2, "The game board should start with exactly two non-empty tiles.")

    def test_move_tiles_up(self):
        # Functionalities 2: Move Tiles Up
        initial_board = [[2, 0, 0, 0],
                         [2, 0, 0, 0],
                         [0, 0, 0, 0],
                         [0, 0, 0, 0]]
        self.game._board = initial_board
        self.game.move('w')
        expected_board = [[4, 0, 0, 0],
                          [0, 0, 0, 0],
                          [0, 0, 0, 0],
                          [0, 0, 0, 0]]
        self.assertEqual(self.game._board, expected_board, "Tiles should combine and move up correctly.")

    def test_move_tiles_down(self):
        # Functionalities 3: Move Tiles Down
        initial_board = [[2, 0, 0, 0],
                         [2, 0, 0, 0],
                         [0, 0, 0, 0],
                         [0, 0, 0, 0]]
        self.game._board = initial_board
        self.game.move('s')
        expected_board = [[0, 0, 0, 0],
                          [0, 0, 0, 0],
                          [0, 0, 0, 0],
                          [4, 0, 0, 0]]
        self.assertEqual(self.game._board, expected_board, "Tiles should combine and move down correctly.")

    def test_move_tiles_left(self):
        # Functionalities 4: Move Tiles Left
        initial_board = [[0, 2, 2, 0],
                         [0, 0, 0, 0],
                         [0, 0, 0, 0],
                         [0, 0, 0, 0]]
        self.game._board = initial_board
        self.game.move('a')
        expected_board = [[4, 0, 0, 0],
                          [0, 0, 0, 0],
                          [0, 0, 0, 0],
                          [0, 0, 0, 0]]
        self.assertEqual(self.game._board, expected_board, "Tiles should combine and move left correctly.")

    def test_move_tiles_right(self):
        # Functionalities 5: Move Tiles Right
        initial_board = [[0, 2, 2, 0],
                         [0, 0, 0, 0],
                         [0, 0, 0, 0],
                         [0, 0, 0, 0]]
        self.game._board = initial_board
        self.game.move('d')
        expected_board = [[0, 0, 0, 4],
                          [0, 0, 0, 0],
                          [0, 0, 0, 0],
                          [0, 0, 0, 0]]
        self.assertEqual(self.game._board, expected_board, "Tiles should combine and move right correctly.")

    def test_generate_new_tile(self):
        # Functionalities 6: Generate New Tile
        initial_empty_tiles = sum(tile == 0 for row in self.game._board for tile in row)
        self.game.generate_tile()
        new_empty_tiles = sum(tile == 0 for row in self.game._board for tile in row)
        self.assertEqual(initial_empty_tiles - 1, new_empty_tiles, "A new tile should be generated in an empty space.")

    def test_check_game_over_condition(self):
        # Functionalities 7: Check Game Over Condition
        self.game._board = [[2, 4, 2, 4],
                            [4, 2, 4, 2],
                            [2, 4, 2, 4],
                            [4, 2, 4, 2]]
        self.assertTrue(self.game.check_game_over(), "The game should be over when no moves are possible.")

    def test_save_game_state(self):
        # Functionalities 8: Save Game State
        file_path = "test_game_state.txt"
        self.game.save_game_state(file_path)
        self.assertTrue(os.path.exists(file_path), "Game state file should be created.")
        os.remove(file_path)

    def test_load_game_state(self):
        # Functionalities 9: Load Game State
        file_path = "test_game_state.txt"
        with open(file_path, 'w') as f:
            f.write("0\n2 0 0 0\n0 0 0 0\n0 0 0 0\n0 0 0 0\n")
        self.game.load_game_state(file_path)
        expected_board = [[2, 0, 0, 0],
                          [0, 0, 0, 0],
                          [0, 0, 0, 0],
                          [0, 0, 0, 0]]
        self.assertEqual(self.game._board, expected_board, "Game board should be loaded correctly from the file.")
        os.remove(file_path)

if __name__ == '__main__':
    unittest.main()
