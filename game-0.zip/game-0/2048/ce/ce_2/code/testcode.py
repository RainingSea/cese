import unittest
from game import Game

class Test2048Game(unittest.TestCase):

    def setUp(self):
        # Initialize the game
        self.game = Game()

    def test_initialize_game_board(self):
        # Functionalities 1: Initialize Game Board
        non_zero_tiles = sum(tile != 0 for row in self.game._board for tile in row)
        self.assertEqual(non_zero_tiles, 2, "The game board should start with exactly two non-zero tiles")

    def test_move_tiles_up(self):
        # Functionalities 2: Move Tiles Up
        self.game._board = [
            [2, 0, 0, 0],
            [2, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0]
        ]
        self.game.move('up')
        self.assertEqual(self.game._board[0][0], 4, "Tiles should combine when moved up")
        self.assertEqual(self.game._board[1][0], 0, "No tile should remain in the second row after move up")

    def test_move_tiles_down(self):
        # Functionalities 3: Move Tiles Down
        self.game._board = [
            [2, 0, 0, 0],
            [2, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0]
        ]
        self.game.move('down')
        self.assertEqual(self.game._board[3][0], 4, "Tiles should combine when moved down")
        self.assertEqual(self.game._board[2][0], 0, "No tile should remain in the third row after move down")

    def test_move_tiles_left(self):
        # Functionalities 4: Move Tiles Left
        self.game._board = [
            [0, 2, 2, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0]
        ]
        self.game.move('left')
        self.assertEqual(self.game._board[0][0], 4, "Tiles should combine when moved left")
        self.assertEqual(self.game._board[0][1], 0, "No tile should remain in the second column after move left")

    def test_move_tiles_right(self):
        # Functionalities 5: Move Tiles Right
        self.game._board = [
            [0, 2, 2, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0]
        ]
        self.game.move('right')
        self.assertEqual(self.game._board[0][3], 4, "Tiles should combine when moved right")
        self.assertEqual(self.game._board[0][2], 0, "No tile should remain in the third column after move right")

    def test_generate_new_tile(self):
        # Functionalities 6: Generate New Tile
        self.game._board = [
            [2, 4, 8, 16],
            [32, 64, 128, 256],
            [512, 1024, 2048, 0],
            [0, 0, 0, 0]
        ]
        self.game.generate_new_tile()
        non_zero_tiles = sum(tile != 0 for row in self.game._board for tile in row)
        self.assertEqual(non_zero_tiles, 15, "A new tile should be generated after a move")

    def test_check_game_over_condition(self):
        # Functionalities 7: Check Game Over Condition
        self.game._board = [
            [2, 4, 8, 16],
            [32, 64, 128, 256],
            [512, 1024, 2048, 4096],
            [8192, 16384, 32768, 65536]
        ]
        self.assertTrue(self.game.check_game_over(), "Game should be over when no moves are possible")

    def test_save_game_state(self):
        # Functionalities 8: Save Game State
        try:
            self.game.save_game_state("test_game_state.txt")
            with open("test_game_state.txt", 'r') as file:
                lines = file.readlines()
                self.assertEqual(len(lines), 5, "The saved game state should have 5 lines")
        except Exception as e:
            self.fail(f"Saving game state raised an exception: {e}")

    def test_load_game_state(self):
        # Functionalities 9: Load Game State
        self.game.save_game_state("test_game_state.txt")
        self.game._board = [[0] * 4 for _ in range(4)]  # Reset board
        self.game.load_game_state("test_game_state.txt")
        non_zero_tiles = sum(tile != 0 for row in self.game._board for tile in row)
        self.assertGreater(non_zero_tiles, 0, "The game board should be restored from the saved state")

if __name__ == '__main__':
    unittest.main()
