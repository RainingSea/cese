import pygame
from game import Game

def main():
    pygame.init()
    screen = pygame.display.set_mode((400, 500))
    pygame.display.set_caption("2048 Game")
    clock = pygame.time.Clock()
    game = Game()
    
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    game.move('up')
                elif event.key == pygame.K_DOWN:
                    game.move('down')
                elif event.key == pygame.K_LEFT:
                    game.move('left')
                elif event.key == pygame.K_RIGHT:
                    game.move('right')

        screen.fill((187, 173, 160))
        draw_board(screen, game)
        pygame.display.flip()
        clock.tick(60)

    pygame.quit()

def draw_board(screen, game):
    for i in range(4):
        for j in range(4):
            value = game._board[i][j]
            pygame.draw.rect(screen, (204, 192, 179), (j * 100, i * 100, 100, 100))
            if value != 0:
                font = pygame.font.Font(None, 55)
                text = font.render(str(value), True, (255, 255, 255))
                text_rect = text.get_rect(center=(j * 100 + 50, i * 100 + 50))
                screen.blit(text, text_rect)

if __name__ == "__main__":
    main()