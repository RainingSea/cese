import random

class Tile:
    def __init__(self, value: int):
        self._value = value

    def get_value(self) -> int:
        return self._value

class Game:
    def __init__(self):
        self._board = [[0] * 4 for _ in range(4)]
        self._score = 0
        self.start_game()

    def start_game(self) -> None:
        self.generate_new_tile()
        self.generate_new_tile()

    def move(self, direction: str) -> None:
        if direction == 'up':
            self._move_up()
        elif direction == 'down':
            self._move_down()
        elif direction == 'left':
            self._move_left()
        elif direction == 'right':
            self._move_right()
        self.generate_new_tile()

    def generate_new_tile(self) -> None:
        empty_tiles = [(i, j) for i in range(4) for j in range(4) if self._board[i][j] == 0]
        if empty_tiles:
            i, j = random.choice(empty_tiles)
            self._board[i][j] = 2 if random.random() < 0.9 else 4

    def check_game_over(self) -> bool:
        if any(0 in row for row in self._board):
            return False
        for i in range(4):
            for j in range(4):
                if (i < 3 and self._board[i][j] == self._board[i + 1][j]) or (j < 3 and self._board[i][j] == self._board[i][j + 1]):
                    return False
        return True

    def save_game_state(self, file_path: str) -> None:
        with open(file_path, 'w') as file:
            file.write(f"{self._score}\n")
            for row in self._board:
                file.write('|'.join(map(str, row)) + '\n')

    def load_game_state(self, file_path: str) -> None:
        with open(file_path, 'r') as file:
            self._score = int(file.readline().strip())
            for i in range(4):
                row = list(map(int, file.readline().strip().split('|')))
                self._board[i] = row