class Tile:
    def __init__(self, value: int):
        self.value = value

    def draw(self) -> None:
        # Placeholder for drawing logic, to be implemented in the game class
        pass