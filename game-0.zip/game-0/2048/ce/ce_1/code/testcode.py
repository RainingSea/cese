import unittest
from game import Game
from tile import Tile

class Test2048Game(unittest.TestCase):

    def setUp(self):
        self.game = Game()

    def test_initialize_game_board(self):
        # Functionalities 1: Initialize Game Board
        non_empty_tiles = sum(tile != 0 for row in self.game.board for tile in row)
        self.assertEqual(non_empty_tiles, 2, "There should be exactly two tiles initialized on the board.")

    def test_move_tiles_up(self):
        # Functionalities 2: Move Tiles Up
        self.game.board = [
            [Tile(2), 0, 0, 0],
            [Tile(2), 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0]
        ]
        self.game.move('up')
        self.assertEqual(self.game.board[0][0].value, 4, "Tiles should combine to form a 4 at the top.")
        self.assertEqual(self.game.board[1][0], 0, "The second row should be empty after the move.")

    def test_move_tiles_down(self):
        # Functionalities 3: Move Tiles Down
        self.game.board = [
            [Tile(2), 0, 0, 0],
            [Tile(2), 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0]
        ]
        self.game.move('down')
        self.assertEqual(self.game.board[3][0].value, 4, "Tiles should combine to form a 4 at the bottom.")
        self.assertEqual(self.game.board[2][0], 0, "The third row should be empty after the move.")

    def test_move_tiles_left(self):
        # Functionalities 4: Move Tiles Left
        self.game.board = [
            [0, Tile(2), Tile(2), 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0]
        ]
        self.game.move('left')
        self.assertEqual(self.game.board[0][0].value, 4, "Tiles should combine to form a 4 on the left.")
        self.assertEqual(self.game.board[0][1], 0, "The second column should be empty after the move.")

    def test_move_tiles_right(self):
        # Functionalities 5: Move Tiles Right
        self.game.board = [
            [0, Tile(2), Tile(2), 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0]
        ]
        self.game.move('right')
        self.assertEqual(self.game.board[0][3].value, 4, "Tiles should combine to form a 4 on the right.")
        self.assertEqual(self.game.board[0][2], 0, "The third column should be empty after the move.")

    def test_generate_new_tile(self):
        # Functionalities 6: Generate New Tile
        initial_empty_tiles = sum(tile == 0 for row in self.game.board for tile in row)
        self.game.generate_new_tile()
        new_empty_tiles = sum(tile == 0 for row in self.game.board for tile in row)
        self.assertEqual(initial_empty_tiles - 1, new_empty_tiles, "A new tile should be generated, reducing empty tiles by one.")

    def test_check_game_over_condition(self):
        # Functionalities 7: Check Game Over Condition
        self.game.board = [
            [Tile(2), Tile(4), Tile(2), Tile(4)],
            [Tile(4), Tile(2), Tile(4), Tile(2)],
            [Tile(2), Tile(4), Tile(2), Tile(4)],
            [Tile(4), Tile(2), Tile(4), Tile(2)]
        ]
        self.assertTrue(self.game.check_game_over(), "The game should be over when no moves are possible.")

    def test_save_game_state(self):
        # Functionalities 8: Save Game State
        self.game.save_game_state('test_game_state.txt')
        with open('test_game_state.txt', 'r') as file:
            lines = file.readlines()
        self.assertEqual(len(lines), 5, "The saved game state should have 5 lines (1 for score, 4 for board).")

    def test_load_game_state(self):
        # Functionalities 9: Load Game State
        self.game.save_game_state('test_game_state.txt')
        new_game = Game()
        new_game.load_game_state('test_game_state.txt')
        self.assertEqual(self.game.score, new_game.score, "Loaded game score should match the saved score.")
        for i in range(4):
            for j in range(4):
                self.assertEqual(self.game.board[i][j].value if self.game.board[i][j] != 0 else 0,
                                 new_game.board[i][j].value if new_game.board[i][j] != 0 else 0,
                                 "Loaded game board should match the saved board.")

if __name__ == '__main__':
    unittest.main()
