from game import Game

def main():
    game = Game()
    game.load_game_state()
    game.start_game()

if __name__ == "__main__":
    main()