import pygame
import json
from typing import List

class Block:
    def __init__(self, color: tuple):
        self.color = color

class Grid:
    def __init__(self, width: int, height: int):
        self.blocks = [[Block((255, 0, 0)) for _ in range(width)] for _ in range(height)]

    def display(self, screen):
        for y, row in enumerate(self.blocks):
            for x, block in enumerate(row):
                pygame.draw.rect(screen, block.color, (x * 50, y * 50, 50, 50))

    def update_blocks(self):
        # Logic to update blocks if needed
        pass

class Score:
    def __init__(self):
        self.points = 0

    def add_points(self, points: int):
        self.points += points

    def get_score(self) -> int:
        return self.points

class Move:
    def __init__(self, block: Block, action: str):
        self.block = block
        self.action = action

class Game:
    def __init__(self):
        self.grid = Grid(10, 10)
        self.score = Score()
        self.move_history: List[Move] = []

    def start_game(self):
        pygame.init()
        self.screen = pygame.display.set_mode((500, 500))
        pygame.display.set_caption("Block Connect Game")
        self.run_game_loop()

    def run_game_loop(self):
        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    x, y = event.pos
                    self.select_block(x // 50, y // 50)

            self.screen.fill((255, 255, 255))
            self.grid.display(self.screen)
            pygame.display.flip()

        pygame.quit()

    def select_block(self, x: int, y: int):
        # Logic to select a block
        pass

    def connect_blocks(self):
        # Logic to connect blocks
        pass

    def clear_blocks(self):
        # Logic to clear blocks
        pass

    def undo_move(self):
        # Logic to undo the last move
        pass

    def save_game_state(self):
        with open('game_state.json', 'w') as f:
            json.dump({'score': self.score.get_score()}, f)

    def load_game_state(self):
        try:
            with open('game_state.json', 'r') as f:
                data = json.load(f)
                self.score.points = data.get('score', 0)
        except FileNotFoundError:
            pass