[OUTPUT]
## general overview of the project
Block Connect is a puzzle game where players have to connect blocks of the same color to clear them from the board.

## software functional requirements
1. The system shall allow players to select blocks of the same color to initiate a connection.
2. The system shall display a grid with blocks of various colors.
3. The system shall enable players to connect two or more blocks of the same color, which will then disappear from the board.
4. The system shall include a scoring system that tracks and displays the number of blocks cleared by the player.
5. The system shall allow remaining blocks to fall to occupy the empty spaces after blocks are cleared, and new blocks shall appear on the board.
6. The system shall provide an option for players to undo their last move.
[/OUTPUT]