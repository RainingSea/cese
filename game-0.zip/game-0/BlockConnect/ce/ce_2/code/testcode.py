import unittest
from game import Game, Grid, Score, Block

class TestBlockConnectGame(unittest.TestCase):

    def setUp(self):
        # Initialize the game and its components
        self.game = Game()
        self.grid = self.game.grid
        self.score = self.game.score

    def test_select_and_connect_blocks(self):
        # Functionalities 1: Select and Connect Blocks of the Same Color
        # Simulate selecting blocks of the same color
        self.grid.blocks[0][0] = Block('red')
        self.grid.blocks[0][1] = Block('red')
        self.grid.blocks[0][2] = Block('red')
        self.game.select_block(0, 0)
        self.game.select_block(0, 1)
        self.game.select_block(0, 2)
        self.game.connect_blocks()
        self.game.clear_blocks()
        self.assertIsNone(self.grid.blocks[0][0], "Block should be cleared")
        self.assertIsNone(self.grid.blocks[0][1], "Block should be cleared")
        self.assertIsNone(self.grid.blocks[0][2], "Block should be cleared")

    def test_display_game_grid(self):
        # Functionalities 2: Display the Game Grid
        # Check if the grid is initialized with blocks
        self.assertIsNotNone(self.grid.blocks[0][0], "Grid should display blocks")
        self.assertIsNotNone(self.grid.blocks[7][7], "Grid should display blocks")

    def test_score_calculation_after_block_clearing(self):
        # Functionalities 3: Score Calculation After Block Clearing
        # Simulate clearing blocks and check score
        self.grid.blocks[0][0] = Block('blue')
        self.grid.blocks[0][1] = Block('blue')
        self.grid.blocks[0][2] = Block('blue')
        self.game.select_block(0, 0)
        self.game.select_block(0, 1)
        self.game.select_block(0, 2)
        self.game.connect_blocks()
        self.game.clear_blocks()
        self.score.add_points(3)
        self.assertEqual(self.score.get_score(), 3, "Score should increase by 3 points")

    def test_blocks_fall_to_occupy_spaces(self):
        # Functionalities 4: Blocks Fall to Occupy Spaces
        # Simulate clearing blocks and check if blocks fall
        self.grid.blocks[1][0] = Block('yellow')
        self.grid.blocks[0][0] = None
        self.grid.update_grid()
        self.assertIsNotNone(self.grid.blocks[0][0], "Blocks should fall to fill the gap")

    def test_undo_last_move(self):
        # Functionalities 5: Undo Last Move
        # Simulate a move and undo it
        self.grid.blocks[0][0] = Block('green')
        self.grid.blocks[0][1] = Block('green')
        self.game.select_block(0, 0)
        self.game.select_block(0, 1)
        self.game.connect_blocks()
        self.game.clear_blocks()
        self.game.undo_move()
        self.assertIsNotNone(self.grid.blocks[0][0], "Blocks should return to initial positions")
        self.assertIsNotNone(self.grid.blocks[0][1], "Blocks should return to initial positions")

    def test_save_game_state(self):
        # Functionalities 6: Save Game State to a Local File
        # Simulate saving game state
        try:
            self.game.save_game_state()
        except Exception as e:
            self.fail(f"Save game state raised an exception: {e}")

    def test_load_game_state(self):
        # Functionalities 7: Load Game State from a Local File
        # Simulate loading game state
        try:
            self.game.load_game_state()
        except Exception as e:
            self.fail(f"Load game state raised an exception: {e}")

if __name__ == '__main__':
    unittest.main()
