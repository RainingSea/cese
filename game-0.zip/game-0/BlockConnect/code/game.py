import json
from typing import List
import random

class Block:
    def __init__(self, color: str) -> None:
        self.color = color
        self.selected = False

    def select(self) -> None:
        self.selected = True

    def deselect(self) -> None:
        self.selected = False

class Grid:
    def __init__(self, width: int, height: int) -> None:
        self.width = width
        self.height = height
        self.blocks = [[Block("white") for _ in range(width)] for _ in range(height)]

    def initialize_grid(self) -> None:
        for row in self.blocks:
            for block in row:
                block.color = self.random_color()

    def get_block(self, x: int, y: int) -> Block:
        return self.blocks[y][x]

    def update_grid(self) -> None:
        self.fall_blocks()

    def random_color(self) -> str:
        colors = ["red", "green", "blue", "yellow", "purple", "orange"]
        return random.choice(colors)

    def fall_blocks(self) -> None:
        for x in range(self.width):
            empty_spaces = 0
            for y in range(self.height - 1, -1, -1):
                if self.get_block(x, y).color == "white":
                    empty_spaces += 1
                elif empty_spaces > 0:
                    self.blocks[y + empty_spaces][x] = self.blocks[y][x]
                    self.blocks[y][x] = Block("white")

class Score:
    def __init__(self) -> None:
        self.points = 0

    def add_points(self, points: int) -> None:
        self.points += points

    def get_score(self) -> int:
        return self.points

class Move:
    def __init__(self, action: str, affected_blocks: List[Block]) -> None:
        self.action = action
        self.affected_blocks = affected_blocks

class Game:
    def __init__(self) -> None:
        self.grid = Grid(10, 10)
        self.score = Score()
        self.move_history: List[Move] = []

    def start_game(self) -> None:
        self.grid.initialize_grid()

    def select_block(self, x: int, y: int) -> None:
        block = self.grid.get_block(x, y)
        if not block.selected:
            block.select()
            self.move_history.append(Move("select", [block]))

    def clear_blocks(self) -> None:
        cleared_blocks = [block for row in self.grid.blocks for block in row if block.selected]
        points = len(cleared_blocks) * 10  # Example scoring logic
        self.score.add_points(points)
        for block in cleared_blocks:
            block.deselect()
        self.move_history.append(Move("clear", cleared_blocks))
        self.grid.update_grid()  # Update grid after clearing blocks

    def undo_move(self) -> None:
        if self.move_history:
            last_move = self.move_history.pop()
            if last_move.action == "select":
                for block in last_move.affected_blocks:
                    block.deselect()
            elif last_move.action == "clear":
                for block in last_move.affected_blocks:
                    block.select()
                self.score.add_points(-len(last_move.affected_blocks) * 10)

    def save_game_state(self) -> None:
        game_state = {
            'score': self.score.get_score(),
            'grid': [[block.color for block in row] for row in self.grid.blocks]
        }
        with open('game_state.json', 'w') as f:
            json.dump(game_state, f)

    def load_game_state(self) -> None:
        try:
            with open('game_state.json', 'r') as f:
                data = json.load(f)
                self.score.points = data.get('score', 0)
                for y, row in enumerate(data.get('grid', [])):
                    for x, color in enumerate(row):
                        self.grid.blocks[y][x].color = color
                        self.grid.blocks[y][x].selected = False  # Ensure deselected on load
        except FileNotFoundError:
            pass