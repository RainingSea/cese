import pygame
from game import Game

def main():
    pygame.init()
    screen = pygame.display.set_mode((800, 600))
    pygame.display.set_caption("Block Connect Puzzle Game")
    
    game = Game()
    game.load_game_state()  # Load game state at the start
    game.start_game()
    
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                x, y = pygame.mouse.get_pos()
                grid_x = x // 60
                grid_y = y // 60
                if 0 <= grid_x < game.grid.width and 0 <= grid_y < game.grid.height:
                    game.select_block(grid_x, grid_y)
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:  # Clear blocks on space key
                    game.clear_blocks()
                elif event.key == pygame.K_u:  # Undo last move on 'u' key
                    game.undo_move()
        
        screen.fill((255, 255, 255))  # Clear screen with white
        # Draw game grid and blocks here
        for y in range(game.grid.height):
            for x in range(game.grid.width):
                block = game.grid.get_block(x, y)
                color = block.color if not block.selected else (255, 0, 0)  # Highlight selected blocks
                pygame.draw.rect(screen, color, (x * 60, y * 60, 60, 60))
        
        pygame.display.flip()
    
    game.save_game_state()  # Save game state on exit
    pygame.quit()

if __name__ == "__main__":
    main()