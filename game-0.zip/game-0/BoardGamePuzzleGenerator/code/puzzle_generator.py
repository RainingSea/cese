import json
import random

class PuzzleGenerator:
    def __init__(self) -> None:
        self.puzzles = {
            "logic": [],
            "pattern_recognition": [],
            "spatial": []
        }
        self.load_puzzles()

    def load_puzzles(self) -> None:
        self.puzzles["logic"] = self.load_puzzles_from_file("logic_puzzles.json")
        self.puzzles["pattern_recognition"] = self.load_puzzles_from_file("pattern_recognition.json")
        self.puzzles["spatial"] = self.load_puzzles_from_file("spatial_puzzles.json")

    def load_puzzles_from_file(self, file_path: str) -> list:
        try:
            with open(file_path, 'r') as file:
                return json.load(file)
        except FileNotFoundError:
            raise Exception(f"File not found: {file_path}")

    def generate_puzzle(self, category: str) -> str:
        if category in self.puzzles and self.puzzles[category]:
            return random.choice(self.puzzles[category])
        else:
            return random.choice(self.puzzles["logic"])  # Default category