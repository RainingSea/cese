import pygame
from game import Game

def main() -> None:
    pygame.init()
    try:
        game = Game()
        game.start_game("default")
    finally:
        pygame.quit()

if __name__ == "__main__":
    main()