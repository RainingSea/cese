import pygame
from puzzle_generator import PuzzleGenerator
from timer import Timer
from score import Score

class Game:
    def __init__(self) -> None:
        self.puzzle_generator = PuzzleGenerator()
        self.timer = Timer()
        self.score = Score()
        self.current_puzzle = ""
        self.is_game_running = False

    def start_game(self, category: str) -> None:
        self.is_game_running = True
        self.timer.start()
        self.current_puzzle = self.puzzle_generator.generate_puzzle(category)
        self.display_game_screen()

    def submit_solution(self, solution: str) -> bool:
        if not self.validate_solution_format(solution):
            print("Invalid solution format!")
            return False

        is_correct = self.check_solution(solution)
        self.display_feedback(is_correct)
        time_taken = self.timer.stop()
        self.score.calculate_score(time_taken, is_correct)
        return is_correct

    def validate_solution_format(self, solution: str) -> bool:
        return isinstance(solution, str) and len(solution) > 0

    def display_feedback(self, is_correct: bool) -> None:
        if is_correct:
            print("Correct!")
        else:
            print("Try Again!")

    def check_solution(self, solution: str) -> bool:
        return solution == self.current_puzzle

    def display_game_screen(self) -> None:
        print(f"Puzzle: {self.current_puzzle}")
        print(f"Current Score: {self.score.get_score()}")