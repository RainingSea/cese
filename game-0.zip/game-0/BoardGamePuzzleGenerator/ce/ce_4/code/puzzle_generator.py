import random

class PuzzleGenerator:
    def __init__(self):
        self.puzzles = []

    def load_puzzles(self, file_name: str) -> None:
        with open(file_name, 'r') as file:
            self.puzzles = [line.strip() for line in file.readlines()]

    def get_random_puzzle(self) -> str:
        return random.choice(self.puzzles) if self.puzzles else ""