class Score:
    def __init__(self):
        self.score = 0

    def calculate_score(self, time_taken: float, is_correct: bool) -> int:
        if is_correct:
            return max(0, 100 - int(time_taken))  # Simple scoring logic
        return 0

    def save_score(self, player_name: str, score: int) -> None:
        with open('scores.txt', 'a') as file:
            file.write(f"{player_name}|{score}\n")