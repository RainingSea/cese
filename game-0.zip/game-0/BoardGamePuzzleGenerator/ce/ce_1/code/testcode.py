import unittest
from unittest.mock import patch, MagicMock
from game import Game
from puzzle_generator import PuzzleGenerator
from timer import Timer
from score import Score

class TestBoardGamePuzzleGenerator(unittest.TestCase):

    def setUp(self):
        self.game = Game()
        self.puzzle_generator = self.game.puzzle_generator
        self.timer = self.game.timer
        self.score = self.game.score

    def test_select_puzzle_category(self):
        # Functionalities 1: Select Puzzle Category
        category = "logic puzzles"
        self.puzzle_generator.load_puzzles = MagicMock()
        self.puzzle_generator.generate_puzzle = MagicMock(return_value="Sample Puzzle")
        self.game.start_game(category)
        self.puzzle_generator.load_puzzles.assert_called_once()
        self.puzzle_generator.generate_puzzle.assert_called_with(category)

    def test_generate_new_puzzle(self):
        # Functionalities 2: Generate a New Puzzle
        category = "math"
        self.puzzle_generator.load_puzzles()
        puzzle = self.puzzle_generator.generate_puzzle(category)
        self.assertIn(puzzle, ["5+3=8", "10-2=8"], "Generated puzzle should be from the selected category")

    def test_start_timer(self):
        # Functionalities 3: Start the Timer
        self.timer.start = MagicMock()
        self.game.start_game("math")
        self.timer.start.assert_called_once()

    def test_calculate_player_score(self):
        # Functionalities 4: Calculate Player’s Score
        self.timer.get_elapsed_time = MagicMock(return_value=240)  # 4 minutes
        score = self.score.calculate_score(240, True)
        self.assertEqual(score, 60, "Score should be calculated based on time and correctness")

    def test_submit_solution(self):
        # Functionalities 5: Submit Solution
        self.game.current_puzzle = "5+3=8"
        is_correct = self.game.submit_solution("5+3=8")
        self.assertTrue(is_correct, "Solution should be correct")

    def test_view_puzzle_feedback(self):
        # Functionalities 6: View Puzzle Feedback
        with patch('builtins.print') as mocked_print:
            self.game.display_feedback(True)
            mocked_print.assert_called_with("Correct! Your score:", 100)

    def test_timer_stops_on_solution_submission(self):
        # Functionalities 7: Timer Stops on Solution Submission
        self.timer.get_elapsed_time = MagicMock(return_value=300)
        self.game.current_puzzle = "5+3=8"
        self.game.submit_solution("5+3=8")
        time_taken = self.timer.get_elapsed_time()
        self.assertEqual(time_taken, 300, "Timer should stop and record the time taken")

    def test_load_puzzle_data_from_file(self):
        # Functionalities 8: Load Puzzle Data from File
        self.puzzle_generator.load_puzzles()
        self.assertIn("math", self.puzzle_generator.puzzles, "Puzzle data should be loaded from file")

    def test_validate_puzzle_solution_format(self):
        # Functionalities 9: Validate Puzzle Solution Format
        self.game.current_puzzle = "5+3=8"
        is_correct = self.game.submit_solution("incorrect_format")
        self.assertFalse(is_correct, "Solution format should be validated")

if __name__ == '__main__':
    unittest.main()
