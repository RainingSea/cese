import random

class PuzzleGenerator:
    def __init__(self):
        self.puzzles = {
            "math": ["2 + 2", "3 * 3", "5 - 1"],
            "words": ["cat", "dog", "fish"],
            "logic": ["If A is true, then B is false.", "All swans are white."]
        }

    def generate_puzzle(self, category: str) -> str:
        if category in self.puzzles:
            return random.choice(self.puzzles[category])
        return "No puzzles available for this category."