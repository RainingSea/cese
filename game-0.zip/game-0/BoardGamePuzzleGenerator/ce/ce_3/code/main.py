from game import Game

def main() -> None:
    game = Game()
    category = "math"  # Example category
    game.start_game(category)
    solution = input("Enter your solution: ")
    if game.submit_solution(solution):
        print("Correct!")
    else:
        print("Incorrect!")
    print(f"Your score: {game.score.get_score()}")

if __name__ == "__main__":
    main()