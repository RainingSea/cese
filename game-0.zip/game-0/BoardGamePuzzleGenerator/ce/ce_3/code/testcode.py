import unittest
from game import Game
from puzzle_generator import PuzzleGenerator
from timer import Timer
from score import Score

class TestBoardGamePuzzleGenerator(unittest.TestCase):

    def setUp(self):
        self.game = Game()
        self.puzzle_generator = self.game.puzzle_generator
        self.timer = self.game.timer
        self.score = self.game.score

    def test_select_puzzle_category(self):
        # Functionalities 1: Select Puzzle Category
        category = "logic"
        puzzle = self.puzzle_generator.generate_puzzle(category)
        self.assertIn(puzzle, self.puzzle_generator.puzzles[category], 
                      "The puzzle should be from the 'logic' category")

    def test_generate_new_puzzle(self):
        # Functionalities 2: Generate a New Puzzle
        category = "math"
        puzzle = self.puzzle_generator.generate_puzzle(category)
        self.assertIn(puzzle, self.puzzle_generator.puzzles[category], 
                      "A unique puzzle should be generated from the selected category")

    def test_start_timer(self):
        # Functionalities 3: Start the Timer
        self.timer.start()
        elapsed_time = self.timer.get_elapsed_time()
        self.assertGreaterEqual(elapsed_time, 0, 
                                "Timer should start and show elapsed time since the puzzle was generated")

    def test_calculate_player_score(self):
        # Functionalities 4: Calculate Player’s Score
        self.timer.start()
        # Simulate solving the puzzle in under 5 minutes
        self.timer.start_time -= 60 * 4  # 4 minutes ago
        self.score.calculate_score(self.timer.get_elapsed_time(), True)
        self.assertGreater(self.score.get_score(), 0, 
                           "Score should be calculated based on time and accuracy")

    def test_submit_solution(self):
        # Functionalities 5: Submit Solution
        correct = self.game.submit_solution("4")
        self.assertTrue(correct, "The solution should be correct")
        incorrect = self.game.submit_solution("5")
        self.assertFalse(incorrect, "The solution should be incorrect")

    def test_view_puzzle_feedback(self):
        # Functionalities 6: View Puzzle Feedback
        correct_feedback = self.game.submit_solution("4")
        self.assertTrue(correct_feedback, "Feedback should indicate the solution is correct")
        incorrect_feedback = self.game.submit_solution("5")
        self.assertFalse(incorrect_feedback, "Feedback should indicate the solution is incorrect")

    def test_timer_stops_on_solution_submission(self):
        # Functionalities 7: Timer Stops on Solution Submission
        self.timer.start()
        self.game.submit_solution("4")
        elapsed_time = self.timer.get_elapsed_time()
        self.assertGreaterEqual(elapsed_time, 0, 
                                "Timer should stop and record the final time taken to solve the puzzle")

    def test_load_puzzle_data_from_file(self):
        # Functionalities 8: Load Puzzle Data from File
        try:
            with open('puzzles.txt', 'r') as file:
                data = file.read()
            self.assertTrue(data, "Puzzle data should be loaded from the file")
        except FileNotFoundError:
            self.fail("Puzzle file not found")

    def test_validate_puzzle_solution_format(self):
        # Functionalities 9: Validate Puzzle Solution Format
        invalid_format = self.game.submit_solution("four")
        self.assertFalse(invalid_format, 
                         "The application should flag the submission as invalid for incorrect format")

if __name__ == '__main__':
    unittest.main()
