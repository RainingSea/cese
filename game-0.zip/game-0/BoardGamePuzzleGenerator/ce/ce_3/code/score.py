class Score:
    def __init__(self):
        self.points = 0

    def calculate_score(self, time: float, accuracy: bool) -> int:
        if accuracy:
            self.points = max(0, 100 - int(time * 10))  # Example scoring logic
        else:
            self.points = 0
        return self.points

    def get_score(self) -> int:
        return self.points