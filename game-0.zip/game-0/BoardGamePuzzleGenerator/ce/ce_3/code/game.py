from timer import Timer
from score import Score
from puzzle_generator import PuzzleGenerator

class Game:
    def __init__(self):
        self.puzzle_generator = PuzzleGenerator()
        self.timer = Timer()
        self.score = Score()

    def start_game(self, category: str) -> None:
        self.timer.start()
        puzzle = self.puzzle_generator.generate_puzzle(category)
        print(f"Puzzle: {puzzle}")

    def submit_solution(self, solution: str) -> bool:
        # Placeholder for actual solution checking logic
        correct_solution = "4"  # Example for math puzzle "2 + 2"
        is_correct = solution == correct_solution
        self.update_score(is_correct)
        return is_correct

    def update_score(self) -> None:
        elapsed_time = self.timer.get_elapsed_time()
        accuracy = True  # This would be determined by the solution check
        self.score.calculate_score(elapsed_time, accuracy)