import json
import random

class PuzzleGenerator:
    def __init__(self):
        self.puzzles = {}

    def load_puzzles(self) -> None:
        with open('puzzles/logic_puzzles.txt', 'r') as file:
            self.puzzles['Logic'] = file.readlines()
        with open('puzzles/pattern_recognition_puzzles.txt', 'r') as file:
            self.puzzles['Pattern Recognition'] = file.readlines()
        with open('puzzles/spatial_puzzles.txt', 'r') as file:
            self.puzzles['Spatial'] = file.readlines()

    def generate_puzzle(self, category: str) -> str:
        return random.choice(self.puzzles[category]).strip()