import unittest
from game import Game
from puzzle_generator import PuzzleGenerator
from timer import Timer
from score import Score

class TestBoardGamePuzzleGenerator(unittest.TestCase):

    def setUp(self):
        # Initialize the game and its components
        self.game = Game()
        self.puzzle_generator = self.game.puzzle_generator
        self.timer = self.game.timer
        self.score = self.game.score

    def test_select_puzzle_category(self):
        # Functionalities 1: Select Puzzle Category
        self.puzzle_generator.load_puzzles()
        self.assertIn('Logic', self.puzzle_generator.puzzles, "Logic category should be loaded")

    def test_generate_new_puzzle(self):
        # Functionalities 2: Generate a New Puzzle
        self.puzzle_generator.load_puzzles()
        puzzle = self.puzzle_generator.generate_puzzle('Logic')
        self.assertIn(puzzle, [line.strip() for line in open('puzzles/logic_puzzles.txt').readlines()],
                      "Generated puzzle should be from the logic puzzles category")

    def test_start_timer(self):
        # Functionalities 3: Start the Timer
        self.timer.start()
        self.assertGreater(self.timer.get_elapsed_time(), 0, "Timer should start counting up")

    def test_calculate_player_score(self):
        # Functionalities 4: Calculate Player’s Score
        self.timer.start()
        self.timer.start_time -= 60  # Simulate 1 minute has passed
        self.score.calculate_score(self.timer.get_elapsed_time(), True)
        self.assertEqual(self.score.get_score(), 40, "Score should be calculated based on time and correctness")

    def test_submit_solution(self):
        # Functionalities 5: Submit Solution
        self.puzzle_generator.load_puzzles()
        self.game.current_puzzle = self.puzzle_generator.generate_puzzle('Logic')
        correct_solution = self.game.current_puzzle.split('|')[1]
        self.assertTrue(self.game.submit_solution(correct_solution), "Solution should be correct")

    def test_view_puzzle_feedback(self):
        # Functionalities 6: View Puzzle Feedback
        self.puzzle_generator.load_puzzles()
        self.game.current_puzzle = self.puzzle_generator.generate_puzzle('Logic')
        correct_solution = self.game.current_puzzle.split('|')[1]
        self.game.submit_solution(correct_solution)
        self.assertEqual(self.game.get_feedback(), "Correct!", "Feedback should indicate correctness")

    def test_timer_stops_on_solution_submission(self):
        # Functionalities 7: Timer Stops on Solution Submission
        self.timer.start()
        self.timer.start_time -= 30  # Simulate 30 seconds have passed
        self.game.submit_solution("dummy_solution")
        elapsed_time = self.timer.get_elapsed_time()
        self.assertAlmostEqual(elapsed_time, 30, delta=1, msg="Timer should stop on solution submission")

    def test_load_puzzle_data_from_file(self):
        # Functionalities 8: Load Puzzle Data from File
        try:
            self.puzzle_generator.load_puzzles()
            loaded = True
        except FileNotFoundError:
            loaded = False
        self.assertTrue(loaded, "Puzzle data should be loaded from file")

    def test_validate_puzzle_solution_format(self):
        # Functionalities 9: Validate Puzzle Solution Format
        self.puzzle_generator.load_puzzles()
        self.game.current_puzzle = self.puzzle_generator.generate_puzzle('Logic')
        incorrect_solution = "incorrect_format"
        self.assertFalse(self.game.submit_solution(incorrect_solution), "Solution format should be validated")

if __name__ == '__main__':
    unittest.main()
