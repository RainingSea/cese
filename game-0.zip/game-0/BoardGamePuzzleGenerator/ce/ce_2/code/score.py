class Score:
    def __init__(self):
        self.points = 0

    def calculate_score(self, time_taken: float, is_correct: bool) -> int:
        if is_correct:
            self.points += max(0, 100 - int(time_taken))  # Simple scoring logic
        return self.points

    def get_score(self) -> int:
        return self.points