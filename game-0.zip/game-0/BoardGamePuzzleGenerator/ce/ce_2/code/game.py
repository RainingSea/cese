import pygame
from puzzle_generator import PuzzleGenerator
from timer import Timer
from score import Score

class Game:
    def __init__(self):
        self.puzzle_generator = PuzzleGenerator()
        self.timer = Timer()
        self.score = Score()
        self.current_puzzle = ""
        self.is_correct = False

    def start_game(self, category: str) -> None:
        self.puzzle_generator.load_puzzles()
        self.current_puzzle = self.puzzle_generator.generate_puzzle(category)
        self.timer.start()
        self.run_game_loop()

    def submit_solution(self, solution: str) -> bool:
        self.is_correct = (solution == self.current_puzzle)
        time_taken = self.timer.get_elapsed_time()
        self.score.calculate_score(time_taken, self.is_correct)
        return self.is_correct

    def get_feedback(self) -> str:
        return "Correct!" if self.is_correct else "Try again!"
    
    def run_game_loop(self):
        # Placeholder for game loop logic
        pass