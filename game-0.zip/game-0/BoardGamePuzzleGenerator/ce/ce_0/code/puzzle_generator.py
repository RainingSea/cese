import random

class PuzzleGenerator:
    def __init__(self):
        self.puzzles = {
            "default": ["puzzle1", "puzzle2", "puzzle3"],
            "math": ["2+2", "3*3", "5-1"],
            "words": ["apple", "banana", "cherry"]
        }

    def generate_puzzle(self, category: str) -> str:
        return random.choice(self.puzzles.get(category, self.puzzles["default"]))