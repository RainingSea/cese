class Score:
    def __init__(self):
        self.points = 0

    def calculate_score(self, time: float, accuracy: bool) -> int:
        if accuracy:
            self.points += max(100 - int(time), 0)  # Simple scoring logic
        return self.points

    def get_score(self) -> int:
        return self.points