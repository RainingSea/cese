import unittest
from game import Game
from puzzle_generator import PuzzleGenerator
from timer import Timer
from score import Score

class TestBoardGamePuzzleGenerator(unittest.TestCase):

    def setUp(self):
        self.game = Game()
        self.puzzle_generator = self.game.puzzle_generator
        self.timer = self.game.timer
        self.score = self.game.score

    def test_select_puzzle_category(self):
        # Functionalities 1: Select Puzzle Category
        category = "logic puzzles"
        # Since "logic puzzles" is not implemented, this should fail
        puzzle = self.puzzle_generator.generate_puzzle(category)
        self.assertNotIn(category, self.puzzle_generator.puzzles, 
                         "Category 'logic puzzles' should not be available")

    def test_generate_new_puzzle(self):
        # Functionalities 2: Generate a New Puzzle
        category = "default"
        puzzle = self.puzzle_generator.generate_puzzle(category)
        self.assertIn(puzzle, self.puzzle_generator.puzzles[category], 
                      "Generated puzzle should be from the selected category")

    def test_start_timer(self):
        # Functionalities 3: Start the Timer
        self.timer.start()
        elapsed_time = self.timer.get_elapsed_time()
        self.assertGreaterEqual(elapsed_time, 0, 
                                "Timer should start and elapsed time should be non-negative")

    def test_calculate_player_score(self):
        # Functionalities 4: Calculate Player’s Score
        self.timer.start()
        # Simulate solving the puzzle in under 5 minutes
        self.timer.start_time -= 240  # 4 minutes ago
        self.game.update_score()
        score = self.score.get_score()
        self.assertGreater(score, 0, 
                           "Score should be greater than 0 for solving the puzzle in under 5 minutes")

    def test_submit_solution(self):
        # Functionalities 5: Submit Solution
        self.game.current_puzzle = "puzzle1"
        result = self.game.submit_solution("puzzle1")
        self.assertTrue(result, "Solution should be correct and return True")

    def test_view_puzzle_feedback(self):
        # Functionalities 6: View Puzzle Feedback
        self.game.current_puzzle = "puzzle1"
        result = self.game.submit_solution("wrong_solution")
        self.assertFalse(result, "Solution should be incorrect and return False")

    def test_timer_stops_on_solution_submission(self):
        # Functionalities 7: Timer Stops on Solution Submission
        self.timer.start()
        self.game.submit_solution("puzzle1")
        elapsed_time = self.timer.get_elapsed_time()
        self.assertGreaterEqual(elapsed_time, 0, 
                                "Timer should stop and elapsed time should be recorded")

    def test_load_puzzle_data_from_file(self):
        # Functionalities 8: Load Puzzle Data from File
        try:
            puzzles = self.puzzle_generator.puzzles
            self.assertIsInstance(puzzles, dict, 
                                  "Puzzles should be loaded into a dictionary from the file")
        except FileNotFoundError:
            self.fail("Puzzle data file not found")

    def test_validate_puzzle_solution_format(self):
        # Functionalities 9: Validate Puzzle Solution Format
        self.game.current_puzzle = "2+2"
        result = self.game.submit_solution("four")
        self.assertFalse(result, 
                         "Solution format is incorrect and should be flagged as invalid")

if __name__ == '__main__':
    unittest.main()
