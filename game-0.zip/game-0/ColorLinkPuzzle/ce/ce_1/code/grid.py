import pygame
from block import Block

class Grid:
    def __init__(self, width: int, height: int, block_size: int):
        self._width = width
        self._height = height
        self._block_size = block_size
        self._blocks = []

    def initialize_grid(self) -> None:
        colors = ['red', 'green', 'blue', 'yellow']
        for x in range(self._width):
            row = []
            for y in range(self._height):
                color = colors[(x + y) % len(colors)]
                row.append(Block(color, (x, y)))
            self._blocks.append(row)

    def draw_grid(self, screen: pygame.Surface) -> None:
        for row in self._blocks:
            for block in row:
                pygame.draw.rect(screen, block._color, (block._position[0] * self._block_size, block._position[1] * self._block_size, self._block_size, self._block_size))

    def get_adjacent_blocks(self, position: tuple) -> list:
        x, y = position
        adjacent = []
        for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
            if 0 <= x + dx < self._width and 0 <= y + dy < self._height:
                adjacent.append(self._blocks[x + dx][y + dy])
        return adjacent