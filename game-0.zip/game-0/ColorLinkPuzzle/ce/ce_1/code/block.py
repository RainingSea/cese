class Block:
    def __init__(self, color: str, position: tuple):
        self._color = color
        self._position = position

    def is_connected(self, other: 'Block') -> bool:
        return self._color == other._color