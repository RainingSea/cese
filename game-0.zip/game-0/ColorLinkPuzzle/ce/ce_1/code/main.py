import pygame
from game import Game

def main() -> None:
    pygame.init()
    screen = pygame.display.set_mode((800, 600))
    game = Game(10, 10, 50)
    game.start_game()
    pygame.quit()

if __name__ == "__main__":
    main()