class Score:
    def __init__(self):
        self._current_score = 0

    def update_score(self, points: int) -> None:
        self._current_score += points

    def get_score(self) -> int:
        return self._current_score