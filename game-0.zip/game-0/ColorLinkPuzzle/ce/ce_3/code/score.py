class Score:
    def __init__(self):
        self.points = 0

    def add_points(self, value: int) -> None:
        self.points += value

    def get_score(self) -> int:
        return self.points