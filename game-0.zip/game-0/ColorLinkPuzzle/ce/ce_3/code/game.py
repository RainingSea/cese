import pygame
from grid import Grid
from score import Score

class Game:
    def __init__(self):
        self.grid = Grid()
        self.score = Score()

    def start_game(self) -> None:
        self.grid.initialize_grid(5)  # Example size
        # Placeholder for starting game logic

    def draw(self) -> None:
        self.grid.draw_grid()
        # Placeholder for drawing score

    def handle_input(self, event) -> None:
        # Placeholder for handling input
        pass

    def clear_blocks(self) -> None:
        # Placeholder for clearing blocks logic
        pass

    def save_high_score(self, player_name: str) -> None:
        with open('high_scores.txt', 'a') as f:
            f.write(f"{player_name}|{self.score.get_score()}\n")