class Block:
    def __init__(self, color: str, position: tuple[int, int]):
        self.color = color
        self.position = position

    def draw(self):
        # Placeholder for drawing logic
        pass