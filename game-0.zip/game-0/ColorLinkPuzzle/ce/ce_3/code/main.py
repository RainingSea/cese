import pygame
from game import Game

def main() -> None:
    pygame.init()
    game = Game()
    game.start_game()

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            game.handle_input(event)

        game.draw()
        pygame.display.flip()

    pygame.quit()

if __name__ == "__main__":
    main()