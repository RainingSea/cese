import pygame

class Block:
    def __init__(self, color, position):
        self.color = color
        self.position = position

    def draw(self):
        # Draw the block on the screen
        x, y = self.position
        pygame.draw.rect(pygame.display.get_surface(), self.color, (x * 50, y * 50, 50, 50))