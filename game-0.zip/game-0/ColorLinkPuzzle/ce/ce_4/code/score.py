class Score:
    def __init__(self):
        self.points = 0

    def add_points(self, value):
        self.points += value

    def get_score(self):
        return self.points