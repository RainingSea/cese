class Level:
    def __init__(self):
        self.current_level = 1

    def increase_level(self):
        self.current_level += 1

    def get_level(self):
        return self.current_level