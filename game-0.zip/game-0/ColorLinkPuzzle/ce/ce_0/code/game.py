import pygame
from grid import Grid
from score import Score
from level import Level

class Game:
    def __init__(self):
        self.grid = Grid()
        self.score = Score()
        self.level = Level()
        self.running = True

    def start_game(self):
        while self.running:
            self.handle_events()
            self.update()
            self.draw()

    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False

    def update(self):
        # Update game logic here
        pass

    def draw(self):
        self.grid.draw()
        # Draw score and level here
        pygame.display.flip()

    def clear_blocks(self, blocks):
        cleared = self.grid.clear_connected_blocks()
        self.update_score(len(cleared) * 10)

    def update_score(self, points):
        self.score.add_points(points)

    def load_game_data(self):
        # Load game data from file
        pass

    def save_game_data(self):
        # Save game data to file
        pass