class Score:
    def __init__(self):
        self.points = 0

    def update_score(self, points: int):
        self.points += points

    def get_score(self) -> int:
        return self.points

    def reset_score(self):
        self.points = 0