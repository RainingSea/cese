import pygame
from game import Game

def main():
    pygame.init()
    screen = pygame.display.set_mode((600, 600))
    pygame.display.set_caption("Color Link Puzzle")
    
    game = Game()
    game.start_game()

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        screen.fill((255, 255, 255))
        for block in game.grid.blocks:
            block.draw(screen)

        game.increase_difficulty()  # Increase difficulty each frame for demo purposes

        pygame.display.flip()

    pygame.quit()

if __name__ == "__main__":
    main()