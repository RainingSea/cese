from block import Block
import random
from collections import deque

class Grid:
    def __init__(self):
        self.blocks = []

    def initialize_grid(self):
        colors = ['red', 'green', 'blue', 'yellow']
        for x in range(0, 600, 50):
            for y in range(0, 600, 50):
                color = colors[(x // 50 + y // 50) % len(colors)]
                self.blocks.append(Block(color, (x, y)))

    def connect_blocks(self, start: tuple, end: tuple) -> bool:
        start_block = next((block for block in self.blocks if block.position == start), None)
        end_block = next((block for block in self.blocks if block.position == end), None)
        if start_block and end_block and start_block.is_adjacent(end_block):
            return start_block.is_connected(end_block)
        return False

    def clear_blocks(self):
        cleared_blocks = [block for block in self.blocks if block.color == 'cleared']
        self.blocks = [block for block in self.blocks if block.color != 'cleared']
        return cleared_blocks

    def is_path_clear(self, start: tuple, end: tuple) -> bool:
        start_block = next((block for block in self.blocks if block.position == start), None)
        end_block = next((block for block in self.blocks if block.position == end), None)

        if not start_block or not end_block:
            return False

        queue = deque([start_block])
        visited = {start_block.position}
        
        while queue:
            current = queue.popleft()
            if current.position == end_block.position:
                return True
            
            for block in self.blocks:
                if current.is_adjacent(block) and block.position not in visited:
                    visited.add(block.position)
                    queue.append(block)
        
        return False

    def increase_difficulty(self):
        for block in self.blocks:
            if random.random() < 0.1:  # 10% chance to change color to 'cleared'
                block.color = 'cleared'