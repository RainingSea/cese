import pygame
from grid import Grid
from score import Score
from level import Level

class Game:
    def __init__(self):
        self.grid = Grid()
        self.score = Score()
        self.level = Level()

    def start_game(self):
        self.grid.initialize_grid()

    def load_game(self):
        with open('game_state.txt', 'r') as file:
            data = file.readlines()
            for line in data:
                key, value = line.strip().split('|')
                if key == 'level':
                    self.level.current_level = int(value)
                elif key == 'score':
                    self.score.points = int(value)
                elif key == 'blocks':
                    # Logic to load blocks can be added here
                    pass

    def save_game(self):
        with open('game_state.txt', 'w') as file:
            file.write(f"level|{self.level.get_level()}\n")
            file.write(f"score|{self.score.get_score()}\n")
            # Logic to save blocks can be added here

    def display_high_scores(self):
        with open('high_scores.txt', 'r') as file:
            high_scores = file.readlines()
            formatted_scores = [f"{idx + 1}. {score.strip()}" for idx, score in enumerate(high_scores)]
            return "\n".join(formatted_scores)

    def clear_blocks(self):
        cleared = self.grid.clear_blocks()
        self.score.update_score(len(cleared) * 10)

    def provide_visual_feedback(self, surface: pygame.Surface):
        for block in self.grid.blocks:
            if block.color == 'cleared':
                pygame.draw.rect(surface, (255, 255, 255), (block.position[0], block.position[1], 50, 50))
    
    def increase_difficulty(self):
        self.grid.increase_difficulty()
        self.level.increase_level()