import pygame

class Block:
    def __init__(self, color: str, position: tuple):
        self.color = color
        self.position = position

    def draw(self, surface: pygame.Surface):
        pygame.draw.rect(surface, self.color, (self.position[0], self.position[1], 50, 50))

    def is_adjacent(self, other: 'Block') -> bool:
        return (abs(self.position[0] - other.position[0]) == 50 and self.position[1] == other.position[1]) or \
               (abs(self.position[1] - other.position[1]) == 50 and self.position[0] == other.position[0])

    def is_connected(self, other: 'Block') -> bool:
        return self.color == other.color