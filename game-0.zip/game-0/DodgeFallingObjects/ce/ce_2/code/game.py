import pygame
from player import Player
from block import Block
import random

class Game:
    def __init__(self):
        self.player = Player(400)  # Start in the middle of the screen
        self.blocks = []
        self.score = 0
        self.is_running = True
        self.spawn_timer = 0

    def run(self):
        pygame.init()
        screen = pygame.display.set_mode((800, 600))
        clock = pygame.time.Clock()

        while self.is_running:
            self.handle_events()
            self.update_game_state()
            self.render(screen)
            clock.tick(60)

        pygame.quit()

    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.is_running = False

        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            self.player.move_left()
        if keys[pygame.K_RIGHT]:
            self.player.move_right()

    def update_game_state(self):
        self.spawn_timer += 1
        if self.spawn_timer > 30:  # Spawn a block every 30 frames
            self.spawn_block()
            self.spawn_timer = 0

        for block in self.blocks:
            block.fall()
            if self.check_collision():
                self.is_running = False

        self.blocks = [block for block in self.blocks if block.y_position < 600]

    def spawn_block(self):
        x_position = random.randint(0, 800 - 50)  # Assuming block width is 50
        speed = random.randint(1, 5)
        self.blocks.append(Block(x_position, speed))

    def check_collision(self) -> bool:
        player_pos = self.player.get_position()
        for block in self.blocks:
            block_pos = block.get_position()
            if (player_pos[0] < block_pos[0] + 50 and
                player_pos[0] + self.player.width > block_pos[0] and
                player_pos[1] < block_pos[1] + 50 and
                player_pos[1] + self.player.height > block_pos[1]):
                return True
        return False

    def update_score(self):
        self.score += 1

    def display_score(self):
        print(f"Score: {self.score}")