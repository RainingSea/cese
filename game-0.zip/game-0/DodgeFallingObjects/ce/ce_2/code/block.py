import random

class Block:
    def __init__(self, x_position: int, speed: int):
        self.x_position = x_position
        self.y_position = 0
        self.speed = speed

    def fall(self):
        self.y_position += self.speed

    def get_position(self) -> tuple:
        return (self.x_position, self.y_position)