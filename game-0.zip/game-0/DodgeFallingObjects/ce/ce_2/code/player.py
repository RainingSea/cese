class Player:
    def __init__(self, x_position: int):
        self.x_position = x_position
        self.width = 50
        self.height = 50

    def move_left(self):
        if self.x_position > 0:
            self.x_position -= 5

    def move_right(self):
        if self.x_position < 800 - self.width:  # Assuming the screen width is 800
            self.x_position += 5

    def get_position(self) -> tuple:
        return (self.x_position, 600 - self.height)  # Assuming the screen height is 600