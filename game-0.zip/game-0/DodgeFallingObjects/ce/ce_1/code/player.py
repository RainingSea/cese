class Player:
    def __init__(self, position_x: int):
        self.position_x = position_x
        self.width = 50
        self.height = 50

    def move_left(self):
        self.position_x -= 5

    def move_right(self):
        self.position_x += 5

    def get_position(self) -> int:
        return self.position_x