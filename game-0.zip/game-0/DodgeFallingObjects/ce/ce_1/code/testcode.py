import unittest
import pygame
from game import Game
from player import Player
from block import Block
import os

class TestDodgeFallingObjectsGame(unittest.TestCase):

    def setUp(self):
        # Initialize the game and its components
        pygame.init()
        self.game = Game()
        self.player = self.game.player
        self.blocks = self.game.blocks

    def test_player_movement(self):
        # Functionality 1: Test player movement to the left
        initial_x = self.player.position_x
        self.player.move_left()
        self.assertLess(self.player.position_x, initial_x, "Player should move left")

        # Test player movement to the right
        initial_x = self.player.position_x
        self.player.move_right()
        self.assertGreater(self.player.position_x, initial_x, "Player should move right")

        # Test player does not move beyond the left edge
        self.player.position_x = 0
        self.player.move_left()
        self.assertEqual(self.player.position_x, 0, "Player should not move beyond the left edge")

        # Test player does not move beyond the right edge
        self.player.position_x = self.game.screen_width - self.player.width
        self.player.move_right()
        self.assertEqual(self.player.position_x, self.game.screen_width - self.player.width, "Player should not move beyond the right edge")

    def test_collision_detection(self):
        # Functionality 2: Test collision detection
        self.blocks.append(Block(self.player.position_x))
        self.blocks[0].position_y = self.game.screen_height - self.player.height
        self.game.check_collision()
        self.assertFalse(pygame.get_init(), "Game should end on collision")

    def test_falling_blocks_behavior(self):
        # Functionality 3: Test falling blocks behavior
        initial_block_count = len(self.blocks)
        self.game.spawn_block()
        self.assertGreaterEqual(len(self.blocks), initial_block_count, "Blocks should spawn randomly")

        # Test block speed increase over time
        initial_speed = self.game.game_speed
        self.game.update_blocks()
        self.assertEqual(self.game.game_speed, initial_speed, "Block speed should increase over time")

    def test_scoring_system(self):
        # Functionality 4: Test scoring system
        initial_score = self.game.score
        self.game.update_score()
        self.assertGreater(self.game.score, initial_score, "Score should increase over time")

    def test_player_movement_constraints(self):
        # Functionality 5: Test player movement constraints
        initial_y = self.player.position_x
        self.player.move_left()
        self.assertEqual(self.player.position_x, initial_y - 5, "Player should not move vertically")

    def test_game_over_condition(self):
        # Functionality 6: Test game over condition
        self.blocks.append(Block(self.player.position_x))
        self.blocks[0].position_y = self.game.screen_height - self.player.height
        self.game.check_collision()
        self.assertFalse(pygame.get_init(), "Game should end on collision")

    def test_data_storage(self):
        # Functionality 7: Test data storage
        score_file = 'scores.txt'
        if os.path.exists(score_file):
            os.remove(score_file)
        self.game.score = 100
        with open(score_file, 'w') as f:
            f.write(str(self.game.score))
        with open(score_file, 'r') as f:
            saved_score = int(f.read())
        self.assertEqual(saved_score, self.game.score, "Score should be saved to a local text file")

if __name__ == '__main__':
    unittest.main()
