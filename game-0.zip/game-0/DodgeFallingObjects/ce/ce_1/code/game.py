import pygame
import random
from player import Player
from block import Block

class Game:
    def __init__(self):
        self.player = Player(300)
        self.blocks = []
        self.score = 0
        self.game_speed = 5
        self.screen_width = 800
        self.screen_height = 600
        self.window = pygame.display.set_mode((self.screen_width, self.screen_height))
        pygame.display.set_caption("Dodge the Falling Blocks")
        self.clock = pygame.time.Clock()

    def run(self):
        running = True
        while running:
            self.window.fill((0, 0, 0))
            self.handle_events()
            self.spawn_block()
            self.update_blocks()
            self.check_collision()
            self.update_score()
            self.display_final_score()
            pygame.display.flip()
            self.clock.tick(30)

    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()

        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] and self.player.position_x > 0:
            self.player.move_left()
        if keys[pygame.K_RIGHT] and self.player.position_x < self.screen_width - self.player.width:
            self.player.move_right()

    def spawn_block(self):
        if random.randint(1, 20) == 1:  # Randomly spawn a block
            new_block = Block(random.randint(0, self.screen_width - 50))
            self.blocks.append(new_block)

    def update_blocks(self):
        for block in self.blocks:
            block.fall(self.game_speed)
            if block.position_y > self.screen_height:
                self.blocks.remove(block)

    def check_collision(self):
        for block in self.blocks:
            if (self.player.get_position() < block.position_x + block.width and
                self.player.get_position() + self.player.width > block.position_x and
                block.position_y + block.height > self.screen_height - self.player.height):
                self.display_final_score()
                pygame.quit()
                exit()

    def update_score(self):
        self.score += 1

    def display_final_score(self):
        font = pygame.font.Font(None, 36)
        text = font.render(f'Score: {self.score}', True, (255, 255, 255))
        self.window.blit(text, (10, 10))