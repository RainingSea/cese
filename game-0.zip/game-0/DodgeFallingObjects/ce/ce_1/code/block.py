import random

class Block:
    def __init__(self, position_x: int):
        self.position_x = position_x
        self.position_y = 0
        self.width = 50
        self.height = 50

    def fall(self, speed: int):
        self.position_y += speed

    def get_position(self) -> int:
        return self.position_y