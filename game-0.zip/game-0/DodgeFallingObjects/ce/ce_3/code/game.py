import pygame
from player import Player
from block import Block

class Game:
    def __init__(self):
        self.player = Player(300, 50, 50)  # Initialize player
        self.blocks = []
        self.score = 0
        self.is_running = True

    def run(self):
        pygame.init()
        screen = pygame.display.set_mode((600, 600))
        clock = pygame.time.Clock()

        while self.is_running:
            self.handle_events()
            self.spawn_block()
            self.update_blocks()
            self.check_collision()
            self.display_score(screen)
            pygame.display.flip()
            clock.tick(60)

        self.game_over()

    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.is_running = False

        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            self.player.move_left()
        if keys[pygame.K_RIGHT]:
            self.player.move_right()

    def spawn_block(self):
        if len(self.blocks) < 5:  # Limit the number of blocks on screen
            self.blocks.append(Block.spawn_block(600))

    def update_blocks(self):
        for block in self.blocks:
            block.fall()

    def check_collision(self):
        player_x, player_y = self.player.get_position()
        for block in self.blocks:
            block_x, block_y = block.get_position()
            if (block_x < player_x + self.player.width and
                block_x + 50 > player_x and
                block_y < player_y + self.player.height and
                block_y + 50 > player_y):
                self.is_running = False  # Collision detected

    def update_score(self):
        self.score += 1  # Increment score

    def display_score(self, screen):
        font = pygame.font.Font(None, 36)
        text = font.render(f'Score: {self.score}', True, (255, 255, 255))
        screen.blit(text, (10, 10))

    def game_over(self):
        with open('scores.txt', 'a') as f:
            f.write(f'score: {self.score}\n')  # Save score to file
        pygame.quit()