class Player:
    def __init__(self, x: int, width: int, height: int):
        self.x_position = x
        self.width = width
        self.height = height

    def move_left(self):
        self.x_position -= 5  # Move left by 5 pixels

    def move_right(self):
        self.x_position += 5  # Move right by 5 pixels

    def get_position(self):
        return self.x_position, self.height  # Return current position