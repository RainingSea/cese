import random

class Block:
    def __init__(self, x: int, y: int, speed: int):
        self.x_position = x
        self.y_position = y
        self.speed = speed

    def fall(self):
        self.y_position += self.speed  # Move down by speed pixels

    def get_position(self):
        return self.x_position, self.y_position  # Return current position

    @staticmethod
    def spawn_block(screen_width: int):
        x_position = random.randint(0, screen_width - 50)  # Random x position
        return Block(x_position, 0, random.randint(3, 7))  # Random speed between 3 and 7