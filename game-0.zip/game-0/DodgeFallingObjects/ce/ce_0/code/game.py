import pygame
import random

class Player:
    def __init__(self, x: int, width: int, height: int):
        self.x_position = x
        self.width = width
        self.height = height

    def move_left(self):
        self.x_position -= 5

    def move_right(self):
        self.x_position += 5

class Block:
    def __init__(self, x: int, y: int, speed: int):
        self.x_position = x
        self.y_position = y
        self.speed = speed

    def fall(self):
        self.y_position += self.speed

class Game:
    def __init__(self):
        self.player = Player(300, 50, 50)
        self.blocks = []
        self.score = 0
        self.is_running = True

    def run(self):
        pygame.init()
        screen = pygame.display.set_mode((600, 600))
        clock = pygame.time.Clock()

        while self.is_running:
            self.handle_events()
            self.spawn_block()
            self.update_blocks()
            self.check_collision()
            self.display_score(screen)
            pygame.display.flip()
            clock.tick(60)

        self.game_over()

    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.is_running = False

        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] and self.player.x_position > 0:
            self.player.move_left()
        if keys[pygame.K_RIGHT] and self.player.x_position < 550:
            self.player.move_right()

    def spawn_block(self):
        if random.randint(1, 20) == 1:  # Randomly spawn a block
            block_x = random.randint(0, 550)
            new_block = Block(block_x, 0, 5)
            self.blocks.append(new_block)

    def update_blocks(self):
        for block in self.blocks:
            block.fall()

    def check_collision(self):
        for block in self.blocks:
            if (self.player.x_position < block.x_position + 50 and
                self.player.x_position + self.player.width > block.x_position and
                550 - self.player.height < block.y_position + 50):
                self.is_running = False

    def update_score(self):
        self.score += 1

    def display_score(self, screen):
        font = pygame.font.Font(None, 36)
        score_text = font.render(f'Score: {self.score}', True, (255, 255, 255))
        screen.blit(score_text, (10, 10))

    def game_over(self):
        with open('scores.txt', 'a') as f:
            f.write(f"{self.score}\n")
        pygame.quit()