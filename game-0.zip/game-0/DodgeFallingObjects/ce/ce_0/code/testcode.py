import unittest
import pygame
from game import Game, Player, Block

class TestDodgeFallingObjectsGame(unittest.TestCase):

    def setUp(self):
        # Initialize the game and its components
        self.game = Game()
        self.player = self.game.player

    def test_player_movement(self):
        # Functionality 1: Player Movement
        # Test moving left
        initial_x = self.player.x_position
        self.player.move_left()
        self.assertLess(self.player.x_position, initial_x, "Player should move left")

        # Test moving right
        initial_x = self.player.x_position
        self.player.move_right()
        self.assertGreater(self.player.x_position, initial_x, "Player should move right")

        # Test moving beyond the left edge
        self.player.x_position = 0
        self.player.move_left()
        self.assertEqual(self.player.x_position, 0, "Player should not move beyond the left edge")

        # Test moving beyond the right edge
        self.player.x_position = 550
        self.player.move_right()
        self.assertEqual(self.player.x_position, 550, "Player should not move beyond the right edge")

    def test_collision_detection(self):
        # Functionality 2: Collision Detection
        block = Block(self.player.x_position, 550 - self.player.height, 0)
        self.game.blocks.append(block)
        self.game.check_collision()
        self.assertFalse(self.game.is_running, "Game should end on collision with block")

        # Reset game state for next test
        self.game.is_running = True
        self.game.blocks = []

        # Test avoiding a block
        block = Block(self.player.x_position + 100, 550 - self.player.height, 0)
        self.game.blocks.append(block)
        self.game.check_collision()
        self.assertTrue(self.game.is_running, "Game should continue if player avoids block")

    def test_falling_blocks_behavior(self):
        # Functionality 3: Falling Blocks Behavior
        self.game.spawn_block()
        self.assertTrue(any(block.y_position == 0 for block in self.game.blocks), "Blocks should spawn at the top")

        # Test block falling
        block = Block(0, 0, 5)
        block.fall()
        self.assertEqual(block.y_position, 5, "Block should fall down")

    def test_scoring_system(self):
        # Functionality 4: Scoring System
        initial_score = self.game.score
        self.game.update_score()
        self.assertGreater(self.game.score, initial_score, "Score should increase over time")

    def test_player_movement_constraints(self):
        # Functionality 5: Player Movement Constraints
        initial_y = self.player.x_position
        self.player.move_left()
        self.assertEqual(self.player.x_position, initial_y, "Player should not move vertically")

    def test_game_over_condition(self):
        # Functionality 6: Game Over Condition
        block = Block(self.player.x_position, 550 - self.player.height, 0)
        self.game.blocks.append(block)
        self.game.check_collision()
        self.assertFalse(self.game.is_running, "Game should end on collision with block")

    def test_data_storage(self):
        # Functionality 7: Data Storage
        self.game.score = 10
        self.game.game_over()
        with open('scores.txt', 'r') as f:
            scores = f.readlines()
        self.assertIn("10\n", scores, "Score should be saved to the text file")

if __name__ == '__main__':
    unittest.main()
