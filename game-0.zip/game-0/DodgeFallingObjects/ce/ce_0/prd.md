[OUTPUT]
## general overview of the project
Develop a Dodge the Falling Blocks game. You must design a GUI.

## software functional requirements
1. The system shall allow the player to control a small character at the bottom of the screen using the left and right arrow keys.
2. The system shall implement a mechanism to spawn falling blocks from the top of the screen at random positions.
3. The falling blocks shall move straight down the screen, and their speed shall increase as the player survives longer.
4. The system shall maintain a scoring system that tracks the amount of time the player has survived, updating the score in real-time.
5. The player shall be restricted to horizontal movement only, with no ability to move vertically.
6. The game shall detect collisions between the player's character and the falling blocks, ending the game upon collision.
7. Upon game termination due to a collision, the system shall display the final score to the player.
[/OUTPUT]