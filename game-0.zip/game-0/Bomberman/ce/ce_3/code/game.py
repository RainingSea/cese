import pygame
from grid import Grid
from player import Player
from enemy import Enemy

class Game:
    def __init__(self):
        self.grid = Grid()
        self.player = Player()
        self.enemies = [Enemy() for _ in range(5)]
        self.screen = pygame.display.set_mode((640, 640))
        pygame.display.set_caption("Bomberman Game")
        self.clock = pygame.time.Clock()
        self.running = True

    def start(self):
        self.load_data()
        while self.running:
            self.update()
            self.draw()
            self.check_collisions()
            self.clock.tick(60)

    def update(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    self.player.place_bomb()
                elif event.key in (pygame.K_UP, pygame.K_DOWN, pygame.K_LEFT, pygame.K_RIGHT):
                    direction = {
                        pygame.K_UP: 'up',
                        pygame.K_DOWN: 'down',
                        pygame.K_LEFT: 'left',
                        pygame.K_RIGHT: 'right'
                    }[event.key]
                    self.player.move(direction)

        for enemy in self.enemies:
            enemy.move()

    def draw(self):
        self.screen.fill((0, 0, 0))
        self.grid.draw_grid(self.screen)
        self.player.draw(self.screen)
        for enemy in self.enemies:
            enemy.draw(self.screen)
        pygame.display.flip()

    def check_collisions(self):
        # Collision logic to be implemented
        pass

    def load_data(self):
        with open('player_data.txt', 'r') as f:
            data = f.read().strip().split('|')
            self.player.health = int(data[0])
            self.player.score = int(data[1])

        with open('enemy_data.txt', 'r') as f:
            enemy_data = f.read().strip().split('\n')
            for i, line in enumerate(enemy_data):
                if i < len(self.enemies):
                    self.enemies[i].health = int(line)

    def save_data(self):
        with open('player_data.txt', 'w') as f:
            f.write(f"{self.player.health}|{self.player.score}")

        with open('enemy_data.txt', 'w') as f:
            for enemy in self.enemies:
                f.write(f"{enemy.health}\n")