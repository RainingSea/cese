import pygame

class Grid:
    def __init__(self):
        self.layout = [[' ' for _ in range(13)] for _ in range(13)]

    def create_grid(self):
        # Logic to create grid layout can be implemented here
        pass

    def draw_grid(self, screen):
        block_size = 40
        for row in range(13):
            for col in range(13):
                pygame.draw.rect(screen, (255, 255, 255), (col * block_size, row * block_size, block_size, block_size), 1)