import pygame

class Player:
    def __init__(self):
        self.health = 3
        self.score = 0
        self.position = (0, 0)

    def move(self, direction: str) -> None:
        x, y = self.position
        if direction == 'up':
            self.position = (x, max(0, y - 1))
        elif direction == 'down':
            self.position = (x, min(12, y + 1))
        elif direction == 'left':
            self.position = (max(0, x - 1), y)
        elif direction == 'right':
            self.position = (min(12, x + 1), y)

    def place_bomb(self) -> None:
        # Logic to place a bomb can be implemented here
        pass

    def take_damage(self, amount: int) -> None:
        self.health -= amount

    def update_score(self, amount: int) -> None:
        self.score += amount

    def draw(self, screen):
        block_size = 40
        x, y = self.position
        pygame.draw.rect(screen, (0, 255, 0), (x * block_size, y * block_size, block_size, block_size))