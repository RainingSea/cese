import pygame
import random

class Enemy:
    def __init__(self):
        self.health = 2
        self.position = (random.randint(0, 12), random.randint(0, 12))

    def move(self) -> None:
        # Simple random movement logic
        direction = random.choice(['up', 'down', 'left', 'right'])
        x, y = self.position
        if direction == 'up' and y > 0:
            self.position = (x, y - 1)
        elif direction == 'down' and y < 12:
            self.position = (x, y + 1)
        elif direction == 'left' and x > 0:
            self.position = (x - 1, y)
        elif direction == 'right' and x < 12:
            self.position = (x + 1, y)

    def take_damage(self, amount: int) -> None:
        self.health -= amount

    def draw(self, screen):
        block_size = 40
        x, y = self.position
        pygame.draw.rect(screen, (255, 0, 0), (x * block_size, y * block_size, block_size, block_size))