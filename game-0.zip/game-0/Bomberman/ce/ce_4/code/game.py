import pygame
from player import Player
from enemy import Enemy
from bomb import Bomb

class Game:
    def __init__(self):
        self.grid = [[0 for _ in range(13)] for _ in range(13)]
        self.player = Player((1, 1))
        self.enemies = [Enemy((5, 5)), Enemy((7, 7))]
        self.bombs = []
        self.score = 0
        self.player_health = 3
        self.load_game_data()

    def run(self):
        clock = pygame.time.Clock()
        while True:
            self.handle_input()
            self.update()
            self.draw()
            clock.tick(60)

    def update(self):
        for enemy in self.enemies:
            enemy.move()
        for bomb in self.bombs:
            bomb.timer -= 1
            if bomb.timer <= 0:
                bomb.explode()
                self.bombs.remove(bomb)

    def draw(self):
        # Drawing logic here
        pass

    def handle_input(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.save_game_data()
                pygame.quit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    self.place_bomb()

    def check_collisions(self):
        # Collision logic here
        pass

    def place_bomb(self):
        bomb = Bomb(self.player.position)
        self.bombs.append(bomb)

    def load_game_data(self):
        try:
            with open('game_data.txt', 'r') as file:
                data = file.readlines()
                for line in data:
                    key, value = line.strip().split('|')
                    if key == 'score':
                        self.score = int(value)
                    elif key == 'player_health':
                        self.player_health = int(value)
        except FileNotFoundError:
            pass

    def save_game_data(self):
        with open('game_data.txt', 'w') as file:
            file.write(f'score|{self.score}\n')
            file.write(f'player_health|{self.player_health}\n')