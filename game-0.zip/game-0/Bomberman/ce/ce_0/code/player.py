class Player:
    def __init__(self, position: tuple):
        self.position = position
        self.health = 3

    def move(self, direction: str):
        if direction == "UP":
            self.position = (self.position[0], self.position[1] - 1)
        elif direction == "DOWN":
            self.position = (self.position[0], self.position[1] + 1)
        elif direction == "LEFT":
            self.position = (self.position[0] - 1, self.position[1])
        elif direction == "RIGHT":
            self.position = (self.position[0] + 1, self.position[1])

    def take_damage(self, amount: int):
        self.health -= amount

    def update(self):
        # Update logic to be implemented
        pass