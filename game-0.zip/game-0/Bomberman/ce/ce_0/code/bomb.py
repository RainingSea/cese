class Bomb:
    def __init__(self, position: tuple):
        self.position = position
        self.timer = 60  # Timer for explosion

    def explode(self):
        # Explosion logic to be implemented
        pass