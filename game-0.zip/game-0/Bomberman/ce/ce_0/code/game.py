import pygame
from player import Player
from enemy import Enemy
from bomb import Bomb

class Game:
    def __init__(self):
        self.grid = [[0 for _ in range(13)] for _ in range(13)]
        self.player = Player((1, 1))
        self.enemies = [Enemy((5, 5)), Enemy((7, 7))]
        self.bombs = []
        self.score = 0
        self.player_health = 3
        self.screen = pygame.display.set_mode((640, 640))
        pygame.display.set_caption("Bomberman Game")
        self.clock = pygame.time.Clock()

    def run(self):
        while True:
            self.handle_input()
            self.update()
            self.draw()
            self.clock.tick(60)

    def update(self):
        for enemy in self.enemies:
            enemy.update()
        for bomb in self.bombs:
            bomb.timer -= 1
            if bomb.timer <= 0:
                self.explode_bomb(bomb)

    def draw(self):
        self.screen.fill((255, 255, 255))
        for y in range(13):
            for x in range(13):
                if (x, y) == self.player.position:
                    pygame.draw.rect(self.screen, (0, 255, 0), (x * 40, y * 40, 40, 40))
                for enemy in self.enemies:
                    if (x, y) == enemy.position:
                        pygame.draw.rect(self.screen, (255, 0, 0), (x * 40, y * 40, 40, 40))
        pygame.display.flip()

    def handle_input(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    self.place_bomb()

    def check_collisions(self):
        # Collision logic to be implemented
        pass

    def place_bomb(self):
        bomb = Bomb(self.player.position)
        self.bombs.append(bomb)

    def explode_bomb(self, bomb: Bomb):
        # Explosion logic to be implemented
        self.bombs.remove(bomb)