import random

class Enemy:
    def __init__(self, position: tuple):
        self.position = position
        self.health = 1

    def move(self):
        direction = random.choice(["UP", "DOWN", "LEFT", "RIGHT"])
        if direction == "UP":
            self.position = (self.position[0], self.position[1] - 1)
        elif direction == "DOWN":
            self.position = (self.position[0], self.position[1] + 1)
        elif direction == "LEFT":
            self.position = (self.position[0] - 1, self.position[1])
        elif direction == "RIGHT":
            self.position = (self.position[0] + 1, self.position[1])

    def take_damage(self, amount: int):
        self.health -= amount

    def update(self):
        self.move()