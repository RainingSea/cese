[OUTPUT]
## general overview of the project
Develop a Bomberman Game

## software functional requirements
1. The game shall utilize a 13x13 grid layout.
2. The game shall place obstacles on even-numbered rows and columns of the grid.
3. The player character shall be represented in green, while enemy characters shall be represented in red.
4. The player and enemies shall be able to move within the grid while avoiding obstacles.
5. The player shall be able to place bombs using the space bar.
6. Bombs shall explode after a short delay, affecting all four directions for three squares.
7. Fire from bomb explosions shall be blocked by obstacles.
8. The player shall start with 100 health points and a score of 0.
9. Enemies shall start with 10 health points.
10. The player shall lose health when colliding with enemies or being caught in explosions.
11. If an enemy's health reaches 0, it shall disappear, and the player's score shall increase by 100 points.
12. The game shall end in a loss for the player if their health reaches 0.
13. The game shall end in a win for the player if all enemies are defeated.
14. Upon winning, the game shall display a victory message along with the player's score.
[/OUTPUT]