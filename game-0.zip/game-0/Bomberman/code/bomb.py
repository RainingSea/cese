class Bomb:
    def __init__(self, position: tuple):
        self.position = position
        self.timer = 60  # Timer for bomb explosion
        self.exploded = False

    def explode(self, players, enemies):
        if not self.exploded:
            self.exploded = True
            print(f"Bomb at {self.position} exploded!")
            self.check_damage(players, enemies)

    def check_damage(self, players, enemies):
        # Logic for checking damage to players and enemies
        for player in players:
            if self.is_within_range(player.position):
                player.take_damage(20)  # Example damage value

        for enemy in enemies:
            if self.is_within_range(enemy.position):
                enemy.take_damage(20)  # Example damage value
                if not enemy.is_alive():
                    print(f"Enemy at {enemy.position} defeated!")

    def is_within_range(self, position):
        # Check if the position is within the bomb's explosion range
        return abs(self.position[0] - position[0]) <= 1 and abs(self.position[1] - position[1]) <= 1