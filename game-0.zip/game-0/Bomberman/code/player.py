from bomb import Bomb

class Player:
    def __init__(self, health: int, score: int):
        self.health = health
        self.score = score
        self.position = (0, 0)  # Starting position

    def move(self, direction: str):
        if direction == 'UP' and self.position[1] > 0:
            self.position = (self.position[0], self.position[1] - 1)
        elif direction == 'DOWN' and self.position[1] < 12:
            self.position = (self.position[0], self.position[1] + 1)
        elif direction == 'LEFT' and self.position[0] > 0:
            self.position = (self.position[0] - 1, self.position[1])
        elif direction == 'RIGHT' and self.position[0] < 12:
            self.position = (self.position[0] + 1, self.position[1])

    def place_bomb(self):
        return Bomb(self.position)

    def take_damage(self, amount: int):
        self.health -= amount
        if self.health < 0:
            self.health = 0  # Health cannot go below zero

    def update_score(self, points: int):
        self.score += points

    def is_alive(self) -> bool:
        return self.health > 0