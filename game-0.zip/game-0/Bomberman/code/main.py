import pygame
from game import Game

def main():
    pygame.init()
    game = Game()
    game.load_data()
    game.run()
    game.save_data()  # Save data when the game ends
    pygame.quit()

if __name__ == "__main__":
    main()