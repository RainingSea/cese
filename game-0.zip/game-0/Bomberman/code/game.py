import json
from player import Player
from enemy import Enemy
from bomb import Bomb

class Game:
    def __init__(self):
        self.grid = [[0 for _ in range(13)] for _ in range(13)]
        self.player = Player(health=100, score=0)
        self.enemies = [Enemy(health=50) for _ in range(3)]
        self.bombs = []
        self.player_data = {}
        self.enemy_data = {}

    def run(self):
        # Main game loop
        while self.player.is_alive():
            self.update()
            self.render()
            if not self.player.is_alive():
                print("Game Over! You have lost.")
                break

    def update(self):
        # Update game state
        for enemy in self.enemies:
            enemy.move()

        # Check for bomb explosions
        for bomb in self.bombs:
            bomb.timer -= 1
            if bomb.timer <= 0:
                bomb.explode([self.player] + self.enemies, self.enemies)
                self.bombs.remove(bomb)

        # Check for player and enemy collisions
        for enemy in self.enemies:
            if self.player.position == enemy.position and self.player.is_alive():
                self.player.take_damage(10)  # Example damage value from enemy collision

        # Check for victory conditions
        self.enemies = [enemy for enemy in self.enemies if enemy.is_alive()]
        if not self.enemies:
            print("Congratulations! You have won the game.")
            exit()

    def render(self):
        # Render graphics
        pass

    def load_data(self):
        with open('player_data.txt', 'r') as file:
            data = file.readlines()
            for line in data:
                key, value = line.strip().split('|')
                self.player_data[key] = value

        with open('enemy_data.txt', 'r') as file:
            data = file.readlines()
            for line in data:
                key, value = line.strip().split('|')
                self.enemy_data[key] = value

        # Load player data into player object
        self.player.health = int(self.player_data.get('health', 100))
        self.player.score = int(self.player_data.get('score', 0))

        # Load enemy data into enemy objects
        for i in range(len(self.enemies)):
            self.enemies[i].health = int(self.enemy_data.get(f'enemy_{i}', 50))

    def save_data(self):
        with open('player_data.txt', 'w') as file:
            file.write(f"health|{self.player.health}\n")
            file.write(f"score|{self.player.score}\n")

        with open('enemy_data.txt', 'w') as file:
            for i, enemy in enumerate(self.enemies):
                file.write(f"enemy_{i}|{enemy.health}\n")