import random

class Enemy:
    def __init__(self, health: int):
        self.health = health
        self.position = (0, 0)  # Starting position

    def move(self):
        direction = random.choice(['UP', 'DOWN', 'LEFT', 'RIGHT'])
        if direction == 'UP' and self.position[1] > 0:
            self.position = (self.position[0], self.position[1] - 1)
        elif direction == 'DOWN' and self.position[1] < 12:
            self.position = (self.position[0], self.position[1] + 1)
        elif direction == 'LEFT' and self.position[0] > 0:
            self.position = (self.position[0] - 1, self.position[1])
        elif direction == 'RIGHT' and self.position[0] < 12:
            self.position = (self.position[0] + 1, self.position[1])

    def take_damage(self, amount: int):
        self.health -= amount
        if self.health < 0:
            self.health = 0  # Health cannot go below zero

    def is_alive(self) -> bool:
        return self.health > 0