import pygame

class Paddle:
    def __init__(self, position_x: int):
        self.position_x = position_x
        self.width = 100
        self.height = 10

    def move_left(self):
        self.position_x -= 10

    def move_right(self):
        self.position_x += 10

    def draw(self, screen):
        paddle_color = (0, 0, 255)  # Blue color for the paddle
        pygame.draw.rect(screen, paddle_color, (self.position_x, 580, self.width, self.height))