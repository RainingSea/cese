import pygame

class Ball:
    def __init__(self):
        self.position_x = 400
        self.position_y = 300
        self.velocity_x = 5
        self.velocity_y = -5

    def update(self):
        self.position_x += self.velocity_x
        self.position_y += self.velocity_y

    def draw(self, screen):
        ball_color = (0, 255, 0)  # Green color for the ball
        ball_radius = 10
        pygame.draw.circle(screen, ball_color, (self.position_x, self.position_y), ball_radius)