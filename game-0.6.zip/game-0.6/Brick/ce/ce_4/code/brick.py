class Brick:
    def __init__(self, lives: int):
        self.lives = lives

    def hit(self):
        if self.lives > 0:
            self.lives -= 1

    def draw(self, screen, position):
        if self.lives > 0:
            # Assuming a simple rectangle for brick representation
            brick_color = (255, 0, 0)  # Red color for the brick
            brick_width = 60
            brick_height = 20
            pygame.draw.rect(screen, brick_color, (position[0], position[1], brick_width, brick_height))