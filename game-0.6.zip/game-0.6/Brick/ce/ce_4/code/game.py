import pygame
from paddle import Paddle
from ball import Ball
from brick import Brick

class Game:
    def __init__(self):
        self.paddle = Paddle(350)
        self.ball = Ball()
        self.bricks = [Brick(1) for _ in range(10)]  # Create 10 bricks with 1 life each

    def run(self):
        pygame.init()
        screen = pygame.display.set_mode((800, 600))
        clock = pygame.time.Clock()
        running = True

        while running:
            self.handle_input()
            self.update()
            self.draw(screen)
            pygame.display.flip()
            clock.tick(60)

        pygame.quit()

    def update(self):
        self.ball.update()

    def draw(self, screen):
        screen.fill((0, 0, 0))  # Clear the screen with black
        self.paddle.draw(screen)
        self.ball.draw(screen)
        
        for i, brick in enumerate(self.bricks):
            brick.draw(screen, (i * 80 + 10, 50))  # Position bricks in a row

    def handle_input(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    self.paddle.move_left()
                if event.key == pygame.K_RIGHT:
                    self.paddle.move_right()