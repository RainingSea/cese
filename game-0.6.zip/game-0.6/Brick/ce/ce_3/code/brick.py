import pygame

class Brick:
    def __init__(self, life, position):
        self.life = life
        self.position = position
        self.width = 160
        self.height = 30

    def hit(self):
        self.life -= 1
        if self.life <= 0:
            return True
        return False

    def draw(self, screen):
        pygame.draw.rect(screen, (0, 255, 0), (self.position * self.width, 100, self.width, self.height))