import pygame
import json
from paddle import Paddle
from ball import Ball
from brick import Brick

class Game:
    def __init__(self):
        self.screen = pygame.display.set_mode((800, 600))
        self.clock = pygame.time.Clock()
        self.paddle = Paddle(400)
        self.ball = Ball(400, 300)
        self.bricks = self.load_bricks()

    def start_game(self):
        running = True
        while running:
            self.update()
            self.draw()
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                if event.type == pygame.KEYDOWN:
                    if event.key in [pygame.K_LEFT, pygame.K_RIGHT]:
                        self.paddle.move_left() if event.key == pygame.K_LEFT else self.paddle.move_right()
            self.clock.tick(60)

    def update(self):
        self.ball.move()
        self.ball.check_collision(self.paddle, self.bricks)

    def draw(self):
        self.screen.fill((0, 0, 0))
        self.paddle.draw(self.screen)
        self.ball.draw(self.screen)
        for brick in self.bricks:
            brick.draw(self.screen)
        pygame.display.flip()

    def load_bricks(self):
        with open('bricks.json', 'r') as file:
            data = json.load(file)
            return [Brick(brick['life'], brick['position']) for brick in data['bricks']]

    def save_bricks(self):
        data = {'bricks': [{'life': brick.life, 'position': brick.position} for brick in self.bricks]}
        with open('bricks.json', 'w') as file:
            json.dump(data, file)