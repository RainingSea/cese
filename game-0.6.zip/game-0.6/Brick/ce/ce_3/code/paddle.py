import pygame

class Paddle:
    def __init__(self, position):
        self.position = position
        self.width = 100
        self.height = 20

    def move_left(self):
        self.position -= 5
        if self.position < 0:
            self.position = 0

    def move_right(self):
        self.position += 5
        if self.position > 800 - self.width:
            self.position = 800 - self.width

    def draw(self, screen):
        pygame.draw.rect(screen, (255, 255, 255), (self.position, 580, self.width, self.height))