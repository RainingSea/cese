import pygame

class Ball:
    def __init__(self, x, y):
        self.position = [x, y]
        self.direction = [3, -3]
        self.radius = 10

    def move(self):
        self.position[0] += self.direction[0]
        self.position[1] += self.direction[1]
        if self.position[0] <= 0 or self.position[0] >= 800:
            self.direction[0] = -self.direction[0]
        if self.position[1] <= 0:
            self.direction[1] = -self.direction[1]

    def check_collision(self, paddle, bricks):
        if (self.position[1] + self.radius >= 580 and 
            paddle.position <= self.position[0] <= paddle.position + paddle.width):
            self.direction[1] = -self.direction[1]

        for brick in bricks:
            if (brick.position * 160 <= self.position[0] <= (brick.position + 1) * 160 and
                self.position[1] - self.radius <= 100):  # Assuming bricks are at y=100
                self.direction[1] = -self.direction[1]
                bricks.remove(brick)
                break

    def draw(self, screen):
        pygame.draw.circle(screen, (255, 0, 0), (int(self.position[0]), int(self.position[1])), self.radius)