class Ball:
    def __init__(self, x_position, y_position, x_velocity, y_velocity):
        self.x_position = x_position
        self.y_position = y_position
        self.x_velocity = x_velocity
        self.y_velocity = y_velocity

    def bounce(self):
        self.y_velocity = -self.y_velocity

    def launch(self):
        self.x_position += self.x_velocity
        self.y_position += self.y_velocity