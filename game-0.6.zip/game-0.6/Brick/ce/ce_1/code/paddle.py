class Paddle:
    def __init__(self, x_position, width):
        self.x_position = x_position
        self.width = width

    def move_left(self):
        self.x_position -= 10  # Move left by 10 pixels

    def move_right(self):
        self.x_position += 10  # Move right by 10 pixels