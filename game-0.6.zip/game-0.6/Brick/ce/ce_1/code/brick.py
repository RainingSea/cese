class Brick:
    def __init__(self, x_position, y_position, lives):
        self.x_position = x_position
        self.y_position = y_position
        self.lives = lives

    def hit(self):
        self.lives -= 1