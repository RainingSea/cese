import pygame

class Brick:
    def __init__(self, lives):
        self.lives = lives
        self.width = 75
        self.height = 20
        self.position_x = 0
        self.position_y = 0

    def hit(self):
        self.lives -= 1

    def is_destroyed(self):
        return self.lives <= 0

    def draw(self, window):
        if self.lives > 0:
            pygame.draw.rect(window, (255, 0, 0), (self.position_x, self.position_y, self.width, self.height))