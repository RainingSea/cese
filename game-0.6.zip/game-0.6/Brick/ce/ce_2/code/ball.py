import pygame

class Ball:
    def __init__(self, position_x, position_y):
        self.position_x = position_x
        self.position_y = position_y
        self.velocity_x = 4
        self.velocity_y = -4
        self.radius = 10

    def launch(self):
        pass

    def update_position(self):
        self.position_x += self.velocity_x
        self.position_y += self.velocity_y
        # Collision with walls
        if self.position_x <= 0 or self.position_x >= 800:
            self.velocity_x = -self.velocity_x
        if self.position_y <= 0:
            self.velocity_y = -self.velocity_y

    def draw(self, window):
        pygame.draw.circle(window, (255, 255, 255), (self.position_x, self.position_y), self.radius)