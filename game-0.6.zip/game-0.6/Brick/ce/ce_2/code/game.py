import pygame
from paddle import Paddle
from ball import Ball
from brick import Brick

class Game:
    def __init__(self):
        self.width = 800
        self.height = 600
        self.window = pygame.display.set_mode((self.width, self.height))
        self.paddle = Paddle(self.width // 2)
        self.ball = Ball(self.width // 2, self.height - 50)
        self.bricks = self.load_bricks()
        self.clock = pygame.time.Clock()
        self.running = True

    def load_bricks(self):
        bricks = []
        with open('bricks_data.txt', 'r') as file:
            for line in file:
                lives = int(line.strip())
                bricks.append(Brick(lives))
        return bricks

    def start_game(self):
        while self.running:
            self.update()
            self.draw()
            self.clock.tick(60)

    def update(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            self.paddle.move_left()
        if keys[pygame.K_RIGHT]:
            self.paddle.move_right()
        self.ball.update_position()

    def draw(self):
        self.window.fill((0, 0, 0))
        self.paddle.draw(self.window)
        self.ball.draw(self.window)
        for brick in self.bricks:
            brick.draw(self.window)
        pygame.display.flip()