import pygame

class Paddle:
    def __init__(self, position_x):
        self.width = 100
        self.height = 20
        self.position_x = position_x
        self.position_y = 580

    def move_left(self):
        if self.position_x > 0:
            self.position_x -= 5

    def move_right(self):
        if self.position_x < 800 - self.width:
            self.position_x += 5

    def draw(self, window):
        pygame.draw.rect(window, (255, 255, 255), (self.position_x, self.position_y, self.width, self.height))