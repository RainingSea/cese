import pygame
import os

class Brick:
    def __init__(self, lives):
        self.lives = lives

    def hit(self):
        self.lives -= 1

    def is_destroyed(self):
        return self.lives <= 0

class Paddle:
    def __init__(self, position_x):
        self.position_x = position_x

    def move_left(self):
        self.position_x -= 10

    def move_right(self):
        self.position_x += 10

class Ball:
    def __init__(self, position_x, position_y, velocity_x, velocity_y):
        self.position_x = position_x
        self.position_y = position_y
        self.velocity_x = velocity_x
        self.velocity_y = velocity_y

    def launch(self):
        self.position_x += self.velocity_x
        self.position_y += self.velocity_y

    def update_position(self):
        self.position_x += self.velocity_x
        self.position_y += self.velocity_y

class Game:
    def __init__(self):
        self.paddle = Paddle(300)
        self.ball = Ball(350, 400, 5, -5)
        self.bricks = self.load_game_data()

    def start_game(self):
        pygame.init()
        self.screen = pygame.display.set_mode((800, 600))
        pygame.display.set_caption("Brick Breaker")
        self.clock = pygame.time.Clock()
        self.run_game()

    def run_game(self):
        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False

            keys = pygame.key.get_pressed()
            if keys[pygame.K_LEFT]:
                self.paddle.move_left()
            if keys[pygame.K_RIGHT]:
                self.paddle.move_right()

            self.ball.launch()
            self.update_game()
            self.draw_elements()
            self.clock.tick(60)

        self.save_game_data()
        pygame.quit()

    def update_game(self):
        # Update game logic (e.g., collision detection, scoring)
        pass

    def draw_elements(self):
        self.screen.fill((0, 0, 0))
        # Draw paddle, ball, and bricks
        pygame.draw.rect(self.screen, (255, 255, 255), (self.paddle.position_x, 550, 100, 20))
        pygame.draw.circle(self.screen, (255, 0, 0), (self.ball.position_x, self.ball.position_y), 10)
        for i, brick in enumerate(self.bricks):
            if not brick.is_destroyed():
                pygame.draw.rect(self.screen, (0, 255, 0), (i * 80, 50, 75, 20))

        pygame.display.flip()

    def load_game_data(self):
        bricks = []
        if os.path.exists('game_data.txt'):
            with open('game_data.txt', 'r') as file:
                for line in file:
                    lives = int(line.strip())
                    bricks.append(Brick(lives))
        return bricks

    def save_game_data(self):
        with open('game_data.txt', 'w') as file:
            for brick in self.bricks:
                file.write(f"{brick.lives}\n")