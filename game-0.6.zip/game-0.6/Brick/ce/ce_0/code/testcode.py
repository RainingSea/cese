import unittest
import pygame
from game import Game, Paddle, Ball, Brick

class TestBrickBreakerGame(unittest.TestCase):

    def setUp(self):
        # Initialize the game and its components
        self.game = Game()
        self.paddle = self.game.paddle
        self.ball = self.game.ball
        self.bricks = self.game.bricks

    def test_control_paddle_movement(self):
        # Functionalities 1: Test paddle movement to the left
        initial_x = self.paddle.position_x
        self.paddle.move_left()
        self.assertLess(self.paddle.position_x, initial_x, "Paddle should move left")

        # Test paddle movement to the right
        initial_x = self.paddle.position_x
        self.paddle.move_right()
        self.assertGreater(self.paddle.position_x, initial_x, "Paddle should move right")

    def test_ball_bounce_mechanics(self):
        # Functionalities 2: Simulate ball hitting the paddle
        self.ball.position_x = self.paddle.position_x + 50  # Center of the paddle
        self.ball.position_y = 540  # Just above the paddle
        initial_velocity_y = self.ball.velocity_y
        self.ball.launch()
        self.assertEqual(self.ball.velocity_y, initial_velocity_y, "Ball should bounce off the paddle")

    def test_brick_splitting_logic(self):
        # Functionalities 3: Test brick splitting logic (not implemented in codebase)
        self.fail("Brick splitting logic is not implemented in the codebase")

    def test_brick_disappearance(self):
        # Functionalities 4: Hit a brick until it disappears
        brick = self.bricks[0]
        initial_lives = brick.lives
        for _ in range(initial_lives):
            brick.hit()
        self.assertTrue(brick.is_destroyed(), "Brick should disappear when life reaches 0")

    def test_game_start_mechanism(self):
        # Functionalities 5: Simulate starting the game by moving the paddle
        self.assertTrue(self.game.ball.position_x == 350 and self.game.ball.position_y == 400, "Game should start with ball in center")

    def test_ball_movement(self):
        # Functionalities 6: Test ball movement upwards
        initial_y = self.ball.position_y
        self.ball.launch()
        self.assertNotEqual(self.ball.position_y, initial_y, "Ball should move upwards")

    def test_save_game_state(self):
        # Functionalities 7: Test saving game state (not implemented in codebase)
        self.fail("Save game state functionality is not implemented in the codebase")

    def test_load_game_state(self):
        # Functionalities 8: Test loading game state (not implemented in codebase)
        self.fail("Load game state functionality is not implemented in the codebase")

    def test_end_game_condition(self):
        # Functionalities 9: Simulate the ball falling below the paddle
        self.ball.position_y = 601  # Below the screen
        self.game.update_game()
        self.assertFalse(self.game.run_game(), "Game should end when the ball falls below the paddle")

if __name__ == '__main__':
    unittest.main()
