import pygame

class Paddle:
    def __init__(self, position_x, width):
        self.position_x = position_x
        self.width = width

    def move_left(self):
        self.position_x = max(0, self.position_x - 10)

    def move_right(self):
        self.position_x = min(800 - self.width, self.position_x + 10)

    def draw(self, screen):
        pygame.draw.rect(screen, (255, 255, 255), (self.position_x, 580, self.width, 10))