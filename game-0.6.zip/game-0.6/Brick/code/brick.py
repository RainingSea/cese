import pygame

class Brick:
    def __init__(self, lives, position_x, position_y):
        self.lives = lives
        self.position_x = position_x
        self.position_y = position_y

    def hit(self):
        self.lives -= 1

    def is_destroyed(self):
        return self.lives <= 0

    def draw(self, screen):
        color = (255, 0, 0) if self.lives > 0 else (0, 0, 0)
        pygame.draw.rect(screen, color, (self.position_x, self.position_y, 60, 20))