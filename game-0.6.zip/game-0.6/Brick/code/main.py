import pygame
from game import Game

def main():
    game = Game()
    game.load_game_state('game_data.txt')  # Load game state at the start
    game.start_game()

    while game.running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                game.running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    game.paddle.move_left()
                if event.key == pygame.K_RIGHT:
                    game.paddle.move_right()

        game.update()
        game.draw()
        pygame.time.delay(30)

    game.save_game_state('game_data.txt')  # Save game state on exit
    pygame.quit()

if __name__ == "__main__":
    main()