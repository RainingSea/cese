import pygame
from paddle import Paddle
from ball import Ball
from brick import Brick
import os

class Game:
    def __init__(self):
        self.paddle = Paddle(370, 100)
        self.ball = Ball(400, 300, 5, -5)
        self.bricks = [Brick(1, x * 70 + 10, 30) for x in range(10)]
        self.score = 0

    def start_game(self):
        pygame.init()
        self.screen = pygame.display.set_mode((800, 600))
        pygame.display.set_caption("Breakout Game")
        self.running = True

    def update(self):
        self.ball.update()
        if self.ball.position_x <= 0 or self.ball.position_x >= 800:
            self.ball.velocity_x *= -1
        if self.ball.position_y <= 0:
            self.ball.velocity_y *= -1
        if self.ball.position_y >= 600:
            self.running = False  # End game if ball falls below paddle

        # Paddle collision
        if (self.paddle.position_x <= self.ball.position_x <= self.paddle.position_x + self.paddle.width and
                self.ball.position_y >= 570):
            self.ball.velocity_y *= -1

        # Brick collision
        for brick in self.bricks:
            if (brick.position_x <= self.ball.position_x <= brick.position_x + 60 and
                    brick.position_y <= self.ball.position_y <= brick.position_y + 20 and brick.lives > 0):
                brick.hit()
                self.ball.velocity_y *= -1
                self.score += 1

    def draw(self):
        self.screen.fill((0, 0, 0))
        self.paddle.draw(self.screen)
        self.ball.draw(self.screen)
        for brick in self.bricks:
            brick.draw(self.screen)
        pygame.display.flip()

    def load_game_state(self, filename: str):
        if not os.path.exists(filename):
            print("Game state file not found. Loading defaults.")
            return

        try:
            with open(filename, 'r') as file:
                data = file.readlines()
                self.score = int(data[0].strip())
                self.paddle.position_x = int(data[1].strip())
                self.ball.position_x = int(data[2].strip())
                self.ball.position_y = int(data[3].strip())
                self.ball.velocity_x = int(data[4].strip())
                self.ball.velocity_y = int(data[5].strip())
        except (ValueError, IndexError) as e:
            print(f"Error loading game state: {e}. Loading defaults.")
            self.reset_game_state()

    def save_game_state(self, filename: str):
        with open(filename, 'w') as file:
            file.write(f"{self.score}\n")
            file.write(f"{self.paddle.position_x}\n")
            file.write(f"{self.ball.position_x}\n")
            file.write(f"{self.ball.position_y}\n")
            file.write(f"{self.ball.velocity_x}\n")
            file.write(f"{self.ball.velocity_y}\n")

    def reset_game_state(self):
        self.score = 0
        self.paddle.position_x = 370
        self.ball.reset_position()
        self.bricks = [Brick(1, x * 70 + 10, 30) for x in range(10)]