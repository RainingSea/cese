import pygame
import random

class Ball:
    def __init__(self, size: float, position: tuple[float, float]) -> None:
        self.size = size
        self.position = position
    
    def move(self, delta_x: float, delta_y: float) -> None:
        self.position = (self.position[0] + delta_x, self.position[1] + delta_y)
    
    def grow(self, amount: float) -> None:
        self.size += amount


class Game:
    def __init__(self) -> None:
        self.player_ball = Ball(size=10.0, position=(400, 300))
        self.enemy_balls = []
        self.score = 0
        self.spawn_enemy_balls()
    
    def run(self) -> None:
        pygame.init()
        screen = pygame.display.set_mode((800, 600))
        clock = pygame.time.Clock()
        
        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
            
            keys = pygame.key.get_pressed()
            if keys[pygame.K_LEFT]:
                self.move_player('left')
            if keys[pygame.K_RIGHT]:
                self.move_player('right')
            if keys[pygame.K_UP]:
                self.move_player('up')
            if keys[pygame.K_DOWN]:
                self.move_player('down')

            self.check_collisions()
            
            screen.fill((0, 0, 0))
            self.draw(screen)
            pygame.display.flip()
            clock.tick(60)
        
        self.save_game()
        pygame.quit()
    
    def move_player(self, direction: str) -> None:
        if direction == 'left':
            self.player_ball.move(-5, 0)
        elif direction == 'right':
            self.player_ball.move(5, 0)
        elif direction == 'up':
            self.player_ball.move(0, -5)
        elif direction == 'down':
            self.player_ball.move(0, 5)

    def check_collisions(self) -> None:
        for enemy in self.enemy_balls:
            if self.is_colliding(self.player_ball, enemy):
                if self.player_ball.size > enemy.size:
                    self.player_ball.grow(1.0)
                    self.enemy_balls.remove(enemy)
                    self.score += 1
                else:
                    # Game over logic can be added here
                    pass

    def is_colliding(self, ball1: Ball, ball2: Ball) -> bool:
        distance = ((ball1.position[0] - ball2.position[0]) ** 2 + 
                     (ball1.position[1] - ball2.position[1]) ** 2) ** 0.5
        return distance < (ball1.size + ball2.size)
    
    def spawn_enemy_balls(self) -> None:
        for _ in range(5):
            size = random.uniform(5.0, 15.0)
            position = (random.uniform(0, 800), random.uniform(0, 600))
            self.enemy_balls.append(Ball(size, position))
    
    def save_game(self) -> None:
        with open('game_data.txt', 'w') as f:
            f.write(f'score={self.score}\n')