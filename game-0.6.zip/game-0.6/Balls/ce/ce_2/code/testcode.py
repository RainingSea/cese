import unittest
import pygame
from game import Game, Ball

class TestBallGame(unittest.TestCase):

    def setUp(self):
        # Initialize the game and its components
        self.game = Game()

    def test_player_ball_movement(self):
        # Functionalities 1: Simulate pressing the up arrow key to move the player's ball
        initial_position = self.game.player_ball.position
        self.game.move_player('up')
        expected_position = (initial_position[0], initial_position[1] - 5)
        self.assertEqual(self.game.player_ball.position, expected_position, "Player's ball should move upward")

    def test_enemy_ball_collision(self):
        # Functionalities 2: Position the player's ball to collide with a smaller enemy ball
        self.game.player_ball.size = 15.0
        enemy_ball = Ball(size=10.0, position=self.game.player_ball.position)
        self.game.enemy_balls.append(enemy_ball)
        self.game.check_collisions()
        self.assertNotIn(enemy_ball, self.game.enemy_balls, "Enemy ball should be removed after collision")
        self.assertGreater(self.game.player_ball.size, 15.0, "Player's ball should grow after consuming enemy ball")

    def test_player_ball_consumption(self):
        # Functionalities 3: Simulate a scenario where the player's ball is surrounded by larger enemy balls
        self.game.player_ball.size = 5.0
        enemy_ball = Ball(size=10.0, position=self.game.player_ball.position)
        self.game.enemy_balls.append(enemy_ball)
        # Assuming game over logic is implemented, check if game ends
        self.game.check_collisions()
        # Since game over logic is not implemented, we expect no change
        self.assertIn(enemy_ball, self.game.enemy_balls, "Game over logic is not implemented")

    def test_initialize_game_entities(self):
        # Functionalities 4: Trigger the game initialization function
        self.assertEqual(len(self.game.enemy_balls), 5, "There should be five enemy balls initialized")
        self.assertGreater(self.game.player_ball.size, max(ball.size for ball in self.game.enemy_balls), 
                           "Player's ball should be larger than any enemy ball")

    def test_enemy_ball_spawning(self):
        # Functionalities 5: Call the function responsible for spawning enemy balls
        initial_count = len(self.game.enemy_balls)
        self.game.spawn_enemy_balls()
        self.assertEqual(len(self.game.enemy_balls), initial_count + 5, "Five new enemy balls should be spawned")

    def test_data_storage_functionality(self):
        # Functionalities 6: Save the game state to a local text file
        self.game.save_game()
        with open('game_data.txt', 'r') as f:
            data = f.read()
        self.assertIn(f'score={self.game.score}', data, "Game state should be saved correctly to the file")

if __name__ == '__main__':
    unittest.main()
