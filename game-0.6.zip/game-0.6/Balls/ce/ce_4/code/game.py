import pygame
import random

class Player:
    def __init__(self):
        self.size = 20
        self.position_x = 400
        self.position_y = 300

    def move(self, direction: str):
        if direction == "UP":
            self.position_y -= 5
        elif direction == "DOWN":
            self.position_y += 5
        elif direction == "LEFT":
            self.position_x -= 5
        elif direction == "RIGHT":
            self.position_x += 5

    def grow(self, amount: int):
        self.size += amount

class EnemyBall:
    def __init__(self, size: int, position_x: int, position_y: int):
        self.size = size
        self.position_x = position_x
        self.position_y = position_y

class Game:
    def __init__(self):
        self.player = Player()
        self.enemy_balls = []
        self.score = 0
        self.spawn_enemies(5)

    def spawn_enemies(self, count: int):
        for _ in range(count):
            size = random.randint(10, 30)
            position_x = random.randint(0, 800)
            position_y = random.randint(0, 600)
            self.enemy_balls.append(EnemyBall(size, position_x, position_y))

    def run(self):
        pygame.init()
        screen = pygame.display.set_mode((800, 600))
        clock = pygame.time.Clock()
        running = True

        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False

            keys = pygame.key.get_pressed()
            if keys[pygame.K_UP]:
                self.player.move("UP")
            if keys[pygame.K_DOWN]:
                self.player.move("DOWN")
            if keys[pygame.K_LEFT]:
                self.player.move("LEFT")
            if keys[pygame.K_RIGHT]:
                self.player.move("RIGHT")

            self.check_collisions()
            screen.fill((0, 0, 0))
            self.draw(screen)
            pygame.display.flip()
            clock.tick(60)

        pygame.quit()

    def check_collisions(self):
        for enemy in self.enemy_balls:
            if (self.player.position_x < enemy.position_x + enemy.size and
                self.player.position_x + self.player.size > enemy.position_x and
                self.player.position_y < enemy.position_y + enemy.size and
                self.player.position_y + self.player.size > enemy.position_y):
                self.end_game()

    def update_score(self):
        self.score += 1

    def end_game(self):
        print("Game Over")
        pygame.quit()