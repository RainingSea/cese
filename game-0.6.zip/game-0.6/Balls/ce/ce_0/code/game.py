import pygame
import random

class Player:
    def __init__(self, size: int):
        self.size = size
        self.score = 0

    def grow(self, amount: int):
        self.size += amount

    def consume_enemy(self):
        self.score += 1


class EnemyBall:
    def __init__(self, size: int):
        self.size = size
        self.position = (random.randint(0, 800), random.randint(0, 600))

    def move(self):
        self.position = (self.position[0] + random.choice([-1, 1]), self.position[1] + random.choice([-1, 1]))


class Game:
    def __init__(self):
        self.player = Player(size=20)
        self.enemy_balls = []
        self.spawn_enemy_balls()

    def run(self):
        pygame.init()
        screen = pygame.display.set_mode((800, 600))
        clock = pygame.time.Clock()
        running = True

        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
            
            keys = pygame.key.get_pressed()
            if keys[pygame.K_LEFT]:
                self.player.position = (self.player.position[0] - 5, self.player.position[1])
            if keys[pygame.K_RIGHT]:
                self.player.position = (self.player.position[0] + 5, self.player.position[1])
            if keys[pygame.K_UP]:
                self.player.position = (self.player.position[0], self.player.position[1] - 5)
            if keys[pygame.K_DOWN]:
                self.player.position = (self.player.position[0], self.player.position[1] + 5)

            self.check_collisions()
            screen.fill((255, 255, 255))
            pygame.draw.circle(screen, (0, 255, 0), self.player.position, self.player.size)

            for enemy_ball in self.enemy_balls:
                enemy_ball.move()
                pygame.draw.circle(screen, (255, 0, 0), enemy_ball.position, enemy_ball.size)

            pygame.display.flip()
            clock.tick(60)

        self.end_game()

    def check_collisions(self):
        for enemy_ball in self.enemy_balls:
            distance = ((self.player.position[0] - enemy_ball.position[0]) ** 2 + 
                        (self.player.position[1] - enemy_ball.position[1]) ** 2) ** 0.5
            if distance < self.player.size + enemy_ball.size:
                self.player.consume_enemy()
                self.player.grow(5)
                self.enemy_balls.remove(enemy_ball)

    def spawn_enemy_balls(self):
        for _ in range(5):
            size = random.randint(10, 30)
            self.enemy_balls.append(EnemyBall(size))

    def end_game(self):
        with open('game_data.txt', 'w') as file:
            file.write(f'score|{self.player.score}\n')