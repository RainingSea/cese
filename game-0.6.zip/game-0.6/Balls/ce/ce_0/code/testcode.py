import unittest
import pygame
from game import Game, Player, EnemyBall
import os

class TestBallGame(unittest.TestCase):

    def setUp(self):
        # Initialize the game and its components
        self.game = Game()
        self.player = self.game.player
        self.enemy_balls = self.game.enemy_balls

    def test_player_ball_movement(self):
        # Functionalities 1: Simulate pressing the up arrow key to move the player's ball
        initial_position = self.player.position
        pygame.key.set_pressed([pygame.K_UP])
        self.game.run()
        self.assertLess(self.player.position[1], initial_position[1], "Player's ball should move upward")

    def test_enemy_ball_collision(self):
        # Functionalities 2: Position the player's ball to collide with a smaller enemy ball
        self.player.position = (100, 100)
        enemy_ball = EnemyBall(size=10)
        enemy_ball.position = (100, 100)
        self.enemy_balls.append(enemy_ball)
        self.game.check_collisions()
        self.assertGreater(self.player.size, 20, "Player's ball should grow in size")
        self.assertNotIn(enemy_ball, self.enemy_balls, "Enemy ball should be removed from the game")

    def test_player_ball_consumption(self):
        # Functionalities 3: Simulate a scenario where the player's ball is surrounded by larger enemy balls
        self.player.size = 10
        for _ in range(5):
            enemy_ball = EnemyBall(size=30)
            enemy_ball.position = self.player.position
            self.enemy_balls.append(enemy_ball)
        self.game.check_collisions()
        self.assertFalse(self.game.running, "Game should end when player's ball is consumed")

    def test_initialize_game_entities(self):
        # Functionalities 4: Trigger the game initialization function
        self.assertEqual(len(self.enemy_balls), 5, "There should be five enemy balls")
        self.assertGreater(self.player.size, max(enemy.size for enemy in self.enemy_balls), "Player's ball should be larger than enemy balls")

    def test_enemy_ball_spawning(self):
        # Functionalities 5: Call the function responsible for spawning enemy balls
        initial_count = len(self.enemy_balls)
        self.game.spawn_enemy_balls()
        self.assertEqual(len(self.enemy_balls), initial_count + 5, "Five new enemy balls should be spawned")

    def test_data_storage_functionality(self):
        # Functionalities 6: Save the game state to a local text file
        self.game.end_game()
        with open('game_data.txt', 'r') as file:
            data = file.read()
        self.assertIn(f'score|{self.player.score}', data, "Game state should be written to the text file correctly")

if __name__ == '__main__':
    unittest.main()
