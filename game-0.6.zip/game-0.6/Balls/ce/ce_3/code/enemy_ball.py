import random

class EnemyBall:
    def __init__(self, size: int, position_x: int, position_y: int):
        self.size = size
        self.position_x = position_x
        self.position_y = position_y

    @staticmethod
    def spawn_random_enemy_ball(max_size: int, screen_width: int, screen_height: int):
        size = random.randint(10, max_size)
        position_x = random.randint(0, screen_width)
        position_y = random.randint(0, screen_height)
        return EnemyBall(size, position_x, position_y)