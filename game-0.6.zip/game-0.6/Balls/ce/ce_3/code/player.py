class Player:
    def __init__(self, size: int):
        self.size = size
        self.position_x = 0
        self.position_y = 0

    def move(self, direction: str) -> None:
        if direction == 'up':
            self.position_y -= 5
        elif direction == 'down':
            self.position_y += 5
        elif direction == 'left':
            self.position_x -= 5
        elif direction == 'right':
            self.position_x += 5

    def grow(self, size_increase: int) -> None:
        self.size += size_increase