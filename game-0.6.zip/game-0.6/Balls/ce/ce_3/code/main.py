import pygame
from game import Game

def main():
    game = Game()
    game.initialize_game()

    clock = pygame.time.Clock()
    
    while not game.game_over:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                game.game_over = True
            
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    game.player.move('up')
                elif event.key == pygame.K_DOWN:
                    game.player.move('down')
                elif event.key == pygame.K_LEFT:
                    game.player.move('left')
                elif event.key == pygame.K_RIGHT:
                    game.player.move('right')

        game.update()
        game.render()
        clock.tick(60)

    pygame.quit()

if __name__ == "__main__":
    main()