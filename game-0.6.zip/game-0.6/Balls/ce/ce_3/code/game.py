import pygame
from player import Player
from enemy_ball import EnemyBall

class Game:
    def __init__(self):
        self.player = Player(size=20)
        self.enemy_balls = []
        self.game_over = False
        self.screen_width = 800
        self.screen_height = 600
        self.max_enemy_size = 30

    def initialize_game(self) -> None:
        pygame.init()
        self.screen = pygame.display.set_mode((self.screen_width, self.screen_height))
        pygame.display.set_caption("Battle of Balls")
        self.spawn_enemy_balls()

    def spawn_enemy_balls(self) -> None:
        for _ in range(5):
            enemy_ball = EnemyBall.spawn_random_enemy_ball(self.max_enemy_size, self.screen_width, self.screen_height)
            self.enemy_balls.append(enemy_ball)

    def update(self) -> None:
        # Update game logic
        self.handle_collisions()

    def handle_collisions(self) -> None:
        # Check for collisions between player and enemy balls
        for enemy in self.enemy_balls:
            if (self.player.position_x < enemy.position_x + enemy.size and
                self.player.position_x + self.player.size > enemy.position_x and
                self.player.position_y < enemy.position_y + enemy.size and
                self.player.position_y + self.player.size > enemy.position_y):
                self.player.grow(5)  # Grow player on collision
                self.enemy_balls.remove(enemy)  # Remove enemy ball on collision

    def render(self) -> None:
        self.screen.fill((255, 255, 255))  # Clear screen
        pygame.draw.circle(self.screen, (0, 0, 255), (self.player.position_x, self.player.position_y), self.player.size)
        for enemy in self.enemy_balls:
            pygame.draw.circle(self.screen, (255, 0, 0), (enemy.position_x, enemy.position_y), enemy.size)
        pygame.display.flip()

    def reset_game(self) -> None:
        self.player = Player(size=20)
        self.enemy_balls.clear()
        self.spawn_enemy_balls()
        self.game_over = False