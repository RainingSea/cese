class Player:
    def __init__(self, size=10, position_x=0, position_y=0):
        self.size = size
        self.position_x = position_x
        self.position_y = position_y

    def move(self, direction: str) -> None:
        if direction == 'up':
            self.position_y -= 5
        elif direction == 'down':
            self.position_y += 5
        elif direction == 'left':
            self.position_x -= 5
        elif direction == 'right':
            self.position_x += 5

    def grow(self) -> None:
        self.size += 1