import pygame
import sys
from game import Game

def main():
    pygame.init()
    screen = pygame.display.set_mode((800, 600))
    pygame.display.set_caption('Ball Game')
    clock = pygame.time.Clock()
    
    game = Game()
    
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

        screen.fill((255, 255, 255))
        # Draw player and enemies here
        pygame.display.flip()
        clock.tick(60)

if __name__ == "__main__":
    main()