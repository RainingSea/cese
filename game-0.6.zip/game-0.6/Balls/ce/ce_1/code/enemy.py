import random

class Enemy:
    def __init__(self, size=5, position_x=None, position_y=None):
        self.size = size
        self.position_x = position_x if position_x is not None else random.randint(0, 800)
        self.position_y = position_y if position_y is not None else random.randint(0, 600)

    def move(self) -> None:
        self.position_x += random.choice([-1, 1])
        self.position_y += random.choice([-1, 1])