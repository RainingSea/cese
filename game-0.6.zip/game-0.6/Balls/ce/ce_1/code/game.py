import random
from player import Player
from enemy import Enemy

class Game:
    def __init__(self):
        self.player = Player()
        self.enemies = []

    def run(self) -> None:
        self.spawn_enemies()
        while True:
            self.check_collisions()
            # Game loop logic can be implemented here

    def check_collisions(self) -> None:
        for enemy in self.enemies:
            if (self.player.position_x < enemy.position_x + enemy.size and
                self.player.position_x + self.player.size > enemy.position_x and
                self.player.position_y < enemy.position_y + enemy.size and
                self.player.position_y + self.player.size > enemy.position_y):
                self.player.grow()
                self.enemies.remove(enemy)

    def spawn_enemies(self) -> None:
        for _ in range(5):
            self.enemies.append(Enemy())