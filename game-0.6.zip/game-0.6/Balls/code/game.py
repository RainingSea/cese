import pygame
import json
import random

class Player:
    def __init__(self, size: int = 10, position_x: int = 400, position_y: int = 300):
        self.size = size
        self.position_x = position_x
        self.position_y = position_y

    def move(self, direction: str):
        if direction == 'UP':
            self.position_y -= 5
        elif direction == 'DOWN':
            self.position_y += 5
        elif direction == 'LEFT':
            self.position_x -= 5
        elif direction == 'RIGHT':
            self.position_x += 5

    def grow(self):
        self.size += 1

class Enemy:
    def __init__(self, size: int, position_x: int, position_y: int):
        self.size = size
        self.position_x = position_x
        self.position_y = position_y

    def move(self):
        self.position_x += random.choice([-1, 1]) * random.randint(1, 3)
        self.position_y += random.choice([-1, 1]) * random.randint(1, 3)

class Game:
    def __init__(self):
        self.player = Player(size=10)
        self.enemies = self.spawn_enemy_balls()
        self.score = 0
        self.screen = pygame.display.set_mode((800, 600))
        pygame.display.set_caption("Ball Game")
        self.clock = pygame.time.Clock()
        self.load_game_state()

    def spawn_enemy_balls(self):
        enemy_balls = []
        for _ in range(5):
            size = random.randint(5, 15)
            position_x = random.randint(0, 800)
            position_y = random.randint(0, 600)
            enemy_balls.append(Enemy(size=size, position_x=position_x, position_y=position_y))
        return enemy_balls

    def run(self):
        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False

            keys = pygame.key.get_pressed()
            if keys[pygame.K_UP]:
                self.player.move('UP')
            if keys[pygame.K_DOWN]:
                self.player.move('DOWN')
            if keys[pygame.K_LEFT]:
                self.player.move('LEFT')
            if keys[pygame.K_RIGHT]:
                self.player.move('RIGHT')

            self.update()
            self.draw()
            self.clock.tick(60)

        self.save_game_state()

    def update(self):
        for enemy in self.enemies:
            enemy.move()
        self.check_collisions()

    def draw(self):
        self.screen.fill((0, 0, 0))
        pygame.draw.circle(self.screen, (0, 255, 0), (self.player.position_x, self.player.position_y), self.player.size * 10)
        for enemy in self.enemies:
            pygame.draw.circle(self.screen, (255, 0, 0), (enemy.position_x, enemy.position_y), enemy.size * 10)
        font = pygame.font.Font(None, 36)
        score_text = font.render(f'Score: {self.score}', True, (255, 255, 255))
        self.screen.blit(score_text, (10, 10))
        pygame.display.flip()

    def check_collisions(self):
        for enemy in self.enemies[:]:
            if (self.player.position_x - enemy.position_x) ** 2 + (self.player.position_y - enemy.position_y) ** 2 < (self.player.size * 10) ** 2:
                if self.player.size > enemy.size:
                    self.player.grow()
                    self.enemies.remove(enemy)
                    self.score += 1
                else:
                    self.game_over()

    def game_over(self):
        print("Game Over! You collided with a larger enemy.")
        pygame.quit()

    def save_game_state(self):
        game_state = {
            'player': {
                'size': self.player.size,
                'position_x': self.player.position_x,
                'position_y': self.player.position_y
            },
            'score': self.score,
            'enemies': [{'size': enemy.size, 'position_x': enemy.position_x, 'position_y': enemy.position_y} for enemy in self.enemies]
        }
        with open('game_state.json', 'w') as f:
            json.dump(game_state, f)

    def load_game_state(self):
        try:
            with open('game_state.json', 'r') as f:
                game_state = json.load(f)
                self.player.size = game_state['player']['size']
                self.player.position_x = game_state['player']['position_x']
                self.player.position_y = game_state['player']['position_y']
                self.score = game_state['score']
                self.enemies = [Enemy(size=enemy['size'], position_x=enemy['position_x'], position_y=enemy['position_y']) for enemy in game_state['enemies']]
        except FileNotFoundError:
            pass