from game import Game

def main():
    game = Game()
    game.load_game_data()
    game.run()
    game.save_game_data()

if __name__ == "__main__":
    main()