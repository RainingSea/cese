import unittest
import pygame
from game import Game, Player, Enemy, Bomb

class TestBombermanGame(unittest.TestCase):

    def setUp(self):
        # Initialize the game and its components
        self.game = Game()
        self.player = self.game.player
        self.enemies = self.game.enemies
        self.bombs = self.game.bombs

    def test_player_movement(self):
        # Functionalities 1: Test player movement upwards
        initial_position = self.player.position
        self.player.move('UP')
        self.assertNotEqual(self.player.position, initial_position, "Player should move up")

    def test_enemy_movement(self):
        # Functionalities 2: Test enemy movement
        initial_position = self.enemies[0].position
        self.enemies[0].move()
        self.assertNotEqual(self.enemies[0].position, initial_position, "Enemy should move")

    def test_bomb_placement(self):
        # Functionalities 3: Test bomb placement
        initial_bomb_count = len(self.bombs)
        self.player.place_bomb()
        self.assertEqual(len(self.bombs), initial_bomb_count + 1, "Bomb should be placed")

    def test_bomb_explosion(self):
        # Functionalities 4: Test bomb explosion
        bomb = Bomb(self.player.position)
        explosion_area = bomb.explode()
        self.assertIn(self.player.position, explosion_area, "Explosion should affect the player's position")

    def test_health_loss_from_enemy_collision(self):
        # Functionalities 5: Test health loss from enemy collision
        initial_health = self.player.health
        self.player.lose_health(10)
        self.assertEqual(self.player.health, initial_health - 10, "Player health should decrease")

    def test_health_loss_from_bomb_explosion(self):
        # Functionalities 6: Test health loss from bomb explosion
        initial_health = self.player.health
        bomb = Bomb(self.player.position)
        explosion_area = bomb.explode()
        if self.player.position in explosion_area:
            self.player.lose_health(20)
        self.assertEqual(self.player.health, initial_health - 20, "Player health should decrease from explosion")

    def test_enemy_defeat(self):
        # Functionalities 7: Test enemy defeat
        enemy = self.enemies[0]
        initial_score = self.game.score
        enemy.lose_health(50)
        if enemy.health == 0:
            self.game.score += 100
        self.assertEqual(self.game.score, initial_score + 100, "Score should increase by 100 when enemy is defeated")

    def test_player_victory_conditions(self):
        # Functionalities 8: Test player victory conditions
        for enemy in self.enemies:
            enemy.lose_health(50)
        victory = all(enemy.health == 0 for enemy in self.enemies)
        self.assertTrue(victory, "Player should win when all enemies are defeated")

    def test_player_loss_condition(self):
        # Functionalities 9: Test player loss condition
        self.player.lose_health(100)
        self.assertEqual(self.player.health, 0, "Player should lose when health reaches 0")

    def test_score_initialization(self):
        # Functionalities 10: Test score initialization
        self.assertEqual(self.game.score, 0, "Score should be initialized to 0 at the start of the game")

if __name__ == '__main__':
    unittest.main()
