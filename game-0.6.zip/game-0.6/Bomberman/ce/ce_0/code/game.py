import pygame
import random

class Player:
    def __init__(self, position: tuple):
        self.position = position
        self.health = 3

    def move(self, direction: str):
        if direction == 'UP':
            self.position = (self.position[0], self.position[1] - 1)
        elif direction == 'DOWN':
            self.position = (self.position[0], self.position[1] + 1)
        elif direction == 'LEFT':
            self.position = (self.position[0] - 1, self.position[1])
        elif direction == 'RIGHT':
            self.position = (self.position[0] + 1, self.position[1])

    def place_bomb(self):
        pass  # Placeholder for bomb placement

    def lose_health(self, amount: int):
        self.health -= amount


class Enemy:
    def __init__(self, position: tuple):
        self.position = position
        self.health = 1

    def move(self):
        # Simple random movement for the enemy
        direction = random.choice(['UP', 'DOWN', 'LEFT', 'RIGHT'])
        if direction == 'UP':
            self.position = (self.position[0], self.position[1] - 1)
        elif direction == 'DOWN':
            self.position = (self.position[0], self.position[1] + 1)
        elif direction == 'LEFT':
            self.position = (self.position[0] - 1, self.position[1])
        elif direction == 'RIGHT':
            self.position = (self.position[0] + 1, self.position[1])

    def take_damage(self, amount: int):
        self.health -= amount


class Game:
    def __init__(self):
        self.grid = [[0 for _ in range(13)] for _ in range(13)]
        self.player = Player((1, 1))
        self.enemies = [Enemy((random.randint(0, 12), random.randint(0, 12))) for _ in range(3)]
        self.obstacles = []
        self.score = 0
        self.player_health = self.player.health

    def run(self):
        pygame.init()
        self.screen = pygame.display.set_mode((640, 640))
        pygame.display.set_caption("Bomberman Game")
        self.clock = pygame.time.Clock()
        self.game_loop()

    def game_loop(self):
        running = True
        while running:
            self.handle_input()
            self.update_game_state()
            self.draw_grid()
            pygame.display.flip()
            self.clock.tick(60)

    def draw_grid(self):
        self.screen.fill((255, 255, 255))
        for y in range(13):
            for x in range(13):
                color = (0, 0, 0) if (x % 2 == 0 and y % 2 == 0) else (255, 255, 255)
                pygame.draw.rect(self.screen, color, (x * 40, y * 40, 40, 40), 0)

        pygame.draw.rect(self.screen, (0, 255, 0), (self.player.position[0] * 40, self.player.position[1] * 40, 40, 40), 0)
        for enemy in self.enemies:
            pygame.draw.rect(self.screen, (255, 0, 0), (enemy.position[0] * 40, enemy.position[1] * 40, 40, 40), 0)

    def handle_input(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    self.player.move('UP')
                elif event.key == pygame.K_DOWN:
                    self.player.move('DOWN')
                elif event.key == pygame.K_LEFT:
                    self.player.move('LEFT')
                elif event.key == pygame.K_RIGHT:
                    self.player.move('RIGHT')

    def update_game_state(self):
        for enemy in self.enemies:
            enemy.move()

    def check_collisions(self):
        # Placeholder for collision checking
        pass

    def save_player_data(self):
        with open('player_data.txt', 'w') as file:
            file.write(f'score|{self.score}\n')
            file.write(f'health|{self.player.health}\n')