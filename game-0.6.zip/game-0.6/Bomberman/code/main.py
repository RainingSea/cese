import pygame
from game import Game

def main():
    pygame.init()
    game = Game()
    game.start_game()

    running = True
    while running:
        game.update_game()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

    pygame.quit()

if __name__ == "__main__":
    main()