import json
import random

class Game:
    def __init__(self):
        self.player = Player()
        self.enemies = [Enemy() for _ in range(5)]
        self.grid = Grid()
        self.score = 0
        self.player_health = 100

    def start_game(self):
        self.grid.initialize_grid()
        self.load_game_state()

    def update_game(self):
        for enemy in self.enemies:
            enemy.move()
        self.check_collisions()
        self.save_game_state()
        self.check_victory_conditions()

    def check_collisions(self):
        for enemy in self.enemies:
            if self.player.collides_with(enemy):
                self.player.take_damage(10)
                enemy.lose_health(10)  # Inflict damage to the enemy
                if self.player.health <= 0:
                    self.display_victory_message("Game Over")
                    return  # Stop further processing if game is over
                if enemy.health <= 0:
                    self.enemies.remove(enemy)  # Remove defeated enemy
                    self.score += 100  # Update score for defeating an enemy

    def check_victory_conditions(self):
        if len(self.enemies) == 0:
            self.display_victory_message("You have defeated all enemies! You win!")

    def display_victory_message(self, message):
        print(message)

    def load_game_state(self):
        try:
            with open('game_state.json', 'r') as file:
                state = json.load(file)
                self.player.health = state['player_health']
                self.score = state['score']
                self.enemies = [Enemy(health=e['health']) for e in state['enemies']]
        except FileNotFoundError:
            print("No previous game state found. Starting fresh.")

    def save_game_state(self):
        state = {
            'player_health': self.player.health,
            'score': self.score,
            'enemies': [{'health': enemy.health} for enemy in self.enemies]
        }
        with open('game_state.json', 'w') as file:
            json.dump(state, file)

class Player:
    def __init__(self):
        self.health = 100
        self.score = 0
        self.position = (0, 0)  # Initialize player position
        self.bombs = []
        self.max_bombs = 3  # Maximum bombs player can place

    def move(self, direction: str):
        if direction == 'UP':
            self.position = (self.position[0], self.position[1] - 1)
        elif direction == 'DOWN':
            self.position = (self.position[0], self.position[1] + 1)
        elif direction == 'LEFT':
            self.position = (self.position[0] - 1, self.position[1])
        elif direction == 'RIGHT':
            self.position = (self.position[0] + 1, self.position[1])

    def place_bomb(self):
        if len(self.bombs) < self.max_bombs:
            new_bomb = Bomb(self.position)  # Place bomb at current position
            self.bombs.append(new_bomb)

    def take_damage(self, amount: int):
        self.health -= amount

    def collides_with(self, enemy):
        # Simple collision detection logic based on positions
        return self.position == enemy.position

class Enemy:
    def __init__(self, health=50):
        self.health = health
        self.position = (random.randint(0, 12), random.randint(0, 12))  # Random initial position

    def move(self):
        direction = random.choice(['UP', 'DOWN', 'LEFT', 'RIGHT'])
        if direction == 'UP':
            self.position = (self.position[0], max(0, self.position[1] - 1))
        elif direction == 'DOWN':
            self.position = (self.position[0], min(12, self.position[1] + 1))
        elif direction == 'LEFT':
            self.position = (max(0, self.position[0] - 1), self.position[1])
        elif direction == 'RIGHT':
            self.position = (min(12, self.position[0] + 1), self.position[1])

    def lose_health(self, amount: int) -> None:
        self.health -= amount
        if self.health < 0:
            self.health = 0

class Bomb:
    def __init__(self, position):
        self.position = position
        self.timer = 3
        self.explosion_range = 1

    def explode(self):
        # Logic for bomb explosion
        print(f"Bomb exploded at {self.position}!")

class Grid:
    def __init__(self):
        self.grid_data = []

    def initialize_grid(self):
        self.grid_data = [[' ' for _ in range(13)] for _ in range(13)]
        self.place_obstacles()

    def place_obstacles(self):
        # Logic for placing obstacles on the grid
        with open('obstacles.txt', 'r') as file:
            for row_index, line in enumerate(file):
                self.grid_data[row_index] = list(line.strip().replace('|', ''))

    def render(self):
        # Logic for rendering the grid
        for row in self.grid_data:
            print(''.join(row))

    def handle_bomb_explosion(self, bomb):
        # Handle bomb explosion effects on player and enemies
        for enemy in self.enemies:
            if self.is_within_explosion_range(bomb.position, enemy.position):
                enemy.lose_health(20)  # Damage to enemy
        if self.is_within_explosion_range(bomb.position, self.player.position):
            self.player.take_damage(20)  # Damage to player

    def is_within_explosion_range(self, bomb_position, target_position):
        return (abs(bomb_position[0] - target_position[0]) <= bomb.explosion_range and
                abs(bomb_position[1] - target_position[1]) <= bomb.explosion_range)