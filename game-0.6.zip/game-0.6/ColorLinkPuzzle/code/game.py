import pygame
import json
from grid import Grid
from score import Score
from menu import Menu
from level import Level
from powerup import PowerUp

class Game:
    def __init__(self):
        self.grid = Grid()
        self.score = Score()
        self.menu = Menu()
        self.level = Level()
        self.high_scores = self.load_high_scores()
        self.powerups = []

    def start_game(self):
        settings = self.load_settings()
        self.grid.initialize_grid(settings["grid_size"])
        self.run_game_loop()

    def run_game_loop(self):
        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                self.update()
                self.draw()
            self.menu.display_menu()  # Display menu during the game loop

    def update(self):
        # Game update logic
        self.check_powerups()

    def draw(self):
        # Game drawing logic
        self.display_high_scores()  # Display high scores on the screen

    def load_high_scores(self):
        try:
            with open('high_scores.json', 'r') as file:
                high_scores = json.load(file)["high_scores"]
                return high_scores
        except FileNotFoundError:
            return []

    def load_settings(self):
        try:
            with open('settings.json', 'r') as file:
                settings = json.load(file)
                return settings
        except FileNotFoundError:
            return {"grid_size": 5, "theme": "default", "sound": True}

    def clear_blocks(self, blocks: list):
        cleared_blocks = self.grid.clear_connected_blocks(blocks[0])
        self.score.update_score(len(cleared_blocks))
        self.provide_visual_feedback(cleared_blocks)
        self.spawn_powerup(blocks[0])

    def check_connection(self, start: tuple, end: tuple) -> bool:
        return self.grid.validate_connection(start, end)

    def next_level(self):
        self.level.next_level()
        self.grid.increase_difficulty(self.level.difficulty)

    def provide_visual_feedback(self, cleared_blocks: list):
        # Logic to provide visual feedback for cleared blocks
        for block in cleared_blocks:
            # Change color or animate the cleared block
            pass

    def spawn_powerup(self, position: tuple):
        if self.should_spawn_powerup():
            powerup = PowerUp(position)
            self.powerups.append(powerup)

    def should_spawn_powerup(self) -> bool:
        # Logic to determine if a power-up should spawn
        return True  # Placeholder for actual logic

    def check_powerups(self):
        # Logic to check and apply power-ups
        for powerup in self.powerups:
            powerup.apply_effect(self)

    def display_high_scores(self):
        # Logic to display high scores on the screen
        for score in self.high_scores:
            print(f"{score['name']}: {score['score']}")  # Placeholder for actual display logic