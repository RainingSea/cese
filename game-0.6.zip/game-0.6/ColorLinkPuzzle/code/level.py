class Level:
    def __init__(self):
        self.difficulty = 1

    def next_level(self) -> None:
        self.difficulty += 1