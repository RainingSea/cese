class Block:
    def __init__(self, color: str):
        self.color = color
        self.is_cleared = False