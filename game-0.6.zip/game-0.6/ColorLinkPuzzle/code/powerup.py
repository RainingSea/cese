class PowerUp:
    def __init__(self, position: tuple):
        self.position = position
        self.effect_type = self.random_effect()

    def random_effect(self):
        # Logic to randomly assign an effect type
        return "score_boost"  # Placeholder for actual effects

    def apply_effect(self, game):
        if self.effect_type == "score_boost":
            game.score.update_score(100)  # Example effect