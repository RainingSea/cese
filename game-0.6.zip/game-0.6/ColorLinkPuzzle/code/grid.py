from block import Block
from collections import deque

class Grid:
    def __init__(self):
        self.blocks = []

    def initialize_grid(self, size: int):
        self.blocks = [[Block(color='red') for _ in range(size)] for _ in range(size)]

    def clear_connected_blocks(self, position: tuple) -> list:
        cleared_blocks = []
        queue = deque([position])
        color = self.blocks[position[0]][position[1]].color

        while queue:
            current = queue.popleft()
            x, y = current
            if self.blocks[x][y].color == color and not self.blocks[x][y].is_cleared:
                self.blocks[x][y].is_cleared = True
                cleared_blocks.append(current)
                for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                    neighbor = (x + dx, y + dy)
                    if (0 <= neighbor[0] < len(self.blocks) and 
                        0 <= neighbor[1] < len(self.blocks[0]) and 
                        not self.blocks[neighbor[0]][neighbor[1]].is_cleared):
                        queue.append(neighbor)
        return cleared_blocks

    def validate_connection(self, start: tuple, end: tuple) -> bool:
        queue = deque([start])
        visited = set()
        while queue:
            current = queue.popleft()
            if current == end:
                return True
            visited.add(current)
            for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                neighbor = (current[0] + dx, current[1] + dy)
                if (0 <= neighbor[0] < len(self.blocks) and 
                    0 <= neighbor[1] < len(self.blocks[0]) and 
                    neighbor not in visited and 
                    not self.blocks[neighbor[0]][neighbor[1]].is_cleared):
                    queue.append(neighbor)
        return False

    def increase_difficulty(self, difficulty: int):
        # Logic to increase grid difficulty based on level
        for row in self.blocks:
            for block in row:
                block.color = self.get_new_color_based_on_difficulty(difficulty)

    def get_new_color_based_on_difficulty(self, difficulty: int) -> str:
        # Logic to determine new color based on difficulty
        return 'blue' if difficulty % 2 == 0 else 'red'  # Placeholder logic