import pygame
from game import Game

def main() -> None:
    pygame.init()
    game = Game()
    game.start_game()
    # Main game loop and event handling will go here

if __name__ == "__main__":
    main()