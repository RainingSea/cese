class Menu:
    def show_menu(self):
        print("1. Start New Game")
        print("2. View High Scores")
        choice = input("Choose an option: ")
        return choice

    def start_game(self):
        # Placeholder for starting the game
        pass

    def view_high_scores(self):
        # Placeholder for viewing high scores
        pass