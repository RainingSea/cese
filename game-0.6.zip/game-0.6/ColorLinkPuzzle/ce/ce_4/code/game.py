from block import Block
from high_scores import HighScores

class Game:
    def __init__(self):
        self.grid = [[Block("red", (x, y)) for x in range(5)] for y in range(5)]  # Example grid
        self.score = 0
        self.level = 1
        self.high_scores = HighScores()
        self.high_scores.load_scores()

    def run_game(self):
        # Placeholder for the game loop
        pass

    def draw_grid(self):
        for row in self.grid:
            for block in row:
                block.draw(None)  # Replace None with the actual surface

    def clear_blocks(self, coordinates: list[tuple[int, int]]):
        for coord in coordinates:
            x, y = coord
            self.grid[y][x] = None  # Clear the block

    def check_connection(self, start: tuple[int, int], end: tuple[int, int]) -> bool:
        # Placeholder for connection logic
        return True

    def update_score(self, points: int):
        self.score += points