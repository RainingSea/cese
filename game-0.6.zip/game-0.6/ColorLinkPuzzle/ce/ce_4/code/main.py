import pygame
from game import Game
from menu import Menu

def main():
    pygame.init()
    game = Game()
    menu = Menu()

    while True:
        choice = menu.show_menu()
        if choice == '1':
            game.run_game()
        elif choice == '2':
            menu.view_high_scores()
        else:
            break

if __name__ == "__main__":
    main()