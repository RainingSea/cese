class HighScores:
    def __init__(self):
        self.scores = {}

    def load_scores(self):
        try:
            with open('high_scores.txt', 'r') as file:
                for line in file:
                    player_name, score = line.strip().split(',')
                    self.scores[player_name] = int(score)
        except FileNotFoundError:
            self.scores = {}

    def save_score(self, player_name: str, score: int):
        self.scores[player_name] = score
        with open('high_scores.txt', 'a') as file:
            file.write(f"{player_name},{score}\n")

    def get_high_scores(self) -> list[tuple[str, int]]:
        return sorted(self.scores.items(), key=lambda x: x[1], reverse=True)