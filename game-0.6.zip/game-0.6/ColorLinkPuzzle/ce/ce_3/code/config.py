import json

class Config:
    def __init__(self):
        self.levels = {}

    def load_config(self) -> None:
        with open('config.txt', 'r') as file:
            self.levels = json.load(file)

    def get_level(self, level_number: int) -> list[list[str]]:
        return self.levels.get(level_number, [])