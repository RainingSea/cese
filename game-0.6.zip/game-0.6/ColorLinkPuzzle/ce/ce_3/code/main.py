import pygame
from menu import Menu
from game import Game

def main() -> None:
    pygame.init()
    menu = Menu()
    game = Game()

    # Placeholder for main game loop
    running = True
    while running:
        # Placeholder for handling events and updating game state
        pass

if __name__ == "__main__":
    main()