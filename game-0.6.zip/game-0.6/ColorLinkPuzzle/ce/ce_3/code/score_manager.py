class ScoreManager:
    def __init__(self):
        self.high_scores = []

    def load_scores(self) -> None:
        try:
            with open('high_scores.txt', 'r') as file:
                for line in file:
                    name, score = line.strip().split('|')
                    self.high_scores.append((name, int(score)))
        except FileNotFoundError:
            self.high_scores = []

    def save_score(self, player_name: str, score: int) -> None:
        self.high_scores.append((player_name, score))
        self.high_scores = sorted(self.high_scores, key=lambda x: x[1], reverse=True)[:10]
        
        with open('high_scores.txt', 'w') as file:
            for name, score in self.high_scores:
                file.write(f"{name}|{score}\n")

    def get_high_scores(self) -> list[tuple[str, int]]:
        return self.high_scores