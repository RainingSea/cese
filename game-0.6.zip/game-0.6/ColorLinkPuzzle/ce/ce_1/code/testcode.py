import unittest
import pygame
from game import Game, Block, Grid, Score, Level

class TestColorLinkPuzzleGame(unittest.TestCase):

    def setUp(self):
        # Initialize the game and its components
        pygame.init()
        self.game = Game()
        self.grid = self.game.grid
        self.score = self.game.score
        self.level = self.game.level

    def test_connect_adjacent_blocks_same_color(self):
        # Functionalities 1: Connect Adjacent Blocks of the Same Color
        block1 = self.grid.blocks[0]
        block2 = self.grid.blocks[1]
        block1.color = block2.color  # Ensure they are the same color
        connected = self.game.connect_blocks((0, 0), (1, 0))
        self.assertTrue(connected, "Blocks should be connected if they are adjacent and of the same color")

    def test_clear_connected_blocks_from_grid(self):
        # Functionalities 2: Clear Connected Blocks from the Grid
        block1 = self.grid.blocks[0]
        block2 = self.grid.blocks[1]
        block1.color = block2.color  # Ensure they are the same color
        self.game.connect_blocks((0, 0), (1, 0))
        self.assertFalse(block1.is_connected(), "Block should be cleared from the grid")
        self.assertFalse(block2.is_connected(), "Block should be cleared from the grid")

    def test_validate_connection_unobstructed_path(self):
        # Functionalities 3: Validate Connection Based on Unobstructed Path
        block1 = self.grid.blocks[0]
        block2 = self.grid.blocks[2]
        block1.color = block2.color  # Ensure they are the same color
        connected = self.game.connect_blocks((0, 0), (2, 0))
        self.assertFalse(connected, "Connection should fail if path is obstructed")

    def test_track_player_score(self):
        # Functionalities 4: Track Player's Score
        initial_score = self.score.get_score()
        block1 = self.grid.blocks[0]
        block2 = self.grid.blocks[1]
        block1.color = block2.color  # Ensure they are the same color
        self.game.connect_blocks((0, 0), (1, 0))
        self.assertGreater(self.score.get_score(), initial_score, "Score should increase after clearing blocks")

    def test_provide_visual_feedback_successful_connections(self):
        # Functionalities 5: Provide Visual Feedback on Successful Connections
        # This functionality is not implemented in the codebase
        self.fail("Visual feedback for successful connections is not implemented in the codebase")

    def test_start_new_game(self):
        # Functionalities 6: Start a New Game
        self.game.level.next_level()  # Progress to next level
        self.game.score.add_points(50)  # Increase score
        self.game = Game()  # Start a new game
        self.assertEqual(self.level.difficulty, 1, "Game should reset to level 1")
        self.assertEqual(self.score.get_score(), 0, "Score should reset to 0")

    def test_view_high_scores(self):
        # Functionalities 7: View High Scores
        high_scores = self.game.get_high_scores()
        self.assertEqual(high_scores, ["Alice|150", "Bob|120", "Charlie|90"], "High scores should be displayed correctly")

    def test_increase_difficulty_across_levels(self):
        # Functionalities 8: Increase Difficulty Across Levels
        initial_difficulty = self.level.difficulty
        self.level.next_level()
        self.assertGreater(self.level.difficulty, initial_difficulty, "Difficulty should increase when progressing to the next level")

    def test_use_bonuses_and_power_ups(self):
        # Functionalities 9: Use Bonuses and Power-Ups
        # This functionality is not implemented in the codebase
        self.fail("Bonuses and power-ups functionality is not implemented in the codebase")

    def tearDown(self):
        pygame.quit()

if __name__ == '__main__':
    unittest.main()
