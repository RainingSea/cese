import pygame
import random

class Block:
    def __init__(self, color: str, position: tuple):
        self.color = color
        self.position = position
        self.connected = False

    def draw(self, surface):
        pygame.draw.rect(surface, self.color, (*self.position, 50, 50))

    def is_connected(self) -> bool:
        return self.connected

class Grid:
    def __init__(self):
        self.blocks = self.create_blocks()

    def create_blocks(self):
        colors = ["red", "green", "blue", "yellow", "purple"]
        return [Block(random.choice(colors), (x * 50, y * 50)) for x in range(6) for y in range(6)]

    def draw(self, surface):
        for block in self.blocks:
            block.draw(surface)

    def update(self):
        pass

    def check_path(self, start: tuple, end: tuple) -> bool:
        return True  # Placeholder for path-checking logic

class Score:
    def __init__(self):
        self.points = 0

    def add_points(self, points: int) -> None:
        self.points += points

    def get_score(self) -> int:
        return self.points

class Level:
    def __init__(self):
        self.difficulty = 1

    def next_level(self) -> None:
        self.difficulty += 1

    def reset(self) -> None:
        self.difficulty = 1

class Game:
    def __init__(self):
        self.grid = Grid()
        self.score = Score()
        self.level = Level()
        self.screen = pygame.display.set_mode((300, 300))
        pygame.display.set_caption("Color Link Puzzle")
        self.running = True

    def start(self) -> None:
        while self.running:
            self.handle_events()
            self.update()
            self.draw()
            pygame.display.flip()

    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False

    def update(self):
        self.grid.update()

    def draw(self):
        self.screen.fill((255, 255, 255))
        self.grid.draw(self.screen)

    def connect_blocks(self, start: tuple, end: tuple) -> bool:
        if self.grid.check_path(start, end):
            self.grid.blocks[start[1] * 6 + start[0]].connected = True
            self.grid.blocks[end[1] * 6 + end[0]].connected = True
            self.clear_blocks([start, end])
            return True
        return False

    def clear_blocks(self, blocks: list) -> None:
        for block in blocks:
            self.grid.blocks[block[1] * 6 + block[0]].connected = False

    def get_high_scores(self) -> list:
        with open("highscores.txt", "r") as file:
            return [line.strip() for line in file.readlines()]