import pygame
from game import Game

def main() -> None:
    pygame.init()
    game = Game(grid_size=5)  # Example grid size
    game.start_game()

if __name__ == "__main__":
    main()