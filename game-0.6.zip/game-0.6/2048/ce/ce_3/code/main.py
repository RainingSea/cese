import pygame
from game import Game

# Constants
WINDOW_SIZE = 400
GRID_SIZE = 4
TILE_SIZE = WINDOW_SIZE // GRID_SIZE
BACKGROUND_COLOR = (187, 173, 160)
TILE_COLOR = (255, 255, 255)
FONT_COLOR = (0, 0, 0)

pygame.init()
screen = pygame.display.set_mode((WINDOW_SIZE, WINDOW_SIZE))
pygame.display.set_caption("2048 Game")
font = pygame.font.Font(None, 36)

def draw_board(game: Game) -> None:
    screen.fill(BACKGROUND_COLOR)
    for i in range(GRID_SIZE):
        for j in range(GRID_SIZE):
            tile_value = game._board[i][j]
            if tile_value != 0:
                pygame.draw.rect(screen, TILE_COLOR, (j * TILE_SIZE, i * TILE_SIZE, TILE_SIZE, TILE_SIZE))
                text_surface = font.render(str(tile_value.get_value()), True, FONT_COLOR)
                text_rect = text_surface.get_rect(center=(j * TILE_SIZE + TILE_SIZE // 2, i * TILE_SIZE + TILE_SIZE // 2))
                screen.blit(text_surface, text_rect)
    pygame.display.flip()

def main() -> None:
    game = Game()
    clock = pygame.time.Clock()

    while True:
        draw_board(game)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                game.save_game_state('game_state.txt')
                pygame.quit()
                return
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    game.move('up')
                elif event.key == pygame.K_DOWN:
                    game.move('down')
                elif event.key == pygame.K_LEFT:
                    game.move('left')
                elif event.key == pygame.K_RIGHT:
                    game.move('right')
                game.check_game_over()

        clock.tick(30)

if __name__ == "__main__":
    main()