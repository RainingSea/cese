import random
import json

class Tile:
    def __init__(self, value: int):
        self._value = value

    def get_value(self) -> int:
        return self._value


class Game:
    def __init__(self):
        self._board = [[0] * 4 for _ in range(4)]
        self._score = 0
        self._game_over = False
        self.generate_new_tile()
        self.generate_new_tile()

    def start_game(self) -> None:
        self._board = [[0] * 4 for _ in range(4)]
        self._score = 0
        self._game_over = False
        self.generate_new_tile()
        self.generate_new_tile()

    def move(self, direction: str) -> None:
        # Implement the movement logic here
        # This is a placeholder for the actual implementation
        # You would need to implement merging and moving tiles
        pass

    def generate_new_tile(self) -> None:
        empty_tiles = [(i, j) for i in range(4) for j in range(4) if self._board[i][j] == 0]
        if empty_tiles:
            i, j = random.choice(empty_tiles)
            self._board[i][j] = Tile(2 if random.random() < 0.9 else 4)

    def check_game_over(self) -> bool:
        if any(0 in row for row in self._board):
            return False
        for i in range(4):
            for j in range(4):
                if (i < 3 and self._board[i][j] == self._board[i + 1][j]) or (j < 3 and self._board[i][j] == self._board[i][j + 1]):
                    return False
        self._game_over = True
        return True

    def save_game_state(self, file_path: str) -> None:
        game_state = {
            'board': [[tile.get_value() for tile in row] for row in self._board],
            'score': self._score
        }
        with open(file_path, 'w') as f:
            json.dump(game_state, f)

    def load_game_state(self, file_path: str) -> None:
        with open(file_path, 'r') as f:
            game_state = json.load(f)
            self._board = [[Tile(value) if value != 0 else 0 for value in row] for row in game_state['board']]
            self._score = game_state['score']