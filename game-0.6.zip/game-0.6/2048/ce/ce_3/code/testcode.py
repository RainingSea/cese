import unittest
import os
import json
from game import Game, Tile

class Test2048Game(unittest.TestCase):

    def setUp(self):
        # Initialize the game
        self.game = Game()

    def test_initialize_game_board(self):
        # Functionalities 1: Initialize Game Board
        self.game.start_game()
        non_empty_tiles = sum(tile != 0 for row in self.game._board for tile in row)
        self.assertEqual(non_empty_tiles, 2, "Game board should start with exactly two tiles")

    def test_move_tiles_up(self):
        # Functionalities 2: Move Tiles Up
        self.game._board = [
            [Tile(2), Tile(2), 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0]
        ]
        self.game.move('up')
        self.assertEqual(self.game._board[0][0].get_value(), 4, "Tiles should combine to form 4")
        self.assertEqual(self.game._board[0][1], 0, "The second tile should be empty after combining")

    def test_move_tiles_down(self):
        # Functionalities 3: Move Tiles Down
        self.game._board = [
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [Tile(2), Tile(2), 0, 0],
            [0, 0, 0, 0]
        ]
        self.game.move('down')
        self.assertEqual(self.game._board[3][0].get_value(), 4, "Tiles should combine to form 4")
        self.assertEqual(self.game._board[3][1], 0, "The second tile should be empty after combining")

    def test_move_tiles_left(self):
        # Functionalities 4: Move Tiles Left
        self.game._board = [
            [0, Tile(2), Tile(2), 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0]
        ]
        self.game.move('left')
        self.assertEqual(self.game._board[0][0].get_value(), 4, "Tiles should combine to form 4")
        self.assertEqual(self.game._board[0][1], 0, "The second tile should be empty after combining")

    def test_move_tiles_right(self):
        # Functionalities 5: Move Tiles Right
        self.game._board = [
            [0, 0, Tile(2), Tile(2)],
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0]
        ]
        self.game.move('right')
        self.assertEqual(self.game._board[0][3].get_value(), 4, "Tiles should combine to form 4")
        self.assertEqual(self.game._board[0][2], 0, "The second tile should be empty after combining")

    def test_generate_new_tile(self):
        # Functionalities 6: Generate New Tile
        self.game._board = [
            [Tile(2), Tile(2), Tile(4), Tile(4)],
            [Tile(2), Tile(2), Tile(4), Tile(4)],
            [Tile(2), Tile(2), Tile(4), Tile(4)],
            [0, 0, 0, 0]
        ]
        self.game.generate_new_tile()
        non_empty_tiles = sum(tile != 0 for row in self.game._board for tile in row)
        self.assertEqual(non_empty_tiles, 13, "A new tile should be generated")

    def test_check_game_over_condition(self):
        # Functionalities 7: Check Game Over Condition
        self.game._board = [
            [Tile(2), Tile(4), Tile(2), Tile(4)],
            [Tile(4), Tile(2), Tile(4), Tile(2)],
            [Tile(2), Tile(4), Tile(2), Tile(4)],
            [Tile(4), Tile(2), Tile(4), Tile(2)]
        ]
        self.assertTrue(self.game.check_game_over(), "Game should be over when no moves are possible")

    def test_save_game_state(self):
        # Functionalities 8: Save Game State
        file_path = 'test_game_state.txt'
        self.game.save_game_state(file_path)
        self.assertTrue(os.path.exists(file_path), "Game state file should be created")
        os.remove(file_path)

    def test_load_game_state(self):
        # Functionalities 9: Load Game State
        file_path = 'test_game_state.txt'
        game_state = {
            'board': [
                [2, 2, 4, 4],
                [2, 2, 4, 4],
                [2, 2, 4, 4],
                [0, 0, 0, 0]
            ],
            'score': 16
        }
        with open(file_path, 'w') as f:
            json.dump(game_state, f)
        self.game.load_game_state(file_path)
        self.assertEqual(self.game._board[0][0].get_value(), 2, "Game state should be loaded correctly")
        os.remove(file_path)

if __name__ == '__main__':
    unittest.main()
