[OUTPUT]
## general overview of the project
Design a simple 2048 game.

## software functional requirements
1. The game board shall be divided into a 4x4 grid.
2. The game shall allow players to control the game using the arrow keys on the keyboard (up, down, left, right).
3. The game shall automatically generate two random tiles ("2" or "4") on the board at the start of the game.
4. The game shall allow tiles to move in the direction pressed (up, down, left, or right) and combine according to the game rules.
5. After each valid move, a new tile ("2" or "4") shall be generated in an empty cell on the board.
6. The game shall detect and display a "Game Over" message when no more moves are possible.
7. The game shall save the current game state (board layout and score) to a local text file.
8. The game shall load a saved game state from a local text file to continue gameplay.
9. The game shall keep track of the player's score during the game.
[/OUTPUT]