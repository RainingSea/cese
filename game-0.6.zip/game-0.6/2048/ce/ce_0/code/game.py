import json
import random

class Tile:
    def __init__(self, value: int):
        self._value = value

    def get_value(self) -> int:
        return self._value

class Game:
    def __init__(self):
        self._board = [[0] * 4 for _ in range(4)]
        self._score = 0
        self.start_game()

    def start_game(self) -> None:
        self._board = [[0] * 4 for _ in range(4)]
        self._score = 0
        self.generate_new_tile()
        self.generate_new_tile()

    def move(self, direction: str) -> bool:
        if direction in ['up', 'down', 'left', 'right']:
            moved = False
            # Implement movement logic here
            # This is a placeholder for the movement logic
            # Actual implementation will involve merging tiles and updating the score
            return moved
        return False

    def generate_new_tile(self) -> None:
        empty_tiles = [(r, c) for r in range(4) for c in range(4) if self._board[r][c] == 0]
        if empty_tiles:
            r, c = random.choice(empty_tiles)
            self._board[r][c] = 2 if random.random() < 0.9 else 4

    def check_game_over(self) -> bool:
        for row in self._board:
            if 0 in row:
                return False
        for r in range(4):
            for c in range(4):
                if (r < 3 and self._board[r][c] == self._board[r + 1][c]) or (c < 3 and self._board[r][c] == self._board[r][c + 1]):
                    return False
        return True

    def save_game_state(self, filename: str) -> None:
        game_state = {
            'board': self._board,
            'score': self._score
        }
        with open(filename, 'w') as f:
            json.dump(game_state, f)

    def load_game_state(self, filename: str) -> None:
        with open(filename, 'r') as f:
            game_state = json.load(f)
            self._board = game_state['board']
            self._score = game_state['score']