import unittest
import os
import json
from game import Game

class Test2048Game(unittest.TestCase):

    def setUp(self):
        # Initialize the game
        self.game = Game()

    def test_initialize_game_board(self):
        # Functionalities 1: Initialize Game Board
        self.game.start_game()
        non_zero_tiles = sum(tile != 0 for row in self.game._board for tile in row)
        self.assertEqual(non_zero_tiles, 2, "The game board should start with exactly two tiles.")

    def test_move_tiles_up(self):
        # Functionalities 2: Move Tiles Up
        initial_board = [
            [2, 0, 0, 0],
            [2, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0]
        ]
        self.game._board = initial_board
        self.game.move('up')
        expected_board = [
            [4, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0]
        ]
        self.assertEqual(self.game._board, expected_board, "Tiles should combine and move up correctly.")

    def test_move_tiles_down(self):
        # Functionalities 3: Move Tiles Down
        initial_board = [
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [2, 0, 0, 0],
            [2, 0, 0, 0]
        ]
        self.game._board = initial_board
        self.game.move('down')
        expected_board = [
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [4, 0, 0, 0]
        ]
        self.assertEqual(self.game._board, expected_board, "Tiles should combine and move down correctly.")

    def test_move_tiles_left(self):
        # Functionalities 4: Move Tiles Left
        initial_board = [
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 2, 2, 0],
            [0, 0, 0, 0]
        ]
        self.game._board = initial_board
        self.game.move('left')
        expected_board = [
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [4, 0, 0, 0],
            [0, 0, 0, 0]
        ]
        self.assertEqual(self.game._board, expected_board, "Tiles should combine and move left correctly.")

    def test_move_tiles_right(self):
        # Functionalities 5: Move Tiles Right
        initial_board = [
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 2, 2, 0],
            [0, 0, 0, 0]
        ]
        self.game._board = initial_board
        self.game.move('right')
        expected_board = [
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 4],
            [0, 0, 0, 0]
        ]
        self.assertEqual(self.game._board, expected_board, "Tiles should combine and move right correctly.")

    def test_generate_new_tile(self):
        # Functionalities 6: Generate New Tile
        self.game._board = [
            [2, 2, 4, 8],
            [16, 32, 64, 128],
            [256, 512, 1024, 2048],
            [0, 0, 0, 0]
        ]
        self.game.generate_new_tile()
        non_zero_tiles = sum(tile != 0 for row in self.game._board for tile in row)
        self.assertEqual(non_zero_tiles, 13, "A new tile should be generated on the board.")

    def test_check_game_over_condition(self):
        # Functionalities 7: Check Game Over Condition
        self.game._board = [
            [2, 4, 2, 4],
            [4, 2, 4, 2],
            [2, 4, 2, 4],
            [4, 2, 4, 2]
        ]
        self.assertTrue(self.game.check_game_over(), "Game should be over when no moves are possible.")

    def test_save_game_state(self):
        # Functionalities 8: Save Game State
        filename = 'test_game_state.json'
        self.game.save_game_state(filename)
        self.assertTrue(os.path.exists(filename), "Game state file should be created.")
        os.remove(filename)

    def test_load_game_state(self):
        # Functionalities 9: Load Game State
        filename = 'test_game_state.json'
        game_state = {
            'board': [
                [2, 2, 0, 0],
                [4, 4, 0, 0],
                [0, 0, 2, 2],
                [0, 0, 0, 0]
            ],
            'score': 8
        }
        with open(filename, 'w') as f:
            json.dump(game_state, f)
        self.game.load_game_state(filename)
        self.assertEqual(self.game._board, game_state['board'], "Game board should be loaded correctly.")
        os.remove(filename)

if __name__ == '__main__':
    unittest.main()
