import unittest
import json
from game import Game

class TestGame2048(unittest.TestCase):

    def setUp(self):
        # Initialize the game
        self.game = Game()

    def test_initialize_game_board(self):
        # Functionalities 1: Initialize Game Board
        self.game.start_game()
        non_zero_tiles = sum(tile != 0 for row in self.game.board for tile in row)
        self.assertEqual(non_zero_tiles, 2, "The game board should have exactly two non-zero tiles at the start.")

    def test_move_tiles_up(self):
        # Functionalities 2: Move Tiles Up
        self.game.board = [
            [2, 0, 0, 0],
            [2, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0]
        ]
        self.game.move('up')
        self.assertEqual(self.game.board[0][0], 4, "Tiles should combine when moved up.")
        self.assertEqual(self.game.board[1][0], 0, "The second row should be empty after combining.")

    def test_move_tiles_down(self):
        # Functionalities 3: Move Tiles Down
        self.game.board = [
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [2, 0, 0, 0],
            [2, 0, 0, 0]
        ]
        self.game.move('down')
        self.assertEqual(self.game.board[3][0], 4, "Tiles should combine when moved down.")
        self.assertEqual(self.game.board[2][0], 0, "The third row should be empty after combining.")

    def test_move_tiles_left(self):
        # Functionalities 4: Move Tiles Left
        self.game.board = [
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [2, 2, 0, 0]
        ]
        self.game.move('left')
        self.assertEqual(self.game.board[3][0], 4, "Tiles should combine when moved left.")
        self.assertEqual(self.game.board[3][1], 0, "The second column should be empty after combining.")

    def test_move_tiles_right(self):
        # Functionalities 5: Move Tiles Right
        self.game.board = [
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 2, 2]
        ]
        self.game.move('right')
        self.assertEqual(self.game.board[3][3], 4, "Tiles should combine when moved right.")
        self.assertEqual(self.game.board[3][2], 0, "The third column should be empty after combining.")

    def test_generate_new_tile(self):
        # Functionalities 6: Generate New Tile
        self.game.board = [
            [2, 4, 8, 16],
            [32, 64, 128, 256],
            [512, 1024, 2048, 0],
            [0, 0, 0, 0]
        ]
        self.game.generate_new_tile()
        non_zero_tiles = sum(tile != 0 for row in self.game.board for tile in row)
        self.assertEqual(non_zero_tiles, 14, "A new tile should be generated after a move.")

    def test_check_game_over_condition(self):
        # Functionalities 7: Check Game Over Condition
        self.game.board = [
            [2, 4, 8, 16],
            [32, 64, 128, 256],
            [512, 1024, 2048, 4096],
            [8192, 16384, 32768, 65536]
        ]
        self.assertTrue(self.game.check_game_over(), "The game should be over when no moves are possible.")

    def test_save_game_state(self):
        # Functionalities 8: Save Game State
        self.game.board = [
            [2, 4, 8, 16],
            [32, 64, 128, 256],
            [512, 1024, 2048, 4096],
            [8192, 16384, 32768, 65536]
        ]
        self.game.score = 123456
        self.game.save_game_state()
        with open('game_state.json', 'r') as f:
            game_state = json.load(f)
        self.assertEqual(game_state['board'], self.game.board, "The saved board state should match the current board.")
        self.assertEqual(game_state['score'], self.game.score, "The saved score should match the current score.")

    def test_load_game_state(self):
        # Functionalities 9: Load Game State
        self.game.board = [[0] * 4 for _ in range(4)]
        self.game.score = 0
        self.game.load_game_state()
        with open('game_state.json', 'r') as f:
            game_state = json.load(f)
        self.assertEqual(self.game.board, game_state['board'], "The loaded board state should match the saved board.")
        self.assertEqual(self.game.score, game_state['score'], "The loaded score should match the saved score.")

if __name__ == '__main__':
    unittest.main()
