import json
import random

class Game:
    def __init__(self):
        self.board = [[0] * 4 for _ in range(4)]
        self.score = 0
        self.game_over = False
        self.generate_new_tile()
        self.generate_new_tile()

    def start_game(self) -> None:
        self.board = [[0] * 4 for _ in range(4)]
        self.score = 0
        self.game_over = False
        self.generate_new_tile()
        self.generate_new_tile()

    def move(self, direction: str) -> None:
        if direction == 'up':
            self._move_up()
        elif direction == 'down':
            self._move_down()
        elif direction == 'left':
            self._move_left()
        elif direction == 'right':
            self._move_right()
        self.generate_new_tile()
        self.check_game_over()

    def generate_new_tile(self) -> None:
        empty_cells = [(i, j) for i in range(4) for j in range(4) if self.board[i][j] == 0]
        if empty_cells:
            i, j = random.choice(empty_cells)
            self.board[i][j] = 2 if random.random() < 0.9 else 4

    def check_game_over(self) -> bool:
        if any(0 in row for row in self.board):
            return False
        for i in range(4):
            for j in range(4):
                if (i < 3 and self.board[i][j] == self.board[i + 1][j]) or (j < 3 and self.board[i][j] == self.board[i][j + 1]):
                    return False
        self.game_over = True
        return True

    def save_game_state(self) -> None:
        game_state = {
            'board': self.board,
            'score': self.score
        }
        with open('game_state.json', 'w') as f:
            json.dump(game_state, f)

    def load_game_state(self) -> None:
        try:
            with open('game_state.json', 'r') as f:
                game_state = json.load(f)
                self.board = game_state['board']
                self.score = game_state['score']
        except FileNotFoundError:
            pass

    def display_board(self) -> None:
        for row in self.board:
            print("\t".join(str(x) if x != 0 else '.' for x in row))
        print(f"Score: {self.score}")