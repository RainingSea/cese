import pygame
from game import Game

# Constants
WINDOW_SIZE = 400
GRID_SIZE = 4
TILE_SIZE = WINDOW_SIZE // GRID_SIZE
BACKGROUND_COLOR = (187, 173, 160)
GRID_COLOR = (204, 192, 178)
FONT_COLOR = (255, 255, 255)

class Game2048:
    def __init__(self):
        pygame.init()
        self.window = pygame.display.set_mode((WINDOW_SIZE, WINDOW_SIZE))
        pygame.display.set_caption("2048")
        self.clock = pygame.time.Clock()
        self.game = Game()
        self.game.load_game_state()

    def run(self):
        while not self.game.game_over:
            self.handle_events()
            self.draw()
            self.clock.tick(30)

        self.show_game_over()

    def handle_events(self) -> None:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.game.save_game_state()
                pygame.quit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    self.game.move('up')
                elif event.key == pygame.K_DOWN:
                    self.game.move('down')
                elif event.key == pygame.K_LEFT:
                    self.game.move('left')
                elif event.key == pygame.K_RIGHT:
                    self.game.move('right')

    def draw(self) -> None:
        self.window.fill(BACKGROUND_COLOR)
        for i in range(GRID_SIZE):
            for j in range(GRID_SIZE):
                tile_value = self.game.board[i][j]
                self.draw_tile(i, j, tile_value)
        pygame.display.flip()

    def draw_tile(self, i: int, j: int, value: int) -> None:
        color = self.get_tile_color(value)
        pygame.draw.rect(self.window, color, (j * TILE_SIZE, i * TILE_SIZE, TILE_SIZE, TILE_SIZE))
        if value != 0:
            font = pygame.font.Font(None, 55)
            text = font.render(str(value), True, FONT_COLOR)
            text_rect = text.get_rect(center=(j * TILE_SIZE + TILE_SIZE // 2, i * TILE_SIZE + TILE_SIZE // 2))
            self.window.blit(text, text_rect)

    def get_tile_color(self, value: int) -> tuple:
        colors = {
            2: (238, 228, 218),
            4: (237, 224, 200),
            8: (242, 177, 121),
            16: (245, 149, 99),
            32: (246, 124, 95),
            64: (246, 94, 59),
            128: (237, 207, 114),
            256: (237, 204, 97),
            512: (237, 200, 80),
            1024: (237, 197, 63),
            2048: (237, 194, 46)
        }
        return colors.get(value, (60, 58, 50))

    def show_game_over(self) -> None:
        font = pygame.font.Font(None, 75)
        text = font.render("Game Over!", True, FONT_COLOR)
        text_rect = text.get_rect(center=(WINDOW_SIZE // 2, WINDOW_SIZE // 2))
        self.window.blit(text, text_rect)
        pygame.display.flip()
        pygame.time.wait(3000)
        self.game.save_game_state()
        pygame.quit()

if __name__ == "__main__":
    game = Game2048()
    game.run()