import unittest
import os
import json
from game import Game

class Test2048Game(unittest.TestCase):

    def setUp(self):
        # Initialize the game
        self.game = Game()

    def test_initialize_game_board(self):
        # Functionalities 1: Initialize Game Board
        self.game.start_game()
        non_empty_tiles = sum(tile != 0 for row in self.game._board for tile in row)
        self.assertEqual(non_empty_tiles, 2, "The game board should have exactly two non-empty tiles at the start.")

    def test_move_tiles_up(self):
        # Functionalities 2: Move Tiles Up
        self.game._board = [
            [2, 0, 0, 2],
            [2, 0, 0, 2],
            [0, 0, 0, 0],
            [0, 0, 0, 0]
        ]
        self.game.move("up")
        expected_board = [
            [4, 0, 0, 4],
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0]
        ]
        self.assertEqual(self.game._board, expected_board, "Tiles should combine and move up correctly.")

    def test_move_tiles_down(self):
        # Functionalities 3: Move Tiles Down
        self.game._board = [
            [2, 0, 0, 2],
            [2, 0, 0, 2],
            [0, 0, 0, 0],
            [0, 0, 0, 0]
        ]
        self.game.move("down")
        expected_board = [
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [4, 0, 0, 4]
        ]
        self.assertEqual(self.game._board, expected_board, "Tiles should combine and move down correctly.")

    def test_move_tiles_left(self):
        # Functionalities 4: Move Tiles Left
        self.game._board = [
            [2, 2, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [2, 2, 0, 0]
        ]
        self.game.move("left")
        expected_board = [
            [4, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [4, 0, 0, 0]
        ]
        self.assertEqual(self.game._board, expected_board, "Tiles should combine and move left correctly.")

    def test_move_tiles_right(self):
        # Functionalities 5: Move Tiles Right
        self.game._board = [
            [0, 0, 2, 2],
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 2, 2]
        ]
        self.game.move("right")
        expected_board = [
            [0, 0, 0, 4],
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 4]
        ]
        self.assertEqual(self.game._board, expected_board, "Tiles should combine and move right correctly.")

    def test_generate_new_tile(self):
        # Functionalities 6: Generate New Tile
        self.game._board = [
            [2, 2, 2, 2],
            [2, 2, 2, 2],
            [2, 2, 2, 2],
            [2, 2, 2, 0]
        ]
        self.game.generate_new_tile()
        non_empty_tiles = sum(tile != 0 for row in self.game._board for tile in row)
        self.assertEqual(non_empty_tiles, 16, "A new tile should be generated in an empty space.")

    def test_check_game_over_condition(self):
        # Functionalities 7: Check Game Over Condition
        self.game._board = [
            [2, 4, 2, 4],
            [4, 2, 4, 2],
            [2, 4, 2, 4],
            [4, 2, 4, 2]
        ]
        self.assertTrue(self.game.check_game_over(), "The game should be over when no moves are possible.")

    def test_save_game_state(self):
        # Functionalities 8: Save Game State
        self.game._board = [
            [2, 2, 2, 2],
            [2, 2, 2, 2],
            [2, 2, 2, 2],
            [2, 2, 2, 2]
        ]
        self.game._score = 100
        self.game.save_game_state()
        with open('game_state.json', 'r') as f:
            game_state = json.load(f)
        self.assertEqual(game_state["board"], self.game._board, "The board state should be saved correctly.")
        self.assertEqual(game_state["score"], self.game._score, "The score should be saved correctly.")

    def test_load_game_state(self):
        # Functionalities 9: Load Game State
        saved_state = {
            "board": [
                [2, 2, 2, 2],
                [2, 2, 2, 2],
                [2, 2, 2, 2],
                [2, 2, 2, 2]
            ],
            "score": 100
        }
        with open('game_state.json', 'w') as f:
            json.dump(saved_state, f)
        self.game.load_game_state()
        self.assertEqual(self.game._board, saved_state["board"], "The board state should be loaded correctly.")
        self.assertEqual(self.game._score, saved_state["score"], "The score should be loaded correctly.")

if __name__ == '__main__':
    unittest.main()
