import json
import random

class Tile:
    def __init__(self, value: int):
        self._value = value

    def get_value(self) -> int:
        return self._value

class Game:
    def __init__(self):
        self._board = [[0] * 4 for _ in range(4)]
        self._score = 0
        self.generate_new_tile()
        self.generate_new_tile()

    def start_game(self) -> None:
        self._board = [[0] * 4 for _ in range(4)]
        self._score = 0
        self.generate_new_tile()
        self.generate_new_tile()

    def move(self, direction: str) -> None:
        if direction == "up":
            self._move_up()
        elif direction == "down":
            self._move_down()
        elif direction == "left":
            self._move_left()
        elif direction == "right":
            self._move_right()
        self.generate_new_tile()
        if self.check_game_over():
            print("Game Over!")

    def generate_new_tile(self) -> None:
        empty_tiles = [(r, c) for r in range(4) for c in range(4) if self._board[r][c] == 0]
        if empty_tiles:
            r, c = random.choice(empty_tiles)
            self._board[r][c] = 2 if random.random() < 0.9 else 4

    def check_game_over(self) -> bool:
        if any(0 in row for row in self._board):
            return False
        for r in range(4):
            for c in range(4):
                if (r < 3 and self._board[r][c] == self._board[r + 1][c]) or (c < 3 and self._board[r][c] == self._board[r][c + 1]):
                    return False
        return True

    def save_game_state(self) -> None:
        game_state = {
            "board": self._board,
            "score": self._score
        }
        with open('game_state.json', 'w') as f:
            json.dump(game_state, f)

    def load_game_state(self) -> None:
        try:
            with open('game_state.json', 'r') as f:
                game_state = json.load(f)
                self._board = game_state["board"]
                self._score = game_state["score"]
        except FileNotFoundError:
            print("No saved game found.")
    
    # Placeholder methods for move handling
    def _move_up(self):
        # Implement the logic for moving tiles up
        pass

    def _move_down(self):
        # Implement the logic for moving tiles down
        pass

    def _move_left(self):
        # Implement the logic for moving tiles left
        pass

    def _move_right(self):
        # Implement the logic for moving tiles right
        pass