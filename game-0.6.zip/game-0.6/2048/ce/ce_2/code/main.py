import pygame
from game import Game

def main():
    pygame.init()
    screen = pygame.display.set_mode((400, 500))
    pygame.display.set_caption("2048 Game")
    clock = pygame.time.Clock()
    game = Game()
    running = True

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    game.move("up")
                elif event.key == pygame.K_DOWN:
                    game.move("down")
                elif event.key == pygame.K_LEFT:
                    game.move("left")
                elif event.key == pygame.K_RIGHT:
                    game.move("right")
        
        screen.fill((187, 173, 160))
        draw_board(screen, game)
        pygame.display.flip()
        clock.tick(30)

    pygame.quit()

def draw_board(screen, game):
    for r in range(4):
        for c in range(4):
            tile_value = game._board[r][c]
            if tile_value > 0:
                pygame.draw.rect(screen, get_color(tile_value), (c * 100, r * 100, 100, 100))
                font = pygame.font.Font(None, 55)
                text = font.render(str(tile_value), True, (255, 255, 255))
                screen.blit(text, (c * 100 + 25, r * 100 + 25))

def get_color(value):
    colors = {
        0: (205, 193, 180),
        2: (238, 228, 218),
        4: (237, 224, 200),
        8: (242, 177, 121),
        16: (245, 149, 99),
        32: (246, 124, 95),
        64: (246, 94, 59),
        128: (237, 207, 114),
        256: (237, 204, 97),
        512: (237, 200, 80),
        1024: (237, 197, 63),
        2048: (237, 194, 46),
    }
    return colors.get(value, (0, 0, 0))

if __name__ == "__main__":
    main()