import unittest
import os
from game import Game

class Test2048Game(unittest.TestCase):

    def setUp(self):
        # Initialize the game
        self.game = Game()

    def test_initialize_game_board(self):
        # Functionalities 1: Initialize Game Board
        self.game.initialize_board()
        non_zero_tiles = sum(tile != 0 for row in self.game.board for tile in row)
        self.assertEqual(non_zero_tiles, 2, "There should be exactly two non-zero tiles on the board after initialization.")

    def test_move_tiles_up(self):
        # Functionalities 2: Move Tiles Up
        self.game.board = [
            [2, 0, 0, 2],
            [2, 0, 0, 2],
            [0, 0, 0, 0],
            [0, 0, 0, 0]
        ]
        self.game.move('up')
        expected_board = [
            [4, 0, 0, 4],
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0]
        ]
        self.assertEqual(self.game.board, expected_board, "Tiles should combine and move up correctly.")

    def test_move_tiles_down(self):
        # Functionalities 3: Move Tiles Down
        self.game.board = [
            [2, 0, 0, 2],
            [2, 0, 0, 2],
            [0, 0, 0, 0],
            [0, 0, 0, 0]
        ]
        self.game.move('down')
        expected_board = [
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [4, 0, 0, 4]
        ]
        self.assertEqual(self.game.board, expected_board, "Tiles should combine and move down correctly.")

    def test_move_tiles_left(self):
        # Functionalities 4: Move Tiles Left
        self.game.board = [
            [2, 0, 0, 2],
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [2, 0, 0, 2]
        ]
        self.game.move('left')
        expected_board = [
            [4, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [4, 0, 0, 0]
        ]
        self.assertEqual(self.game.board, expected_board, "Tiles should combine and move left correctly.")

    def test_move_tiles_right(self):
        # Functionalities 5: Move Tiles Right
        self.game.board = [
            [2, 0, 0, 2],
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [2, 0, 0, 2]
        ]
        self.game.move('right')
        expected_board = [
            [0, 0, 0, 4],
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 4]
        ]
        self.assertEqual(self.game.board, expected_board, "Tiles should combine and move right correctly.")

    def test_generate_new_tile(self):
        # Functionalities 6: Generate New Tile
        self.game.board = [
            [2, 4, 2, 4],
            [4, 2, 4, 2],
            [2, 4, 2, 4],
            [0, 0, 0, 0]
        ]
        self.game.generate_tile()
        non_zero_tiles = sum(tile != 0 for row in self.game.board for tile in row)
        self.assertEqual(non_zero_tiles, 13, "A new tile should be generated on the board.")

    def test_check_game_over_condition(self):
        # Functionalities 7: Check Game Over Condition
        self.game.board = [
            [2, 4, 2, 4],
            [4, 2, 4, 2],
            [2, 4, 2, 4],
            [4, 2, 4, 2]
        ]
        self.assertTrue(self.game.check_game_over(), "Game should be over when no moves are possible.")

    def test_save_game_state(self):
        # Functionalities 8: Save Game State
        file_path = 'test_game_state.txt'
        self.game.save_game_state(file_path)
        self.assertTrue(os.path.exists(file_path), "Game state file should be created.")
        os.remove(file_path)

    def test_load_game_state(self):
        # Functionalities 9: Load Game State
        file_path = 'test_game_state.txt'
        self.game.board = [
            [2, 4, 2, 4],
            [4, 2, 4, 2],
            [2, 4, 2, 4],
            [4, 2, 4, 2]
        ]
        self.game.score = 100
        self.game.save_game_state(file_path)
        new_game = Game()
        new_game.load_game_state(file_path)
        self.assertEqual(new_game.board, self.game.board, "Loaded board should match saved board.")
        self.assertEqual(new_game.score, self.game.score, "Loaded score should match saved score.")
        os.remove(file_path)

if __name__ == '__main__':
    unittest.main()
