import random
import json

class Game:
    def __init__(self) -> None:
        self.board = []
        self.score = 0
        self.initialize_board()

    def initialize_board(self) -> None:
        self.board = [[0] * 4 for _ in range(4)]
        self.generate_tile()
        self.generate_tile()

    def generate_tile(self) -> None:
        empty_tiles = [(i, j) for i in range(4) for j in range(4) if self.board[i][j] == 0]
        if empty_tiles:
            i, j = random.choice(empty_tiles)
            self.board[i][j] = random.choice([2, 4])

    def move(self, direction: str) -> None:
        if direction == 'up':
            self.combine_tiles(vertical=True)
        elif direction == 'down':
            self.combine_tiles(vertical=True, reverse=True)
        elif direction == 'left':
            self.combine_tiles()
        elif direction == 'right':
            self.combine_tiles(reverse=True)

    def combine_tiles(self, vertical=False, reverse=False) -> None:
        if vertical:
            range_func = range(4)
            if reverse:
                range_func = reversed(range(4))
            for j in range(4):
                tiles = [self.board[i][j] for i in range_func]
                self._combine(tiles)
                for i in range(4):
                    self.board[i][j] = tiles[i]
        else:
            for i in range(4):
                tiles = self.board[i]
                if reverse:
                    tiles = reversed(tiles)
                self._combine(tiles)
                self.board[i] = list(tiles)

    def _combine(self, tiles) -> None:
        new_tiles = [tile for tile in tiles if tile != 0]
        combined = []
        skip = False
        for i in range(len(new_tiles)):
            if skip:
                skip = False
                continue
            if i + 1 < len(new_tiles) and new_tiles[i] == new_tiles[i + 1]:
                combined.append(new_tiles[i] * 2)
                self.score += new_tiles[i] * 2
                skip = True
            else:
                combined.append(new_tiles[i])
        combined.extend([0] * (4 - len(combined)))
        for i in range(len(combined)):
            tiles[i] = combined[i]

    def check_game_over(self) -> bool:
        return all(self.board[i][j] != 0 for i in range(4) for j in range(4)) and not self.can_move()

    def can_move(self) -> bool:
        for i in range(4):
            for j in range(4):
                if (j < 3 and self.board[i][j] == self.board[i][j + 1]) or (i < 3 and self.board[i][j] == self.board[i + 1][j]):
                    return True
        return False

    def save_game_state(self, file_path: str) -> None:
        with open(file_path, 'w') as file:
            json.dump({'board': self.board, 'score': self.score}, file)

    def load_game_state(self, file_path: str) -> None:
        with open(file_path, 'r') as file:
            data = json.load(file)
            self.board = data['board']
            self.score = data['score']

    def display_board(self) -> None:
        for row in self.board:
            print(' '.join(str(tile) for tile in row))
        print(f"Score: {self.score}")