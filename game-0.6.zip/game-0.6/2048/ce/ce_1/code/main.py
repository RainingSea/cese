import pygame
from game import Game

def main() -> None:
    pygame.init()
    screen = pygame.display.set_mode((400, 400))
    pygame.display.set_caption('2048 Game')
    game = Game()
    clock = pygame.time.Clock()
    running = True

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    game.move('up')
                elif event.key == pygame.K_DOWN:
                    game.move('down')
                elif event.key == pygame.K_LEFT:
                    game.move('left')
                elif event.key == pygame.K_RIGHT:
                    game.move('right')

        if game.check_game_over():
            print("Game Over!")
            running = False

        screen.fill((255, 255, 255))
        game.display_board()
        pygame.display.flip()
        clock.tick(60)

    game.save_game_state('game_state.txt')
    pygame.quit()

if __name__ == '__main__':
    main()