import pygame
from game import Game

# Constants
WINDOW_SIZE = 400
GRID_SIZE = 4
TILE_SIZE = WINDOW_SIZE // GRID_SIZE
BACKGROUND_COLOR = (187, 173, 160)
GRID_COLOR = (205, 193, 180)
FONT_COLOR = (255, 255, 255)

def draw_board(screen, game):
    """Draw the game board on the screen."""
    screen.fill(BACKGROUND_COLOR)
    for r in range(GRID_SIZE):
        for c in range(GRID_SIZE):
            tile_value = game._board[r][c]
            tile_color = (255, 255, 255) if tile_value == 0 else (0, 255, 0)
            pygame.draw.rect(screen, tile_color, (c * TILE_SIZE, r * TILE_SIZE, TILE_SIZE, TILE_SIZE))
            if tile_value != 0:
                font = pygame.font.SysFont('Arial', 40)
                text = font.render(str(tile_value), True, FONT_COLOR)
                text_rect = text.get_rect(center=(c * TILE_SIZE + TILE_SIZE // 2, r * TILE_SIZE + TILE_SIZE // 2))
                screen.blit(text, text_rect)

def main():
    """Main function to run the game."""
    pygame.init()
    screen = pygame.display.set_mode((WINDOW_SIZE, WINDOW_SIZE))
    pygame.display.set_caption('2048 Game')
    game = Game()
    
    # Load game state if exists
    try:
        game.load_game('game_state.json')
    except FileNotFoundError:
        pass

    while not game._game_over:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                game.save_game('game_state.json')
                pygame.quit()
                return
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    game.move('up')
                elif event.key == pygame.K_DOWN:
                    game.move('down')
                elif event.key == pygame.K_LEFT:
                    game.move('left')
                elif event.key == pygame.K_RIGHT:
                    game.move('right')

        draw_board(screen, game)
        pygame.display.flip()

    pygame.quit()

if __name__ == '__main__':
    main()