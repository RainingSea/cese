import random
import json

class Tile:
    def __init__(self, value: int):
        self._value = value

    def get_value(self) -> int:
        return self._value

class Game:
    def __init__(self):
        self._board = [[0] * 4 for _ in range(4)]
        self._score = 0
        self._game_over = False
        self.start_game()

    def start_game(self) -> None:
        """Reset the game board and generate two new tiles."""
        self._board = [[0] * 4 for _ in range(4)]
        self._score = 0
        self._game_over = False
        self.generate_tile()
        self.generate_tile()

    def move(self, direction: str) -> None:
        """Move tiles in the specified direction."""
        if direction == 'up':
            self._move_up()
        elif direction == 'down':
            self._move_down()
        elif direction == 'left':
            self._move_left()
        elif direction == 'right':
            self._move_right()
        self.generate_tile()
        self._game_over = self.check_game_over()

    def generate_tile(self) -> None:
        """Generate a new tile on the board."""
        empty_tiles = [(r, c) for r in range(4) for c in range(4) if self._board[r][c] == 0]
        if empty_tiles:
            r, c = random.choice(empty_tiles)
            self._board[r][c] = 2 if random.random() < 0.9 else 4

    def check_game_over(self) -> bool:
        """Check if the game is over."""
        for row in self._board:
            if 0 in row:
                return False
        for r in range(4):
            for c in range(4):
                if (r < 3 and self._board[r][c] == self._board[r + 1][c]) or (c < 3 and self._board[r][c] == self._board[r][c + 1]):
                    return False
        return True

    def save_game(self, filename: str) -> None:
        """Save the current game state to a file."""
        game_state = {
            'board': self._board,
            'score': self._score
        }
        with open(filename, 'w') as f:
            json.dump(game_state, f)

    def load_game(self, filename: str) -> None:
        """Load game state from a file."""
        with open(filename, 'r') as f:
            game_state = json.load(f)
            self._board = game_state['board']
            self._score = game_state['score']

    def _move_up(self) -> None:
        """Move tiles up."""
        for c in range(4):
            column = [self._board[r][c] for r in range(4)]
            self._merge(column)
            for r in range(4):
                self._board[r][c] = column[r]

    def _move_down(self) -> None:
        """Move tiles down."""
        for c in range(4):
            column = [self._board[r][c] for r in range(4)][::-1]
            self._merge(column)
            for r in range(4):
                self._board[r][c] = column[::-1][r]

    def _move_left(self) -> None:
        """Move tiles left."""
        for r in range(4):
            row = self._board[r]
            self._merge(row)
            self._board[r] = row

    def _move_right(self) -> None:
        """Move tiles right."""
        for r in range(4):
            row = self._board[r][::-1]
            self._merge(row)
            self._board[r] = row[::-1]

    def _merge(self, line: list) -> None:
        """Merge tiles in a line."""
        new_line = [i for i in line if i != 0]
        merged_line = []
        skip = False
        for i in range(len(new_line)):
            if skip:
                skip = False
                continue
            if i + 1 < len(new_line) and new_line[i] == new_line[i + 1]:
                merged_line.append(new_line[i] * 2)
                self._score += new_line[i] * 2
                skip = True
            else:
                merged_line.append(new_line[i])
        merged_line += [0] * (4 - len(merged_line))
        for i in range(len(line)):
            line[i] = merged_line[i]