import pygame
import json
from typing import List, Tuple

class Block:
    def __init__(self, color: str, position: Tuple[int, int]):
        self.color = color
        self.position = position

class Score:
    def __init__(self):
        self.points = 0

    def add_points(self, points: int) -> None:
        self.points += points

    def get_score(self) -> int:
        return self.points

    def update_score(self, cleared_blocks: int) -> None:
        self.add_points(cleared_blocks * 10)

class Move:
    def __init__(self, blocks: List[Block]):
        self.blocks = blocks

class Grid:
    def __init__(self, rows: int, cols: int):
        self.rows = rows
        self.cols = cols
        self.blocks = [[None for _ in range(cols)] for _ in range(rows)]
        self.populate_blocks()

    def populate_blocks(self) -> None:
        colors = ['red', 'green', 'blue', 'yellow', 'purple']
        for r in range(self.rows):
            for c in range(self.cols):
                color = colors[(r + c) % len(colors)]
                self.blocks[r][c] = Block(color, (r, c))

    def display(self, screen) -> None:
        for row in self.blocks:
            for block in row:
                if block is not None:
                    pygame.draw.rect(screen, block.color, (block.position[1] * 50, block.position[0] * 50, 50, 50))

    def connect_blocks(self, selected: List[Block]) -> int:
        if selected:
            if all(block.color == selected[0].color for block in selected):
                cleared_count = len(selected)
                for block in selected:
                    self.blocks[block.position[0]][block.position[1]] = None
                self.fall_blocks()
                return cleared_count
        return 0

    def fall_blocks(self) -> None:
        for col in range(self.cols):
            empty_spaces = 0
            for row in range(self.rows - 1, -1, -1):
                if self.blocks[row][col] is None:
                    empty_spaces += 1
                elif empty_spaces > 0:
                    self.blocks[row + empty_spaces][col] = self.blocks[row][col]
                    self.blocks[row][col] = None
            for row in range(empty_spaces):
                self.blocks[row][col] = Block('red', (row, col))  # Example color for new blocks

    def load_game_state(self, data: dict) -> None:
        self.blocks = []
        for r, row in enumerate(data['blocks']):
            self.blocks.append([Block(block['color'], (r, c)) if block else None for c, block in enumerate(row)])
        self.rows = len(self.blocks)
        self.cols = len(self.blocks[0]) if self.blocks else 0

    def save_game_state(self) -> dict:
        return {
            'blocks': [[{'color': block.color} if block else None for block in row] for row in self.blocks]
        }

class Game:
    def __init__(self):
        self.grid = Grid(6, 6)
        self.score = Score()
        self.selected_blocks = []
        self.history = []

    def run(self) -> None:
        pygame.init()
        screen = pygame.display.set_mode((300, 300))
        pygame.display.set_caption("Block Connect Game")
        clock = pygame.time.Clock()
        running = True

        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                # Handle block selection and game logic here

            screen.fill((255, 255, 255))
            self.grid.display(screen)
            pygame.display.flip()
            clock.tick(60)

        pygame.quit()

    def undo_move(self) -> None:
        if self.history:
            last_move = self.history.pop()
            for block in last_move.blocks:
                self.grid.blocks[block.position[0]][block.position[1]] = block

    def clear_blocks(self) -> None:
        cleared_count = self.grid.connect_blocks(self.selected_blocks)
        if cleared_count > 0:
            self.history.append(Move(self.selected_blocks.copy()))
            self.score.update_score(cleared_count)
        self.selected_blocks.clear()

    def load_game_state(self, filename: str) -> None:
        try:
            with open(filename, 'r') as file:
                data = json.load(file)
                self.grid.load_game_state(data)
                self.score.points = data.get('score', 0)
        except FileNotFoundError:
            print("Game state file not found.")

    def save_game_state(self, filename: str) -> None:
        game_state = {
            'blocks': self.grid.save_game_state()['blocks'],
            'score': self.score.get_score()
        }
        with open(filename, 'w') as file:
            json.dump(game_state, file)

    def save_game_state_to_file(self, filename: str) -> None:
        game_state = self.save_game_state()
        with open(filename, 'w') as file:
            for row in game_state['blocks']:
                file.write('|'.join([block['color'] if block else 'null' for block in row]) + '\n')
            file.write(f"score|{self.score.get_score()}\n")