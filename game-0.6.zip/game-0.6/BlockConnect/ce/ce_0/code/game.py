import pygame
import random
from typing import List

class Block:
    def __init__(self, color: tuple):
        self.color = color

class Move:
    def __init__(self, blocks: List[Block]):
        self.blocks = blocks

class Score:
    def __init__(self):
        self.points = 0

    def update_score(self, cleared_blocks: int) -> None:
        self.points += cleared_blocks * 10  # Assume each cleared block gives 10 points

    def get_score(self) -> int:
        return self.points

class Grid:
    def __init__(self, width: int, height: int):
        self.blocks = [[None for _ in range(width)] for _ in range(height)]
        self.width = width
        self.height = height

    def display(self) -> None:
        # Code to display the grid using Pygame would go here
        pass

    def fall_blocks(self) -> None:
        # Logic to make blocks fall down would go here
        pass

    def generate_new_blocks(self) -> None:
        # Logic to generate new blocks at the top of the grid would go here
        pass

class Game:
    def __init__(self):
        self.grid = Grid(10, 10)
        self.score = Score()
        self.history = []

    def start_game(self) -> None:
        self.grid.generate_new_blocks()
        self.score = Score()  # Reset score
        self.history.clear()  # Clear move history

    def connect_blocks(self, selected_blocks: List[Block]) -> None:
        if selected_blocks:
            self.history.append(Move(selected_blocks))
            cleared_blocks = len(selected_blocks)  # Assume all selected blocks are cleared
            self.score.update_score(cleared_blocks)
            self.update_grid()

    def undo_move(self) -> None:
        if self.history:
            last_move = self.history.pop()
            # Logic to undo the last move would go here
            # This would likely involve putting the blocks back
            pass

    def update_grid(self) -> None:
        # Logic to update the grid display after blocks are connected would go here
        pass