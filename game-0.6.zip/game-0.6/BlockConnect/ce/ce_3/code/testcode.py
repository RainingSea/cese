import unittest
import os
from block_connect import BlockConnect

class TestBlockConnectGame(unittest.TestCase):

    def setUp(self):
        # Initialize the game
        self.game = BlockConnect()

    def test_select_and_connect_blocks(self):
        # Functionalities 1: Select and Connect Blocks of the Same Color
        self.game.grid[0][0] = 1
        self.game.grid[0][1] = 1
        self.game.select_block(0, 0)
        self.game.select_block(0, 1)
        self.assertEqual(self.game.grid[0][0], 0, "Block at (0,0) should be cleared")
        self.assertEqual(self.game.grid[0][1], 0, "Block at (0,1) should be cleared")

    def test_display_game_grid(self):
        # Functionalities 2: Display the Game Grid
        # This functionality is related to UI display, which is not directly testable in a unit test.
        # Assuming the grid is initialized correctly.
        self.assertEqual(len(self.game.grid), 10, "Grid should have 10 rows")
        self.assertEqual(len(self.game.grid[0]), 10, "Grid should have 10 columns")

    def test_score_calculation_after_block_clearing(self):
        # Functionalities 3: Score Calculation After Block Clearing
        self.game.grid[0][0] = 1
        self.game.grid[0][1] = 1
        self.game.grid[0][2] = 1
        self.game.clear_blocks([(0, 0), (0, 1), (0, 2)])
        self.game.score += 3
        self.assertEqual(self.game.score, 3, "Score should be 3 after clearing three blocks")

    def test_blocks_fall_to_occupy_spaces(self):
        # Functionalities 4: Blocks Fall to Occupy Spaces
        self.game.grid[1][0] = 1
        self.game.grid[0][0] = 0
        self.game.fall_blocks()
        self.assertEqual(self.game.grid[0][0], 1, "Block should fall to the empty space")

    def test_undo_last_move(self):
        # Functionalities 5: Undo Last Move
        self.game.grid[0][0] = 1
        self.game.select_block(0, 0)
        self.game.undo_move()
        self.assertEqual(self.game.grid[0][0], 1, "Block should be restored after undo")

    def test_save_game_state(self):
        # Functionalities 6: Save Game State to a Local File
        self.game.save_game_state()
        self.assertTrue(os.path.exists('game_state.txt'), "Game state file should exist after saving")

    def test_load_game_state(self):
        # Functionalities 7: Load Game State from a Local File
        self.game.grid[0][0] = 1
        self.game.save_game_state()
        self.game.grid[0][0] = 0
        self.game.load_game_state()
        self.assertEqual(self.game.grid[0][0], 1, "Game state should be loaded correctly from file")

if __name__ == '__main__':
    unittest.main()
