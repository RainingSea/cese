import pygame
import os

class BlockConnect:
    def __init__(self):
        self.grid = [[0 for _ in range(10)] for _ in range(10)]  # 10x10 grid
        self.score = 0
        self.undo_stack = []
        self.load_game_state()

    def select_block(self, x: int, y: int) -> None:
        if self.grid[y][x] != 0:
            self.undo_stack.append((x, y, self.grid[y][x]))  # Save current state for undo
            self.grid[y][x] = 0  # Clear the block

    def clear_blocks(self, blocks: list) -> None:
        for x, y in blocks:
            self.grid[y][x] = 0  # Clear each block

    def fall_blocks(self) -> None:
        for x in range(len(self.grid[0])):
            for y in range(len(self.grid) - 1, -1, -1):
                if self.grid[y][x] == 0:
                    for k in range(y - 1, -1, -1):
                        if self.grid[k][x] != 0:
                            self.grid[y][x] = self.grid[k][x]
                            self.grid[k][x] = 0
                            break

    def add_new_blocks(self) -> None:
        for x in range(len(self.grid[0])):
            if self.grid[0][x] == 0:
                self.grid[0][x] = 1  # Add a new block

    def undo_move(self) -> None:
        if self.undo_stack:
            x, y, value = self.undo_stack.pop()
            self.grid[y][x] = value  # Restore the block

    def save_game_state(self) -> None:
        with open('game_state.txt', 'w') as f:
            for row in self.grid:
                f.write('|'.join(map(str, row)) + '\n')
            f.write(str(self.score) + '\n')

    def load_game_state(self) -> None:
        if os.path.exists('game_state.txt'):
            with open('game_state.txt', 'r') as f:
                lines = f.readlines()
                self.grid = [list(map(int, line.strip().split('|'))) for line in lines[:-1]]
                self.score = int(lines[-1].strip())

    def run(self) -> None:
        pygame.init()
        screen = pygame.display.set_mode((800, 600))
        pygame.display.set_caption("Block Connect Game")
        clock = pygame.time.Clock()

        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                # Handle other events (e.g., block selection)

            screen.fill((255, 255, 255))
            # Draw the grid and score here
            pygame.display.flip()
            clock.tick(60)

        pygame.quit()