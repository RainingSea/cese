from block_connect import BlockConnect

def main() -> None:
    game = BlockConnect()
    game.run()

if __name__ == "__main__":
    main()