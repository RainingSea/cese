import unittest
import pygame
from game import Game

class TestBlockConnectGame(unittest.TestCase):

    def setUp(self):
        # Initialize the game
        self.game = Game()
        self.game.start_game()

    def test_select_and_connect_blocks(self):
        # Functionalities 1: Select and Connect Blocks of the Same Color
        # Simulate selecting two blocks of the same color
        self.game.grid[0][0].color = "red"
        self.game.grid[0][1].color = "red"
        self.game.select_block(0, 0)
        self.game.select_block(0, 1)
        
        # Check if the blocks are cleared
        self.assertEqual(self.game.grid[0][0].color, "white", "Block should be cleared")
        self.assertEqual(self.game.grid[0][1].color, "white", "Block should be cleared")

    def test_display_game_grid(self):
        # Functionalities 2: Display the Game Grid
        # Check if the grid is initialized with blocks
        self.assertEqual(len(self.game.grid), 10, "Grid should have 10 rows")
        self.assertEqual(len(self.game.grid[0]), 10, "Grid should have 10 columns")

    def test_score_calculation(self):
        # Functionalities 3: Score Calculation After Block Clearing
        # Simulate clearing three blocks
        self.game.grid[0][0].color = "red"
        self.game.grid[0][1].color = "red"
        self.game.grid[0][2].color = "red"
        self.game.select_block(0, 0)
        self.game.select_block(0, 1)
        self.game.select_block(0, 2)
        
        # Check if the score is updated correctly
        self.assertEqual(self.game.score.get_score(), 3, "Score should be 3 after clearing 3 blocks")

    def test_blocks_fall(self):
        # Functionalities 4: Blocks Fall to Occupy Spaces
        # Simulate clearing a block in the middle
        self.game.grid[5][0].color = "red"
        self.game.grid[4][0].color = "blue"
        self.game.select_block(5, 0)
        
        # Check if the block above falls down
        self.assertEqual(self.game.grid[5][0].color, "blue", "Block should fall to fill the gap")

    def test_undo_last_move(self):
        # Functionalities 5: Undo Last Move
        # Simulate a move and then undo it
        self.game.grid[0][0].color = "red"
        self.game.select_block(0, 0)
        self.game.undo_move()
        
        # Check if the block is restored
        self.assertEqual(self.game.grid[0][0].color, "red", "Block should be restored after undo")

    def test_save_game_state(self):
        # Functionalities 6: Save Game State to a Local File
        # Simulate saving the game state
        self.game.save_game_state()
        
        # Check if the file is created and contains the correct data
        with open('game_state.txt', 'r') as f:
            game_state = f.read()
            self.assertIn('"score": 0', game_state, "Game state should be saved with correct score")

    def test_load_game_state(self):
        # Functionalities 7: Load Game State from a Local File
        # Simulate loading the game state
        self.game.load_game_state()
        
        # Check if the game state is loaded correctly
        self.assertEqual(self.game.score.get_score(), 0, "Game state should be loaded with correct score")
        self.assertEqual(self.game.grid[0][0].color, "red", "Game state should be loaded with correct grid")

if __name__ == '__main__':
    unittest.main()
