import pygame
import json

class Block:
    def __init__(self, color: str, position: tuple[int, int]) -> None:
        self.color = color
        self.position = position

class Score:
    def __init__(self) -> None:
        self.current_score = 0

    def update_score(self, blocks_cleared: int) -> None:
        self.current_score += blocks_cleared

    def get_score(self) -> int:
        return self.current_score

class Game:
    def __init__(self) -> None:
        self.grid = [[Block("white", (x, y)) for x in range(10)] for y in range(10)]
        self.score = Score()
        self.last_move = []

    def start_game(self) -> None:
        pass  # Initialize game state here

    def select_block(self, x: int, y: int) -> None:
        block = self.grid[y][x]
        if block.color != "white":
            self.last_move.append((x, y))
            self.clear_blocks(self.last_move)

    def clear_blocks(self, selected: list[tuple[int, int]]) -> None:
        blocks_cleared = len(selected)
        for x, y in selected:
            self.grid[y][x].color = "white"  # Clear the block
        self.score.update_score(blocks_cleared)
        self.fall_blocks()

    def fall_blocks(self) -> None:
        for x in range(10):
            for y in range(9, -1, -1):
                if self.grid[y][x].color == "white":
                    for k in range(y, 0, -1):
                        if self.grid[k-1][x].color != "white":
                            self.grid[k][x].color = self.grid[k-1][x].color
                            self.grid[k-1][x].color = "white"
                            break

    def undo_move(self) -> None:
        if self.last_move:
            last_x, last_y = self.last_move.pop()
            self.grid[last_y][last_x].color = "red"  # Restore last block

    def save_game_state(self) -> None:
        game_state = {
            'grid': [[block.color for block in row] for row in self.grid],
            'score': self.score.get_score()
        }
        with open('game_state.txt', 'w') as f:
            json.dump(game_state, f)

    def load_game_state(self) -> None:
        try:
            with open('game_state.txt', 'r') as f:
                game_state = json.load(f)
                self.grid = [[Block(color, (x, y)) for x, color in enumerate(row)] for y, row in enumerate(game_state['grid'])]
                self.score.current_score = game_state['score']
        except FileNotFoundError:
            pass