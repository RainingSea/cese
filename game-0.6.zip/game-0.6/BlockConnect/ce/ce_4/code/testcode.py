import unittest
from game import Game
from grid import Grid
from score import Score

class TestBlockConnectGame(unittest.TestCase):

    def setUp(self):
        self.game = Game(10, 10)
        self.game.start_game()

    def test_select_and_connect_blocks(self):
        # Functionalities 1: Select and Connect Blocks of the Same Color
        initial_blocks = [self.game.grid.get_block(0, 0), self.game.grid.get_block(0, 1)]
        self.game.select_block(0, 0)
        self.game.select_block(0, 1)
        self.assertEqual(self.game.grid.get_block(0, 0), '', "Block should be cleared")
        self.assertEqual(self.game.grid.get_block(0, 1), '', "Block should be cleared")

    def test_display_game_grid(self):
        # Functionalities 2: Display the Game Grid
        self.assertIsNotNone(self.game.grid.blocks, "Game grid should be initialized and displayed")

    def test_score_calculation_after_block_clearing(self):
        # Functionalities 3: Score Calculation After Block Clearing
        self.game.select_block(0, 0)
        self.game.select_block(0, 1)
        self.game.select_block(0, 2)
        self.assertEqual(self.game.score.get_score(), 30, "Score should be 30 after clearing three blocks")

    def test_blocks_fall_to_occupy_spaces(self):
        # Functionalities 4: Blocks Fall to Occupy Spaces
        self.game.select_block(0, 0)
        self.game.select_block(0, 1)
        self.game.clear_blocks()
        self.assertEqual(self.game.grid.get_block(0, 0), '', "Block should be cleared")
        self.assertNotEqual(self.game.grid.get_block(1, 0), '', "Block above should fall down")

    def test_undo_last_move(self):
        # Functionalities 5: Undo Last Move
        self.game.select_block(0, 0)
        self.game.undo_move()
        self.assertEqual(len(self.game.moves_history), 0, "Move history should be empty after undo")

    def test_save_game_state(self):
        # Functionalities 6: Save Game State to a Local File
        self.game.save_game_state()
        with open('game_state.txt', 'r') as f:
            content = f.read()
        self.assertIn('R G B Y', content, "Game state should be saved to file")

    def test_load_game_state(self):
        # Functionalities 7: Load Game State from a Local File
        self.game.load_game_state()
        self.assertEqual(self.game.grid.get_block(0, 0), 'R', "Game state should be loaded correctly")

if __name__ == '__main__':
    unittest.main()
