from typing import List, Tuple
from grid import Grid
from score import Score

class Game:
    def __init__(self, rows: int, cols: int):
        self.grid = Grid(rows, cols)
        self.score = Score()
        self.moves_history: List[Tuple[int, int]] = []

    def start_game(self) -> None:
        self.grid.initialize_grid()

    def select_block(self, x: int, y: int) -> None:
        block_color = self.grid.get_block(x, y)
        if block_color:
            self.moves_history.append((x, y))
            self.clear_blocks()

    def clear_blocks(self) -> None:
        if not self.moves_history:
            return
        blocks_to_clear = self.moves_history[:]
        self.grid.remove_blocks(blocks_to_clear)
        self.score.increment(len(blocks_to_clear) * 10)  # Example scoring logic
        self.fall_blocks()

    def fall_blocks(self) -> None:
        self.grid.update_grid()

    def undo_move(self) -> None:
        if self.moves_history:
            last_move = self.moves_history.pop()
            # Logic to handle undoing a move (not fully implemented here)

    def save_game_state(self) -> None:
        with open('game_state.txt', 'w') as f:
            for row in self.grid.blocks:
                f.write(' '.join(row) + '\n')

    def load_game_state(self) -> None:
        with open('game_state.txt', 'r') as f:
            self.grid.blocks = [line.strip().split() for line in f.readlines()]