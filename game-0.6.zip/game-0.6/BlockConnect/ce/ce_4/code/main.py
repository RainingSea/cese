import pygame
from game import Game

def main() -> None:
    pygame.init()
    
    rows, cols = 10, 10  # Example grid size
    game = Game(rows, cols)
    game.start_game()

    # Example game loop (simplified)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        # Here you would include code to draw the grid and handle user input
        pygame.display.flip()

    pygame.quit()

if __name__ == "__main__":
    main()