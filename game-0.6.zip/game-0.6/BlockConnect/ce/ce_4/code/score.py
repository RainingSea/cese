class Score:
    def __init__(self):
        self.points = 0

    def increment(self, points: int) -> None:
        self.points += points

    def get_score(self) -> int:
        return self.points