class Move:
    def __init__(self, blocks_cleared: list):
        self.blocks_cleared = blocks_cleared