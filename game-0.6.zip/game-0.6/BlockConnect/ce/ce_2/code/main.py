import pygame
from game import Game

def main():
    pygame.init()
    screen = pygame.display.set_mode((800, 600))
    pygame.display.set_caption("Block Connect Puzzle Game")
    
    game = Game()
    game.start_game()

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        screen.fill((0, 0, 0))  # Clear screen
        game.grid.display_grid()  # Update display with grid
        
        pygame.display.flip()

    pygame.quit()

if __name__ == "__main__":
    main()