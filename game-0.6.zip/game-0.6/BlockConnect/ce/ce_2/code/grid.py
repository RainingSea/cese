from block import Block

class Grid:
    def __init__(self, width: int, height: int):
        self.blocks = [[Block("white") for _ in range(width)] for _ in range(height)]

    def display_grid(self):
        for row in self.blocks:
            print(" | ".join(block.color for block in row))

    def update_grid(self, new_blocks: list):
        self.blocks = new_blocks