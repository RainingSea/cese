from grid import Grid
from block import Block
from move import Move

class Game:
    def __init__(self):
        self.grid = Grid(10, 10)  # Example grid size
        self.score = 0
        self.move_history = []

    def start_game(self):
        self.grid = Grid(10, 10)  # Reset grid
        self.score = 0
        self.move_history.clear()

    def select_blocks(self, selected_blocks: list):
        cleared_blocks = [block for block in selected_blocks if block.color != "white"]
        self.clear_blocks(cleared_blocks)

    def clear_blocks(self, blocks: list):
        for block in blocks:
            block.color = "white"
        self.move_history.append(Move(blocks))

    def fall_blocks(self):
        # Implement logic to make blocks fall into empty spaces
        pass

    def undo_move(self):
        if self.move_history:
            last_move = self.move_history.pop()
            for block in last_move.blocks_cleared:
                block.color = "red"  # Example color to restore