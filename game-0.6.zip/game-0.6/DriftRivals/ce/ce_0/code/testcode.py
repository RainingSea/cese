import unittest
import pygame
from DriftRivalsGame import DriftRivalsGame
from Car import Car
from Track import Track
from Score import Score

class TestDriftRivalsGame(unittest.TestCase):

    def setUp(self):
        # Initialize the game and its components
        self.game = DriftRivalsGame()
        self.car = self.game.car
        self.track = self.game.track
        self.score = self.game.score

    def test_player_controls_drift_car(self):
        # Functionality 1: Test car movement with arrow keys
        initial_position = self.car.position

        # Simulate pressing the up arrow key
        self.car.move("up")
        self.assertEqual(self.car.position, (initial_position[0], initial_position[1] - 1), "Car should move up")

        # Simulate pressing the left arrow key
        self.car.move("left")
        self.assertEqual(self.car.position, (initial_position[0] - 1, initial_position[1] - 1), "Car should move left")

        # Simulate pressing the down arrow key
        self.car.move("down")
        self.assertEqual(self.car.position, (initial_position[0] - 1, initial_position[1]), "Car should move down")

        # Simulate pressing the right arrow key
        self.car.move("right")
        self.assertEqual(self.car.position, (initial_position[0], initial_position[1]), "Car should move right")

    def test_variety_of_tracks(self):
        # Functionality 2: Test track loading and navigation
        self.assertEqual(self.track.layout, "Simple Track", "Track should be 'Simple Track'")
        self.assertEqual(self.track.difficulty, 1, "Track difficulty should be 1")

        # Simulate navigating through the track
        # Since there's no actual navigation logic, we assume success if no errors occur
        try:
            self.track.draw()
        except Exception as e:
            self.fail(f"Navigation through the track failed with error: {e}")

    def test_drift_challenges_and_scoring_system(self):
        # Functionality 3: Test scoring system
        initial_score = self.score.points

        # Simulate a drift
        drift_angle = self.car.drift()
        self.score.calculate_score(drift_angle, self.car.speed)

        # Check if score is updated
        self.assertGreater(self.score.points, initial_score, "Score should increase after a drift")

    def test_data_storage(self):
        # Functionality 4: Test score saving
        player_name = "test_player"
        self.score.save_score(player_name)

        # Check if score is saved in the file
        with open('scores.txt', 'r') as f:
            scores = f.readlines()
            self.assertIn(f"{player_name}|{self.score.points}\n", scores, "Score should be saved in the file")

if __name__ == '__main__':
    unittest.main()
