class Car:
    def __init__(self, initial_position: tuple):
        self.position = initial_position
        self.speed = 0.0
        self.drift_angle = 0.0

    def move(self, direction: str):
        if direction == "left":
            self.position = (self.position[0] - 1, self.position[1])
        elif direction == "right":
            self.position = (self.position[0] + 1, self.position[1])
        elif direction == "up":
            self.position = (self.position[0], self.position[1] - 1)
        elif direction == "down":
            self.position = (self.position[0], self.position[1] + 1)

    def drift(self) -> float:
        self.drift_angle += 10  # Increment drift angle
        return self.drift_angle