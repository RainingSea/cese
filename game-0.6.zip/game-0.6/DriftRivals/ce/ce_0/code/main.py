from DriftRivalsGame import DriftRivalsGame

if __name__ == "__main__":
    game = DriftRivalsGame()
    game.run_game()