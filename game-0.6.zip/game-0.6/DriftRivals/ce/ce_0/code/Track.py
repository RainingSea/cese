class Track:
    def __init__(self, layout: str, difficulty: int):
        self.layout = layout
        self.difficulty = difficulty

    def draw(self):
        print(f"Drawing track layout: {self.layout} with difficulty {self.difficulty}")