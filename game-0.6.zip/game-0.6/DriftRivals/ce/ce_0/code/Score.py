class Score:
    def __init__(self):
        self.points = 0

    def calculate_score(self, drift_angle: float, speed: float):
        self.points += int(drift_angle * speed)

    def save_score(self, player_name: str):
        with open('scores.txt', 'a') as f:
            f.write(f"{player_name}|{self.points}\n")