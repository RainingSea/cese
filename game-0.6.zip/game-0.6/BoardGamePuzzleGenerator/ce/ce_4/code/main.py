import pygame
from game import Game

def main() -> str:
    pygame.init()
    game = Game()
    game.start_game("Logic")  # Example category; this could be modified to allow user input
    return "Game started!"

if __name__ == "__main__":
    print(main())