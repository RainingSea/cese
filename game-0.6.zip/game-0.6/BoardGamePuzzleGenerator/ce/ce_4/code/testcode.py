import unittest
from game import Game, PuzzleGenerator, Timer, Scoreboard

class TestBoardGamePuzzleGenerator(unittest.TestCase):

    def setUp(self):
        self.game = Game()

    def test_select_puzzle_category(self):
        # Functionalities 1: Select Puzzle Category
        self.game.start_game("Logic")
        self.assertIn("Logic", self.game.puzzle_generator.puzzles, "Category 'Logic' should be loaded in puzzles")

    def test_generate_new_puzzle(self):
        # Functionalities 2: Generate a New Puzzle
        self.game.start_game("Logic")
        puzzle = self.game.puzzle_generator.generate_puzzle("Logic")
        self.assertIsNotNone(puzzle, "A puzzle should be generated for the 'Logic' category")
        self.assertIn(puzzle, self.game.puzzle_generator.puzzles["Logic"], "Generated puzzle should be from the 'Logic' category")

    def test_start_timer(self):
        # Functionalities 3: Start the Timer
        self.game.timer.start()
        self.assertIsNotNone(self.game.timer.start_time, "Timer should start and have a start time")

    def test_calculate_player_score(self):
        # Functionalities 4: Calculate Player’s Score
        self.game.start_game("Logic")
        self.game.timer.start()
        time.sleep(1)  # Simulate time taken to solve the puzzle
        self.game.submit_solution("example_solution")
        score = self.game.scoreboard.scores[-1]
        self.assertTrue(score['accuracy'], "Score should reflect correct solution")
        self.assertLess(score['time'], 300, "Score should reflect time taken under 5 minutes")

    def test_submit_solution(self):
        # Functionalities 5: Submit Solution
        self.game.start_game("Logic")
        self.game.timer.start()
        feedback = self.game.submit_solution("example_solution")
        self.assertEqual(feedback, "Correct!", "Feedback should indicate the solution is correct")

    def test_view_puzzle_feedback(self):
        # Functionalities 6: View Puzzle Feedback
        self.game.start_game("Logic")
        self.game.timer.start()
        feedback = self.game.submit_solution("wrong_solution")
        self.assertEqual(feedback, "Incorrect!", "Feedback should indicate the solution is incorrect")

    def test_timer_stops_on_solution_submission(self):
        # Functionalities 7: Timer Stops on Solution Submission
        self.game.start_game("Logic")
        self.game.timer.start()
        time.sleep(1)  # Simulate time taken to solve the puzzle
        self.game.submit_solution("example_solution")
        final_time = self.game.timer.get_time()
        self.assertGreater(final_time, 0, "Final time should be greater than 0")
        self.assertLess(final_time, 2, "Final time should be less than 2 seconds")

    def test_load_puzzle_data_from_file(self):
        # Functionalities 8: Load Puzzle Data from File
        self.game.puzzle_generator.load_puzzles()
        self.assertIn("Logic", self.game.puzzle_generator.puzzles, "Puzzles should be loaded from file")
        self.assertGreater(len(self.game.puzzle_generator.puzzles["Logic"]), 0, "Loaded puzzles should not be empty")

    def test_validate_puzzle_solution_format(self):
        # Functionalities 9: Validate Puzzle Solution Format
        self.game.start_game("Logic")
        self.game.timer.start()
        feedback = self.game.submit_solution(12345)  # Invalid format
        self.assertEqual(feedback, "Incorrect!", "Feedback should indicate the solution is incorrect due to invalid format")

if __name__ == '__main__':
    unittest.main()
