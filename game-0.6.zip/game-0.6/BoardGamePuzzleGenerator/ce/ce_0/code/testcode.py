import unittest
from unittest.mock import patch, MagicMock
from game import Game
from puzzles import PuzzleGenerator
from timer import Timer
from score import Score

class TestBoardGamePuzzleGenerator(unittest.TestCase):

    def setUp(self):
        self.game = Game()
        self.puzzle_generator = self.game.puzzle_generator
        self.timer = self.game.timer
        self.score = self.game.score

    def test_select_puzzle_category(self):
        # Functionalities 1: Select Puzzle Category
        category = "logic"
        puzzle = self.puzzle_generator.generate_puzzle(category)
        self.assertIsNotNone(puzzle, "Puzzle should be generated for the selected category")

    def test_generate_new_puzzle(self):
        # Functionalities 2: Generate a New Puzzle
        category = "logic"
        puzzle1 = self.puzzle_generator.generate_puzzle(category)
        puzzle2 = self.puzzle_generator.generate_puzzle(category)
        self.assertNotEqual(puzzle1, puzzle2, "Each generated puzzle should be unique")

    def test_start_timer(self):
        # Functionalities 3: Start the Timer
        self.timer.start()
        self.assertGreater(self.timer.start_time, 0, "Timer should start and have a start time greater than 0")

    def test_calculate_player_score(self):
        # Functionalities 4: Calculate Player’s Score
        self.score.calculate_score(240, True)  # 4 minutes
        self.assertGreater(self.score.get_score(), 0, "Score should be calculated based on time and correctness")

    @patch('builtins.input', return_value='correct_solution')
    def test_submit_solution(self, mock_input):
        # Functionalities 5: Submit Solution
        with patch('game.Game.update_score') as mock_update_score:
            self.game.submit_solution('correct_solution')
            mock_update_score.assert_called_once()
            self.assertTrue(mock_update_score.called, "Solution submission should trigger score update")

    @patch('builtins.input', return_value='correct_solution')
    def test_view_puzzle_feedback(self, mock_input):
        # Functionalities 6: View Puzzle Feedback
        with patch('game.Game.submit_solution', return_value=True) as mock_submit_solution:
            self.game.submit_solution('correct_solution')
            self.assertTrue(mock_submit_solution.called, "Feedback should be displayed after solution submission")

    def test_timer_stops_on_solution_submission(self):
        # Functionalities 7: Timer Stops on Solution Submission
        self.timer.start()
        time.sleep(1)  # Simulate time passing
        time_taken = self.timer.stop()
        self.assertGreater(time_taken, 0, "Timer should stop and record the time taken")

    def test_load_puzzle_data_from_file(self):
        # Functionalities 8: Load Puzzle Data from File
        puzzles = self.puzzle_generator.load_puzzles("logic_puzzles.txt")
        self.assertGreater(len(puzzles), 0, "Puzzle data should be loaded from file")

    def test_validate_puzzle_solution_format(self):
        # Functionalities 9: Validate Puzzle Solution Format
        invalid_solution = "invalid_format"
        with patch('game.Game.submit_solution', return_value=False) as mock_submit_solution:
            self.game.submit_solution(invalid_solution)
            self.assertFalse(mock_submit_solution.return_value, "Invalid solution format should be flagged")

if __name__ == '__main__':
    unittest.main()
