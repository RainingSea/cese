from puzzles import PuzzleGenerator
from timer import Timer
from score import Score

class Game:
    def __init__(self):
        self.puzzle_generator = PuzzleGenerator()
        self.timer = Timer()
        self.score = Score()

    def start_game(self, category: str):
        puzzle = self.puzzle_generator.generate_puzzle(category)
        if puzzle:
            print(f"Puzzle: {puzzle}")
            self.timer.start()
            # Simulate user input for solution
            solution = input("Enter your solution: ")
            self.submit_solution(solution)

    def submit_solution(self, solution: str) -> bool:
        # For demonstration, assume the solution is correct if it matches the puzzle
        correct = solution == "correct_solution"  # Placeholder for actual solution check
        time_taken = self.timer.stop()
        self.update_score(time_taken, correct)
        print(f"Score: {self.score.get_score()}")

    def update_score(self, time_taken: float, correct: bool):
        self.score.calculate_score(time_taken, correct)