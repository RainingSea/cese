import random

class PuzzleGenerator:
    def __init__(self):
        self.puzzles = {
            "logic": self.load_puzzles("logic_puzzles.txt"),
            "pattern_recognition": self.load_puzzles("pattern_recognition.txt"),
            "spatial": self.load_puzzles("spatial_puzzles.txt")
        }

    def load_puzzles(self, filename):
        with open(filename, 'r') as file:
            return file.read().strip().splitlines()

    def generate_puzzle(self, category: str) -> str:
        puzzles = self.puzzles.get(category, [])
        return random.choice(puzzles) if puzzles else None