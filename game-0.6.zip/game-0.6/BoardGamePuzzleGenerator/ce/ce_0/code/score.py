class Score:
    def __init__(self):
        self.points = 0

    def calculate_score(self, time_taken: float, correct: bool) -> int:
        if correct:
            base_score = 100
            penalty = int(time_taken * 10)
            self.points += max(0, base_score - penalty)
        return self.points

    def get_score(self) -> int:
        return self.points