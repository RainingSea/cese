import pygame
import time
from puzzle_generator import PuzzleGenerator

class Timer:
    def __init__(self):
        self.start_time = 0.0

    def start(self) -> None:
        self.start_time = time.time()

    def get_elapsed_time(self) -> float:
        return time.time() - self.start_time

class Score:
    def __init__(self):
        self.time_taken = 0.0
        self.accuracy = False

    def calculate_score(self) -> int:
        if self.accuracy:
            return max(0, 100 - int(self.time_taken))
        return 0

    def save_score(self, file_path: str) -> None:
        with open(file_path, 'a') as file:
            file.write(f"{self.time_taken}|{self.accuracy}\n")

class Game:
    def __init__(self):
        self.puzzle_generator = PuzzleGenerator()
        self.timer = Timer()
        self.score = Score()
        self.puzzle_generator.load_puzzles('puzzles.txt')

    def start_game(self, category: str) -> None:
        self.timer.start()
        puzzle = self.puzzle_generator.generate_puzzle(category)
        print(f"Puzzle: {puzzle}")
        solution = input("Enter your solution: ")
        self.submit_solution(solution)

    def submit_solution(self, solution: str) -> str:
        # Simulate checking the solution
        correct_solution = "example"  # Placeholder for the correct solution
        self.timer.get_elapsed_time()
        self.score.time_taken = self.timer.get_elapsed_time()
        self.score.accuracy = solution == correct_solution
        score_value = self.score.calculate_score()
        self.score.save_score('scores.txt')
        return f"Your score: {score_value}"