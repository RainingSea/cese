import unittest
from unittest.mock import patch, mock_open
from game_logic import Game, Timer, Score
from puzzle_generator import PuzzleGenerator

class TestBoardGamePuzzleGenerator(unittest.TestCase):

    def setUp(self):
        self.game = Game()

    def test_select_puzzle_category(self):
        # Functionalities 1: Select Puzzle Category
        category = "logic puzzles"
        self.game.puzzle_generator.puzzles[category] = ["Sample puzzle"]
        puzzle = self.game.puzzle_generator.generate_puzzle(category)
        self.assertIn(puzzle, self.game.puzzle_generator.puzzles[category], 
                      "The puzzle should be from the selected category.")

    def test_generate_new_puzzle(self):
        # Functionalities 2: Generate a New Puzzle
        category = "default"
        puzzle = self.game.puzzle_generator.generate_puzzle(category)
        self.assertIn(puzzle, self.game.puzzle_generator.puzzles[category], 
                      "A unique puzzle should be generated from the selected category.")

    def test_start_timer(self):
        # Functionalities 3: Start the Timer
        self.game.timer.start()
        elapsed_time = self.game.timer.get_elapsed_time()
        self.assertGreaterEqual(elapsed_time, 0, "Timer should start and show elapsed time.")

    def test_calculate_player_score(self):
        # Functionalities 4: Calculate Player’s Score
        self.game.score.time_taken = 240  # 4 minutes
        self.game.score.accuracy = True
        score = self.game.score.calculate_score()
        self.assertEqual(score, 60, "Score should be calculated based on time and accuracy.")

    def test_submit_solution(self):
        # Functionalities 5: Submit Solution
        with patch('builtins.input', return_value="example"):
            feedback = self.game.submit_solution("example")
            self.assertIn("Your score:", feedback, "Feedback should indicate if the solution is correct.")

    def test_view_puzzle_feedback(self):
        # Functionalities 6: View Puzzle Feedback
        with patch('builtins.input', return_value="wrong_solution"):
            feedback = self.game.submit_solution("wrong_solution")
            self.assertIn("Your score:", feedback, "Feedback should indicate correctness of the solution.")

    def test_timer_stops_on_solution_submission(self):
        # Functionalities 7: Timer Stops on Solution Submission
        self.game.timer.start()
        with patch('builtins.input', return_value="example"):
            self.game.submit_solution("example")
            elapsed_time = self.game.timer.get_elapsed_time()
            self.assertGreater(elapsed_time, 0, "Timer should stop and record the time taken.")

    def test_load_puzzle_data_from_file(self):
        # Functionalities 8: Load Puzzle Data from File
        mock_data = "default|Sample puzzle\n"
        with patch('builtins.open', mock_open(read_data=mock_data)):
            self.game.puzzle_generator.load_puzzles('puzzles.txt')
            self.assertIn("default", self.game.puzzle_generator.puzzles, 
                          "Puzzle data should be loaded from the file.")

    def test_validate_puzzle_solution_format(self):
        # Functionalities 9: Validate Puzzle Solution Format
        with patch('builtins.input', return_value="123"):
            feedback = self.game.submit_solution("123")
            self.assertIn("Your score:", feedback, 
                          "The application should handle incorrect format submissions.")

if __name__ == '__main__':
    unittest.main()
