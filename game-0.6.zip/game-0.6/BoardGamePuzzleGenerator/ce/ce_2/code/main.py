import pygame
from game_logic import Game

def main():
    pygame.init()
    game = Game()
    game.start_game("default")  # Starting with a default category for simplicity
    pygame.quit()

if __name__ == "__main__":
    main()