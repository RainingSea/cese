class ScoreTracker:
    def __init__(self):
        self.scores = []

    def calculate_score(self, time_taken: float, accuracy: bool) -> int:
        base_score = 100
        time_penalty = int(time_taken) * 2
        score = base_score - time_penalty
        if accuracy:
            score += 50
        return max(score, 0)

    def save_score(self, score: int) -> None:
        self.scores.append(score)
        with open("user_scores.txt", "a") as file:
            file.write(f"{score}\n")