import random

class PuzzleGenerator:
    def __init__(self):
        self.puzzles = {}

    def load_puzzles(self) -> None:
        for category in ['logic', 'pattern_recognition', 'spatial']:
            try:
                with open(f"{category}_puzzles.txt", "r") as file:
                    self.puzzles[category] = [line.strip() for line in file.readlines()]
            except FileNotFoundError:
                print(f"Error: {category}_puzzles.txt not found.")

    def generate_puzzle(self, category: str) -> str:
        if category not in self.puzzles:
            self.load_puzzles()
        return random.choice(self.puzzles.get(category, []))