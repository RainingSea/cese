class Score:
    def __init__(self):
        self.time_taken = 0.0
        self.accuracy = 0.0

    def calculate_score(self) -> float:
        # Example score calculation based on time taken and accuracy
        return max(0, 100 - self.time_taken * 10 + self.accuracy)

    def display(self) -> float:
        return self.calculate_score()