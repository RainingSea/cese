import json

class PuzzleGenerator:
    def generate_puzzle(self, category: str) -> dict:
        puzzles = self.load_puzzles(category)
        # Simple example logic to return a puzzle
        return puzzles[0] if puzzles else {}

    def load_puzzles(self, category: str) -> list:
        filename = f"{category.lower()}_puzzles.json"
        with open(filename, 'r') as file:
            return json.load(file)