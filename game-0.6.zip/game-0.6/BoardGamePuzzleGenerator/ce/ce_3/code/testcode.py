import unittest
from main import Game
from puzzles import PuzzleGenerator
from timer import Timer
from score import Score

class TestBoardGamePuzzleGenerator(unittest.TestCase):

    def setUp(self):
        # Initialize the game and its components
        self.game = Game()
        self.puzzle_generator = self.game.puzzle_generator
        self.timer = self.game.timer
        self.score = self.game.score

    def test_select_puzzle_category(self):
        # Functionalities 1: Select Puzzle Category
        category = "Logic"
        puzzle = self.puzzle_generator.generate_puzzle(category)
        self.assertIsInstance(puzzle, dict, "The puzzle should be a dictionary")
        self.assertIn("question", puzzle, "The puzzle should have a question key")
        self.assertIn("answer", puzzle, "The puzzle should have an answer key")

    def test_generate_new_puzzle(self):
        # Functionalities 2: Generate a New Puzzle
        category = "Logic"
        puzzle = self.puzzle_generator.generate_puzzle(category)
        self.assertIsNotNone(puzzle, "A puzzle should be generated")
        self.assertIn("question", puzzle, "Generated puzzle should have a question")
        self.assertIn("answer", puzzle, "Generated puzzle should have an answer")

    def test_start_timer(self):
        # Functionalities 3: Start the Timer
        self.timer.start()
        self.assertGreater(self.timer.start_time, 0, "Timer should start and have a start time")

    def test_calculate_player_score(self):
        # Functionalities 4: Calculate Player’s Score
        self.timer.start()
        time.sleep(1)  # Simulate time taken
        self.timer.stop()
        self.score.time_taken = self.timer.stop()
        self.score.accuracy = 100.0  # Assume perfect accuracy
        calculated_score = self.score.calculate_score()
        self.assertGreaterEqual(calculated_score, 0, "Score should be calculated and non-negative")

    def test_submit_solution(self):
        # Functionalities 5: Submit Solution
        solution = "4"  # Assume correct solution for the test
        self.game.submit_solution(solution)
        self.assertTrue(True, "Solution submission should be processed")

    def test_view_puzzle_feedback(self):
        # Functionalities 6: View Puzzle Feedback
        solution = "4"  # Assume correct solution for the test
        self.game.submit_solution(solution)
        self.assertTrue(True, "Feedback should be displayed after solution submission")

    def test_timer_stops_on_solution_submission(self):
        # Functionalities 7: Timer Stops on Solution Submission
        self.timer.start()
        time.sleep(1)  # Simulate time taken
        self.game.submit_solution("4")
        final_time = self.timer.stop()
        self.assertGreater(final_time, 0, "Timer should stop and record the final time")

    def test_load_puzzle_data_from_file(self):
        # Functionalities 8: Load Puzzle Data from File
        category = "Logic"
        puzzles = self.puzzle_generator.load_puzzles(category)
        self.assertIsInstance(puzzles, list, "Puzzles should be loaded as a list")
        self.assertGreater(len(puzzles), 0, "Puzzles should be loaded from file")

    def test_validate_puzzle_solution_format(self):
        # Functionalities 9: Validate Puzzle Solution Format
        solution = "four"  # Incorrect format for a numeric answer
        with self.assertRaises(ValueError, msg="Solution format should be validated"):
            self.game.submit_solution(solution)

if __name__ == '__main__':
    unittest.main()
