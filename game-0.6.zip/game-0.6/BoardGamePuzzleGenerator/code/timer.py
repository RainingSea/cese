import time

class Timer:
    def __init__(self) -> None:
        self.start_time = 0.0

    def start(self) -> None:
        self.start_time = time.time()

    def stop(self) -> float:
        return time.time() - self.start_time