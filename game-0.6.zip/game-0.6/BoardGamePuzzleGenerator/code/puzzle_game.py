import pygame
from puzzle_generator import PuzzleGenerator
from timer import Timer
from score import Score

class Game:
    def __init__(self) -> None:
        self.puzzle_generator = PuzzleGenerator()
        self.timer = Timer()
        self.score = Score()
        self.current_puzzle = None
        self.is_game_running = True

    def start_game(self) -> None:
        self.puzzle_generator.load_puzzles('puzzles.json')
        self.display_main_menu()

    def display_main_menu(self) -> None:
        print("Welcome to the Puzzle Game!")
        category = input("Choose a category: Logic, Pattern Recognition, Spatial: ")
        self.current_puzzle = self.puzzle_generator.generate_puzzle(category)
        if self.current_puzzle:
            self.timer.start()  # Start the timer when the puzzle is presented
            print(self.current_puzzle['question'])
            self.get_solution_input()
        else:
            print("No puzzles available in this category.")
            self.display_main_menu()  # Allow user to choose again

    def get_solution_input(self) -> None:
        solution = input("Enter your solution: ")
        self.validate_solution_format(solution)

    def validate_solution_format(self, solution: str) -> None:
        if not solution.strip():
            print("Solution cannot be empty. Please try again.")
            self.get_solution_input()
        else:
            self.submit_solution(solution)

    def submit_solution(self, solution: str) -> None:
        is_correct = self.current_puzzle['solution'].strip().lower() == solution.strip().lower()
        self.display_feedback(is_correct)
        if is_correct:
            time_taken = self.timer.stop()  # Stop the timer when solution is submitted
            self.score.calculate_score(time_taken, is_correct)
            self.score.save_score('scores.json')
            self.display_main_menu()  # Allow user to play again
        else:
            self.get_solution_input()  # Allow user to try again

    def display_feedback(self, is_correct: bool) -> None:
        if is_correct:
            print("Correct!")
        else:
            print("Incorrect, try again!")