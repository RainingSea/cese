import json
from datetime import datetime

class Score:
    def __init__(self) -> None:
        self.player_name = input("Enter your name: ")
        self.score_value = 0

    def calculate_score(self, time_taken: float, is_correct: bool) -> int:
        base_score = 100
        time_penalty = int(time_taken) * 2
        score = base_score - time_penalty
        if is_correct:
            score += 50
        self.score_value = max(score, 0)
        return self.score_value

    def save_score(self, file_path: str) -> None:
        score_entry = {
            'player_name': self.player_name,
            'score_value': self.score_value,
            'timestamp': datetime.now().isoformat()
        }
        try:
            with open(file_path, 'a') as file:
                json.dump(score_entry, file)
                file.write('\n')
        except Exception as e:
            print(f"Error saving score: {e}")