import pygame
from puzzle_game import Game

def main() -> None:
    pygame.init()
    game = Game()
    game.start_game()

if __name__ == "__main__":
    main()