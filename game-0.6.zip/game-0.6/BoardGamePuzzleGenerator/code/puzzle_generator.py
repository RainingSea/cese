import json
import random

class PuzzleGenerator:
    def __init__(self) -> None:
        self.puzzles = {}

    def load_puzzles(self, file_path: str) -> None:
        with open(file_path, 'r') as file:
            self.puzzles = json.load(file)

    def generate_puzzle(self, category: str) -> dict:
        puzzles_for_category = self.puzzles.get(category, [])
        if puzzles_for_category:
            return random.choice(puzzles_for_category)
        return None