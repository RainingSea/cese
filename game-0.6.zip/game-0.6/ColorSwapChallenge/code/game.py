import pygame
import json
from random import choice

class Block:
    def __init__(self, color: str) -> None:
        self.color = color

class Grid:
    def __init__(self) -> None:
        self.blocks = []

    def initialize_grid(self, size: int, colors: list) -> None:
        self.blocks = [[Block(choice(colors)) for _ in range(size)] for _ in range(size)]

    def swap(self, pos1: tuple, pos2: tuple) -> None:
        block1 = self.get_block(pos1)
        block2 = self.get_block(pos2)
        self.set_block(pos1, block2)
        self.set_block(pos2, block1)

    def get_block(self, pos: tuple) -> Block:
        x, y = pos
        return self.blocks[y][x]

    def set_block(self, pos: tuple, block: Block) -> None:
        x, y = pos
        self.blocks[y][x] = block

    def get_matches(self) -> list:
        matches = []
        for y in range(len(self.blocks)):
            for x in range(len(self.blocks[y])):
                if x < len(self.blocks[y]) - 2 and self.blocks[y][x].color == self.blocks[y][x + 1].color == self.blocks[y][x + 2].color:
                    matches.append([(x, y), (x + 1, y), (x + 2, y)])
                if y < len(self.blocks) - 2 and self.blocks[y][x].color == self.blocks[y + 1][x].color == self.blocks[y + 2][x].color:
                    matches.append([(x, y), (x, y + 1), (x, y + 2)])
        return matches

class Score:
    def __init__(self) -> None:
        self.points = 0
        self.moves_used = 0

    def add_points(self, points: int) -> None:
        self.points += points

    def get_score(self) -> int:
        return self.points

    def increment_moves(self) -> None:
        self.moves_used += 1

class Level:
    def __init__(self, difficulty: int) -> None:
        self.difficulty = difficulty
        self.move_limit = 10  # Example move limit

    def next_level(self) -> None:
        self.difficulty += 1
        self.move_limit += 5  # Increase move limit for next level

class PowerUp:
    def __init__(self, type: str) -> None:
        self.type = type

    def activate(self, game: 'Game') -> None:
        if self.type == "row_clear":
            game.clear_row()
        elif self.type == "column_clear":
            game.clear_column()

class Game:
    def __init__(self) -> None:
        self.grid = Grid()
        self.score = Score()
        self.level = Level(difficulty=1)
        self.colors = ["red", "green", "blue", "yellow", "purple"]
        self.power_ups = []
        self.load_settings()

    def load_settings(self) -> None:
        try:
            with open('settings.json', 'r') as f:
                settings = json.load(f)
                self.level.difficulty = settings.get("difficulty", 1)
                self.level.move_limit = settings.get("move_limit", 10)
        except (FileNotFoundError, json.JSONDecodeError) as e:
            print(f"Error loading settings: {e}")

    def start_game(self) -> None:
        self.grid.initialize_grid(size=8, colors=self.colors)
        self.run_game_loop()

    def run_game_loop(self) -> None:
        while True:
            matches = self.check_matches()
            if matches:
                self.clear_matches(matches)

    def swap_blocks(self, pos1: tuple, pos2: tuple) -> bool:
        block1 = self.grid.get_block(pos1)
        block2 = self.grid.get_block(pos2)
        self.grid.swap(pos1, pos2)
        self.score.increment_moves()
        return True

    def check_matches(self) -> list:
        return self.grid.get_matches()

    def clear_matches(self, matches: list) -> None:
        for match in matches:
            for pos in match:
                self.grid.set_block(pos, Block(choice(self.colors)))  # Replace with new block
        points = self.calculate_combo_score(matches)
        self.update_score(points)

    def update_score(self, points: int) -> None:
        self.score.add_points(points)

    def calculate_combo_score(self, combos: list) -> int:
        score_increase = 0
        for combo in combos:
            score_increase += self.calculate_points(combo)
        return score_increase

    def calculate_points(self, combo: list) -> int:
        return len(combo) * 10  # 10 points per block in combo

    def clear_row(self) -> None:
        # Logic to clear a row
        pass

    def clear_column(self) -> None:
        # Logic to clear a column
        pass