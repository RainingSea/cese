import unittest
from game import Game, Grid, Block

class TestColorSwapChallenge(unittest.TestCase):

    def setUp(self):
        # Initialize the game and its components
        self.game = Game()
        self.grid = self.game.grid

    def test_control_grid_of_colored_blocks(self):
        # Functionality 1: Control the Grid of Colored Blocks
        # Test initial grid setup
        initial_colors = [[block.get_color() for block in row] for row in self.grid.blocks]
        self.assertEqual(len(initial_colors), 5, "Grid should have 5 rows")
        self.assertEqual(len(initial_colors[0]), 5, "Grid should have 5 columns")

        # Test swapping adjacent blocks
        pos1 = (0, 0)
        pos2 = (0, 1)
        color1 = self.grid.blocks[pos1[0]][pos1[1]].get_color()
        color2 = self.grid.blocks[pos2[0]][pos2[1]].get_color()
        self.game.swap_blocks(pos1, pos2)
        self.assertEqual(self.grid.blocks[pos1[0]][pos1[1]].get_color(), color2, "Blocks should be swapped")
        self.assertEqual(self.grid.blocks[pos2[0]][pos2[1]].get_color(), color1, "Blocks should be swapped")

    def test_clear_blocks_by_matching(self):
        # Functionality 2: Clear Blocks by Matching
        # Test clearing blocks by matching
        self.grid.blocks[0][0] = Block('red')
        self.grid.blocks[0][1] = Block('red')
        self.grid.blocks[0][2] = Block('red')
        matches = self.grid.find_matches()
        self.assertGreater(len(matches), 0, "There should be matches found")
        self.game.clear_matches()
        self.assertNotEqual(self.grid.blocks[0][0].get_color(), 'red', "Matched blocks should be cleared")

    def test_level_progression_and_difficulty(self):
        # Functionality 3: Level Progression and Difficulty
        # Test level progression
        initial_level = self.game.level.number
        self.game.level.next_level()
        self.assertEqual(self.game.level.number, initial_level + 1, "Level should progress to the next level")

    def test_scoring_system(self):
        # Functionality 4: Scoring System
        # Test score increase
        initial_score = self.game.score.points
        self.game.update_score(10)
        self.assertEqual(self.game.score.points, initial_score + 10, "Score should increase by 10 points")

    def test_power_ups_activation(self):
        # Functionality 5: Power-ups Activation
        # Test power-up activation (not implemented in codebase)
        self.fail("Power-ups activation functionality is not implemented in the codebase")

    def test_move_limit_tracking(self):
        # Functionality 6: Move Limit Tracking
        # Test move limit tracking
        initial_moves = self.game.score.moves
        self.game.score.use_move()
        self.assertEqual(self.game.score.moves, initial_moves - 1, "Moves should decrease by 1")

    def test_bonus_points_for_combos(self):
        # Functionality 7: Bonus Points for Combos
        # Test bonus points for combos (not implemented in codebase)
        self.fail("Bonus points for combos functionality is not implemented in the codebase")

    def test_data_storage(self):
        # Functionality 8: Data Storage
        # Test saving and loading game data
        data = {'player1': '200|2|3'}
        self.game.save_game_data(data)
        loaded_data = self.game.load_game_data()
        self.assertEqual(loaded_data['player1'], '200|2|3', "Game data should be saved and loaded correctly")

if __name__ == '__main__':
    unittest.main()
