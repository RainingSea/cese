import pygame
from game import Game

def main() -> None:
    pygame.init()
    game = Game()
    game.start_game()
    # Placeholder for game loop
    pygame.quit()

if __name__ == "__main__":
    main()