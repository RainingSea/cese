import pygame
import random

class Block:
    def __init__(self, color: str):
        self.color = color

class Grid:
    def __init__(self):
        self.blocks = []

    def create_grid(self, rows: int, cols: int, colors: list):
        self.blocks = [[Block(random.choice(colors)) for _ in range(cols)] for _ in range(rows)]

    def check_matches(self):
        matches = []
        for row in range(len(self.blocks)):
            for col in range(len(self.blocks[row])):
                if col < len(self.blocks[row]) - 2 and self.blocks[row][col].color == self.blocks[row][col + 1].color == self.blocks[row][col + 2].color:
                    matches.append((row, col))
                    matches.append((row, col + 1))
                    matches.append((row, col + 2))
                if row < len(self.blocks) - 2 and self.blocks[row][col].color == self.blocks[row + 1][col].color == self.blocks[row + 2][col].color:
                    matches.append((row, col))
                    matches.append((row + 1, col))
                    matches.append((row + 2, col))
        return list(set(matches))

    def clear_matches(self, matches: list):
        for row, col in matches:
            self.blocks[row][col] = Block(random.choice(['red', 'green', 'blue', 'yellow', 'purple']))

class Scoreboard:
    def __init__(self):
        self.score = 0
        self.moves_used = 0

    def update_score(self, points: int):
        self.score += points

    def reset(self):
        self.score = 0
        self.moves_used = 0

class Level:
    def __init__(self, move_limit: int, target_blocks: int):
        self.move_limit = move_limit
        self.target_blocks = target_blocks

class Game:
    def __init__(self):
        self.grid = Grid()
        self.scoreboard = Scoreboard()
        self.level = None

    def start_game(self):
        pygame.init()
        self.load_level(1)

    def load_level(self, level_number: int):
        with open('levels.txt', 'r') as file:
            lines = file.readlines()
            level_data = lines[level_number - 1].strip().split('|')
            rows, cols, colors, move_limit, target_blocks = int(level_data[0]), int(level_data[1]), level_data[2].split(','), int(level_data[3]), int(level_data[4])
            self.grid.create_grid(rows, cols, colors)
            self.level = Level(move_limit, target_blocks)

    def swap_blocks(self, block1: Block, block2: Block):
        block1.color, block2.color = block2.color, block1.color

    def update_score(self, points: int):
        self.scoreboard.update_score(points)