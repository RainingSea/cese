[OUTPUT]
## general overview of the project
Develop a Color Swap Challenge game. You must design a GUI.

## software functional requirements
1. The game shall allow the player to control a grid of colored blocks and swap adjacent blocks.
2. The game shall require the player to create matches of three or more blocks of the same color to progress.
3. The game shall automatically clear matches when three or more blocks of the same color are aligned either horizontally or vertically.
4. The game shall include multiple levels, each with increasing difficulty, featuring larger grids, more complex block arrangements, and additional color types.
5. The game shall allow players to earn bonus points by creating combos or activating power-ups that clear blocks in specific patterns.
6. The game shall track the number of moves used to complete each level and enforce a move limit for level completion.
7. The game shall provide players with the ability to use power-ups strategically to assist in clearing the board, with new power-ups available as players progress.
8. The game shall implement a scoring system that calculates points based on the number of blocks cleared, combos achieved, and the number of moves used to complete each level.
[/OUTPUT]