import pygame
from game import Game

def main():
    pygame.init()
    game = Game()
    game.start_game()
    # Main game loop can be implemented here

if __name__ == "__main__":
    main()