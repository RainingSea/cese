class Level:
    def __init__(self, level_number: int, move_limit: int):
        self.level_number = level_number
        self.move_limit = move_limit

    def get_move_limit(self) -> int:
        return self.move_limit