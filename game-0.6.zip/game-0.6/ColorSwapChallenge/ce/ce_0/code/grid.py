from block import Block

class Grid:
    def __init__(self):
        self.blocks = []

    def initialize_grid(self, size: int):
        self.blocks = [[Block("red"), Block("green"), Block("blue")] for _ in range(size)]

    def get_block(self, pos: tuple) -> Block:
        x, y = pos
        return self.blocks[y][x]

    def set_block(self, pos: tuple, block: Block):
        x, y = pos
        self.blocks[y][x] = block