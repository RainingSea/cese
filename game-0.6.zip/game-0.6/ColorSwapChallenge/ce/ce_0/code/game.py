import json
from grid import Grid
from score import Score
from level import Level

class Game:
    def __init__(self):
        self.grid = Grid()
        self.score = Score()
        self.level = Level(1, 20)

    def start_game(self):
        self.grid.initialize_grid(8)

    def swap_blocks(self, pos1: tuple, pos2: tuple) -> bool:
        block1 = self.grid.get_block(pos1)
        block2 = self.grid.get_block(pos2)
        self.grid.set_block(pos1, block2)
        self.grid.set_block(pos2, block1)
        return True

    def check_matches(self) -> list:
        # Dummy implementation for checking matches
        return []

    def clear_matches(self, matches: list):
        # Dummy implementation for clearing matches
        pass

    def update_score(self, points: int):
        self.score.add_points(points)

    def load_level(self, level_number: int):
        with open('levels.txt', 'r') as file:
            levels = json.load(file)
            self.level = Level(level_number, levels[str(level_number)])

    def save_score(self, player_name: str):
        with open('scores.txt', 'a') as file:
            file.write(f"{player_name}|{self.score.get_score()}\n")