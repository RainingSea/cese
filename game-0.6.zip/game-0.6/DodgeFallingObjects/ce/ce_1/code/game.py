import pygame
import random

class Player:
    def __init__(self, x: int, width: int, height: int):
        self.x = x
        self.width = width
        self.height = height

    def move_left(self):
        self.x -= 5

    def move_right(self):
        self.x += 5

class Block:
    def __init__(self, x: int, y: int, width: int, height: int):
        self.x = x
        self.y = y
        self.width = width
        self.height = height

    def fall(self, speed: int):
        self.y += speed

class Game:
    def __init__(self):
        self.player = Player(200, 50, 20)
        self.blocks = []
        self.score = 0
        self.speed = 5

    def run(self):
        pygame.init()
        screen = pygame.display.set_mode((400, 600))
        clock = pygame.time.Clock()
        running = True

        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False

            keys = pygame.key.get_pressed()
            if keys[pygame.K_LEFT] and self.player.x > 0:
                self.player.move_left()
            if keys[pygame.K_RIGHT] and self.player.x < 400 - self.player.width:
                self.player.move_right()

            self.update_blocks()
            self.check_collision()
            self.display_score(screen)

            screen.fill((0, 0, 0))
            pygame.draw.rect(screen, (0, 255, 0), (self.player.x, 580, self.player.width, self.player.height))
            for block in self.blocks:
                pygame.draw.rect(screen, (255, 0, 0), (block.x, block.y, block.width, block.height))

            pygame.display.flip()
            clock.tick(30)

        self.save_score()
        pygame.quit()

    def update_blocks(self):
        if random.randint(1, 20) == 1:  # Randomly add blocks
            x_pos = random.randint(0, 400 - 30)
            self.blocks.append(Block(x_pos, 0, 30, 30))

        for block in self.blocks:
            block.fall(self.speed)

        self.blocks = [block for block in self.blocks if block.y < 600]

    def check_collision(self):
        for block in self.blocks:
            if (self.player.x < block.x + block.width and
                self.player.x + self.player.width > block.x and
                580 < block.y + block.height):
                self.score += 1
                self.blocks.remove(block)

    def display_score(self, screen):
        font = pygame.font.Font(None, 36)
        score_text = font.render(f'Score: {self.score}', True, (255, 255, 255))
        screen.blit(score_text, (10, 10))

    def save_score(self):
        with open('scores.txt', 'a') as file:
            file.write(f'{self.score}\n')