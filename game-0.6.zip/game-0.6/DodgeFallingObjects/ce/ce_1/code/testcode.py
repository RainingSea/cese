import unittest
import pygame
from game import Game, Player, Block

class TestDodgeFallingObjectsGame(unittest.TestCase):

    def setUp(self):
        # Initialize the game and its components
        self.game = Game()
        self.player = self.game.player

    def test_player_movement(self):
        # Functionality 1: Player Movement
        initial_x = self.player.x

        # Test moving left
        self.player.move_left()
        self.assertLess(self.player.x, initial_x, "Player should move left")

        # Test moving right
        initial_x = self.player.x
        self.player.move_right()
        self.assertGreater(self.player.x, initial_x, "Player should move right")

        # Test boundary conditions
        self.player.x = 0
        self.player.move_left()
        self.assertEqual(self.player.x, 0, "Player should not move beyond the left edge")

        self.player.x = 400 - self.player.width
        self.player.move_right()
        self.assertEqual(self.player.x, 400 - self.player.width, "Player should not move beyond the right edge")

    def test_collision_detection(self):
        # Functionality 2: Collision Detection
        block = Block(self.player.x, 580, self.player.width, self.player.height)
        self.game.blocks.append(block)
        self.game.check_collision()
        self.assertEqual(self.game.score, 1, "Score should increase when player collides with a block")

        # Test avoiding collision
        self.player.x = 0
        self.game.blocks.append(Block(100, 580, self.player.width, self.player.height))
        self.game.check_collision()
        self.assertEqual(self.game.score, 1, "Score should not increase when player avoids a block")

    def test_falling_blocks_behavior(self):
        # Functionality 3: Falling Blocks Behavior
        initial_block_count = len(self.game.blocks)
        self.game.update_blocks()
        self.assertGreaterEqual(len(self.game.blocks), initial_block_count, "Blocks should appear randomly")

        # Test increasing speed
        initial_speed = self.game.speed
        self.game.speed += 1
        self.assertGreater(self.game.speed, initial_speed, "Block speed should increase over time")

    def test_scoring_system(self):
        # Functionality 4: Scoring System
        initial_score = self.game.score
        self.game.check_collision()
        self.assertGreaterEqual(self.game.score, initial_score, "Score should increase based on time survived")

    def test_player_movement_constraints(self):
        # Functionality 5: Player Movement Constraints
        initial_y = self.player.height
        self.player.move_left()
        self.assertEqual(self.player.height, initial_y, "Player should not move vertically")

    def test_game_over_condition(self):
        # Functionality 6: Game Over Condition
        block = Block(self.player.x, 580, self.player.width, self.player.height)
        self.game.blocks.append(block)
        self.game.check_collision()
        self.assertEqual(self.game.score, 1, "Game should end when player collides with a block")

    def test_data_storage(self):
        # Functionality 7: Data Storage
        self.game.save_score()
        with open('scores.txt', 'r') as file:
            scores = file.readlines()
        self.assertIn(f'{self.game.score}\n', scores, "Score should be saved to a local text file")

if __name__ == '__main__':
    unittest.main()
