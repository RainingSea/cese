class Player:
    def __init__(self, x: int, y: int):
        self.x = x
        self.y = y

    def move_left(self):
        self.x -= 5  # Move left by 5 pixels

    def move_right(self):
        self.x += 5  # Move right by 5 pixels