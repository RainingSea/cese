import pygame
from player import Player
from block import Block

class Game:
    def __init__(self):
        self.player = Player(250, 400)  # Initial player position
        self.blocks = []
        self.score = 0
        self.running = True
        self.screen = pygame.display.set_mode((500, 500))
        pygame.display.set_caption("Dodge the Falling Blocks")

    def run(self):
        while self.running:
            self.handle_events()
            self.update()
            self.draw()
            pygame.display.flip()
            pygame.time.delay(30)

    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False

        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] and self.player.x > 0:
            self.player.move_left()
        if keys[pygame.K_RIGHT] and self.player.x < 500:
            self.player.move_right()

    def update(self):
        if random.randint(1, 20) == 1:  # Randomly spawn blocks
            new_block = Block(random.randint(0, 480), 0, random.randint(1, 5))
            self.blocks.append(new_block)

        for block in self.blocks:
            block.fall()
            if block.y > 500:  # Remove block if it falls off the screen
                self.blocks.remove(block)
                self.score += 1
            if self.check_collision():
                self.save_score()
                self.running = False

    def draw(self):
        self.screen.fill((255, 255, 255))  # Clear screen with white
        pygame.draw.rect(self.screen, (0, 0, 255), (self.player.x, self.player.y, 20, 20))  # Draw player

        for block in self.blocks:
            pygame.draw.rect(self.screen, (255, 0, 0), (block.x, block.y, 20, 20))  # Draw blocks

        font = pygame.font.SysFont(None, 36)
        score_text = font.render(f'Score: {self.score}', True, (0, 0, 0))
        self.screen.blit(score_text, (10, 10))  # Draw score

    def check_collision(self) -> bool:
        for block in self.blocks:
            if (self.player.x < block.x + 20 and
                self.player.x + 20 > block.x and
                self.player.y < block.y + 20 and
                self.player.y + 20 > block.y):
                return True
        return False

    def save_score(self):
        with open('scores.txt', 'a') as f:
            f.write(f'{self.score}\n')