import random

class Block:
    def __init__(self, x: int, y: int, speed: int):
        self.x = x
        self.y = y
        self.speed = speed

    def fall(self):
        self.y += self.speed  # Move down by the speed value