import unittest
import pygame
from game import Game
from player import Player
from block import Block

class TestDodgeFallingObjectsGame(unittest.TestCase):

    def setUp(self):
        # Initialize the game and its components
        pygame.init()
        self.game = Game()
        self.player = self.game.player
        self.blocks = self.game.blocks

    def test_player_movement(self):
        # Functionality 1: Player Movement
        initial_x = self.player.x

        # Simulate left arrow key press
        self.player.move_left()
        self.assertLess(self.player.x, initial_x, "Player should move left")

        # Simulate right arrow key press
        initial_x = self.player.x
        self.player.move_right()
        self.assertGreater(self.player.x, initial_x, "Player should move right")

        # Attempt to move beyond the left edge
        self.player.x = 0
        self.player.move_left()
        self.assertEqual(self.player.x, 0, "Player should not move beyond the left edge")

        # Attempt to move beyond the right edge
        self.player.x = 500
        self.player.move_right()
        self.assertEqual(self.player.x, 500, "Player should not move beyond the right edge")

    def test_collision_detection(self):
        # Functionality 2: Collision Detection
        self.blocks.append(Block(self.player.x, self.player.y, 0))
        self.assertTrue(self.game.check_collision(), "Collision should be detected")

        # Move player to avoid collision
        self.player.x = 100
        self.assertFalse(self.game.check_collision(), "Player should avoid the block")

    def test_falling_blocks_behavior(self):
        # Functionality 3: Falling Blocks Behavior
        initial_block_count = len(self.blocks)
        self.game.update()
        self.assertGreaterEqual(len(self.blocks), initial_block_count, "Blocks should appear randomly")

        # Check if blocks fall straight down
        block = Block(100, 0, 1)
        self.blocks.append(block)
        block.fall()
        self.assertEqual(block.y, 1, "Block should fall straight down")

    def test_scoring_system(self):
        # Functionality 4: Scoring System
        initial_score = self.game.score
        self.game.blocks.append(Block(0, 501, 1))  # Simulate block falling off screen
        self.game.update()
        self.assertGreater(self.game.score, initial_score, "Score should increase when block falls off screen")

    def test_player_movement_constraints(self):
        # Functionality 5: Player Movement Constraints
        initial_y = self.player.y
        self.player.move_left()
        self.assertEqual(self.player.y, initial_y, "Player should not move vertically")

    def test_game_over_condition(self):
        # Functionality 6: Game Over Condition
        self.blocks.append(Block(self.player.x, self.player.y, 0))
        self.game.update()
        self.assertFalse(self.game.running, "Game should end on collision")

        # Restart the game
        self.game.running = True
        self.assertTrue(self.game.running, "Game should be able to restart")

    def test_data_storage(self):
        # Functionality 7: Data Storage
        self.game.score = 10
        self.game.save_score()
        with open('scores.txt', 'r') as f:
            scores = f.readlines()
        self.assertIn('10\n', scores, "Score should be saved to the file")

if __name__ == '__main__':
    unittest.main()
