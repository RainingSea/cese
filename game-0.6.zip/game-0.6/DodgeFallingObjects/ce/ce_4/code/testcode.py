import unittest
import pygame
from game import Game, Player, Block
import os

class TestDodgeFallingObjectsGame(unittest.TestCase):

    def setUp(self):
        # Initialize the game and its components
        self.game = Game()
        self.player = self.game.player

    def test_player_movement(self):
        # Functionality 1: Player Movement
        initial_x = self.player.x

        # Test moving left
        self.player.move_left()
        self.assertLess(self.player.x, initial_x, "Player should move left")

        # Test moving right
        initial_x = self.player.x
        self.player.move_right()
        self.assertGreater(self.player.x, initial_x, "Player should move right")

        # Test boundary on the left
        self.player.x = 0
        self.player.move_left()
        self.assertEqual(self.player.x, 0, "Player should not move beyond the left edge")

        # Test boundary on the right
        self.player.x = 600
        self.player.move_right()
        self.assertEqual(self.player.x, 600, "Player should not move beyond the right edge")

    def test_collision_detection(self):
        # Functionality 2: Collision Detection
        block = Block(self.player.x, self.player.y)
        self.game.blocks.append(block)

        # Simulate collision
        self.game.check_collision()
        self.assertFalse(pygame.get_init(), "Game should end on collision")

    def test_falling_blocks_behavior(self):
        # Functionality 3: Falling Blocks Behavior
        initial_block_count = len(self.game.blocks)
        self.game.update()
        self.assertGreaterEqual(len(self.game.blocks), initial_block_count, "Blocks should appear randomly")

    def test_scoring_system(self):
        # Functionality 4: Scoring System
        initial_score = self.game.score
        block = Block(0, 601)  # Simulate a block falling past the screen
        self.game.blocks.append(block)
        self.game.update()
        self.assertGreater(self.game.score, initial_score, "Score should increase when a block falls past the screen")

    def test_player_movement_constraints(self):
        # Functionality 5: Player Movement Constraints
        initial_y = self.player.y
        self.player.move_left()
        self.assertEqual(self.player.y, initial_y, "Player should not move vertically")

    def test_game_over_condition(self):
        # Functionality 6: Game Over Condition
        block = Block(self.player.x, self.player.y)
        self.game.blocks.append(block)
        self.game.check_collision()
        self.assertFalse(pygame.get_init(), "Game should end immediately on collision")

    def test_data_storage(self):
        # Functionality 7: Data Storage
        self.game.score = 10
        self.game.save_score()
        with open('scores.txt', 'r') as file:
            scores = file.readlines()
        self.assertIn('score: 10\n', scores, "Score should be saved to the file")

if __name__ == '__main__':
    unittest.main()
