import pygame
import random

class Player:
    def __init__(self):
        self.x = 300
        self.y = 550

    def move_left(self):
        if self.x > 0:
            self.x -= 5

    def move_right(self):
        if self.x < 600:
            self.x += 5

    def get_position(self):
        return (self.x, self.y)

class Block:
    def __init__(self, x: int, y: int):
        self.x = x
        self.y = y
        self.speed = random.randint(3, 6)

    def fall(self):
        self.y += self.speed

    def get_position(self):
        return (self.x, self.y)

class Game:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((800, 600))
        self.player = Player()
        self.blocks = []
        self.score = 0
        self.speed = 5

    def run(self):
        clock = pygame.time.Clock()
        running = True
        while running:
            self.update()
            self.draw()
            clock.tick(60)

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_LEFT:
                        self.player.move_left()
                    if event.key == pygame.K_RIGHT:
                        self.player.move_right()

        self.save_score()
        pygame.quit()

    def update(self):
        if random.randint(1, 20) == 1:
            block_x = random.randint(0, 780)
            self.blocks.append(Block(block_x, 0))

        for block in self.blocks:
            block.fall()
            if block.y > 600:
                self.blocks.remove(block)
                self.score += 1

        self.check_collision()

    def draw(self):
        self.screen.fill((0, 0, 0))
        pygame.draw.rect(self.screen, (0, 255, 0), (self.player.get_position()[0], self.player.get_position()[1], 50, 50))
        for block in self.blocks:
            pygame.draw.rect(self.screen, (255, 0, 0), (block.get_position()[0], block.get_position()[1], 50, 50))
        font = pygame.font.Font(None, 36)
        text = font.render(f'Score: {self.score}', True, (255, 255, 255))
        self.screen.blit(text, (10, 10))
        pygame.display.flip()

    def check_collision(self):
        player_rect = pygame.Rect(self.player.get_position()[0], self.player.get_position()[1], 50, 50)
        for block in self.blocks:
            block_rect = pygame.Rect(block.get_position()[0], block.get_position()[1], 50, 50)
            if player_rect.colliderect(block_rect):
                self.save_score()
                pygame.quit()

    def save_score(self):
        with open('scores.txt', 'a') as file:
            file.write(f'score: {self.score}\n')