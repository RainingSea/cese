class Player:
    def __init__(self):
        self.x = 400  # Starting position
        self.width = 50
        self.height = 50

    def move_left(self):
        if self.x > 0:
            self.x -= 5  # Adjust speed of movement

    def move_right(self):
        if self.x < 800 - self.width:
            self.x += 5  # Adjust speed of movement