import unittest
import pygame
from game import Game
from player import Player
from block import Block
import os

class TestDodgeFallingObjectsGame(unittest.TestCase):

    def setUp(self):
        # Initialize the game and its components
        self.game = Game()
        self.player = self.game.player

    def test_player_movement(self):
        # Functionality 1: Player Movement
        initial_x = self.player.x

        # Simulate left arrow key press
        self.player.move_left()
        self.assertLess(self.player.x, initial_x, "Player should move left")

        # Simulate right arrow key press
        initial_x = self.player.x
        self.player.move_right()
        self.assertGreater(self.player.x, initial_x, "Player should move right")

        # Attempt to move beyond the left edge
        self.player.x = 0
        self.player.move_left()
        self.assertEqual(self.player.x, 0, "Player should not move beyond the left edge")

        # Attempt to move beyond the right edge
        self.player.x = 800 - self.player.width
        self.player.move_right()
        self.assertEqual(self.player.x, 800 - self.player.width, "Player should not move beyond the right edge")

    def test_collision_detection(self):
        # Functionality 2: Collision Detection
        block = Block()
        block.x = self.player.x
        block.y = 550 - block.size

        # Simulate collision
        self.assertTrue(self.game.check_collision(block), "Collision should be detected")

        # Simulate avoiding collision
        block.x = self.player.x + self.player.width + 1
        self.assertFalse(self.game.check_collision(block), "Collision should not be detected")

    def test_falling_blocks_behavior(self):
        # Functionality 3: Falling Blocks Behavior
        block = Block()
        initial_y = block.y
        block.fall()
        self.assertGreater(block.y, initial_y, "Block should fall down")

        # Test speed increase over time (not implemented in codebase)
        self.fail("Speed increase over time is not implemented in the codebase")

    def test_scoring_system(self):
        # Functionality 4: Scoring System
        initial_score = self.game.score
        self.game.update()
        self.assertGreaterEqual(self.game.score, initial_score, "Score should increase over time")

        # Simulate game over and check score display (not directly testable here)
        self.fail("Final score display after game over is not directly testable in unit tests")

    def test_player_movement_constraints(self):
        # Functionality 5: Player Movement Constraints
        initial_y = self.player.x

        # Attempt vertical movement
        self.player.move_left()
        self.assertEqual(self.player.x, initial_y, "Player should not move vertically")

    def test_game_over_condition(self):
        # Functionality 6: Game Over Condition
        block = Block()
        block.x = self.player.x
        block.y = 550 - block.size

        # Simulate collision and game over
        self.assertTrue(self.game.check_collision(block), "Game should end on collision")

        # Restart game (not directly testable here)
        self.fail("Game restart after game over is not directly testable in unit tests")

    def test_data_storage(self):
        # Functionality 7: Data Storage
        self.game.save_score()
        self.assertTrue(os.path.exists('scores.txt'), "Score file should exist")

        with open('scores.txt', 'r') as f:
            scores = f.readlines()
            self.assertIn(f"{self.game.score}\n", scores, "Score should be recorded in the file")

if __name__ == '__main__':
    unittest.main()
