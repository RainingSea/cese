import pygame
from player import Player
from block import Block

class Game:
    def __init__(self):
        self.player = Player()
        self.blocks = []
        self.score = 0
        self.speed = 5
        pygame.init()
        self.screen = pygame.display.set_mode((800, 600))
        pygame.display.set_caption("Dodge the Falling Blocks")

    def run(self):
        clock = pygame.time.Clock()
        while True:
            self.handle_input()
            self.update()
            self.draw()
            clock.tick(60)

    def handle_input(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()

        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            self.player.move_left()
        if keys[pygame.K_RIGHT]:
            self.player.move_right()

    def update(self):
        if len(self.blocks) < 5:  # Limit number of blocks
            self.blocks.append(Block())

        for block in self.blocks:
            block.fall()
            if self.check_collision(block):
                self.save_score()
                pygame.quit()
                exit()
            if block.y > 600:
                self.blocks.remove(block)
                self.score += 1  # Increase score for each survived block

    def draw(self):
        self.screen.fill((0, 0, 0))
        pygame.draw.rect(self.screen, (0, 255, 0), (self.player.x, 550, self.player.width, self.player.height))
        for block in self.blocks:
            pygame.draw.rect(self.screen, (255, 0, 0), (block.x, block.y, block.size, block.size))
        font = pygame.font.Font(None, 36)
        score_text = font.render(f"Score: {self.score}", True, (255, 255, 255))
        self.screen.blit(score_text, (10, 10))
        pygame.display.flip()

    def check_collision(self, block):
        return (self.player.x < block.x + block.size and
                self.player.x + self.player.width > block.x and
                550 < block.y + block.size)

    def save_score(self):
        with open('scores.txt', 'a') as f:
            f.write(f"{self.score}\n")