import random

class Block:
    def __init__(self):
        self.size = random.randint(20, 50)
        self.x = random.randint(0, 800 - self.size)
        self.y = 0

    def fall(self):
        self.y += 5  # Adjust speed of falling blocks

    def reset(self):
        self.size = random.randint(20, 50)
        self.x = random.randint(0, 800 - self.size)
        self.y = 0