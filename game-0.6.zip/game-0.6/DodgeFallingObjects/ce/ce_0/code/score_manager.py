import pygame

class ScoreManager:
    def __init__(self):
        self.score = 0

    def update_score(self):
        self.score += 1

    def get_score(self):
        return self.score

    def save_score(self, player_name: str):
        with open("scores.txt", "a") as f:
            f.write(f"{player_name}:{self.score}\n")

    def display_score(self, screen):
        font = pygame.font.Font(None, 36)
        score_surface = font.render(f"Score: {self.score}", True, (0, 0, 0))
        screen.blit(score_surface, (10, 10))