import pygame
import random

class BlocksManager:
    def __init__(self):
        self.blocks = []
        self.fall_speed = 5
        self.spawn_block()

    def spawn_block(self):
        x_position = random.randint(0, 750)  # Assuming the screen width is 800
        self.blocks.append(pygame.Rect(x_position, 0, 50, 50))

    def update_blocks(self):
        for block in self.blocks:
            block.y += self.fall_speed
        self.blocks = [block for block in self.blocks if block.y < 600]  # Keep only blocks on screen
        
        if random.random() < 0.02:  # 2% chance to spawn a block each frame
            self.spawn_block()

    def get_blocks(self):
        return self.blocks

    def draw_blocks(self, screen):
        for block in self.blocks:
            pygame.draw.rect(screen, (255, 0, 0), block)