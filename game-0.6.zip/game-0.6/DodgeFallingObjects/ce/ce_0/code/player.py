import pygame

class Player:
    def __init__(self, position):
        self.position = position
        self.speed = 5

    def move_left(self):
        if self.position[0] > 0:
            self.position = (self.position[0] - self.speed, self.position[1])

    def move_right(self):
        if self.position[0] < 750:  # Assuming the screen width is 800
            self.position = (self.position[0] + self.speed, self.position[1])

    def get_position(self):
        return self.position

    def draw(self, screen):
        pygame.draw.rect(screen, (0, 0, 255), (*self.position, 50, 50))