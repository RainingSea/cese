import unittest
import pygame
from player import Player
from blocks_manager import BlocksManager
from game_state import GameState
from score_manager import ScoreManager
from game import Game

class TestDodgeFallingObjectsGame(unittest.TestCase):

    def setUp(self):
        pygame.init()
        self.game = Game()
        self.player = self.game.player
        self.blocks_manager = self.game.blocks_manager
        self.score_manager = self.game.score_manager
        self.state = self.game.state

    def test_player_movement(self):
        # Functionality 1: Player Movement
        initial_position = self.player.get_position()

        # Move left
        self.player.move_left()
        self.assertLess(self.player.get_position()[0], initial_position[0], "Player should move left")

        # Move right
        self.player.move_right()
        self.assertGreater(self.player.get_position()[0], initial_position[0], "Player should move right")

        # Attempt to move beyond left edge
        self.player.position = (0, self.player.position[1])
        self.player.move_left()
        self.assertEqual(self.player.get_position()[0], 0, "Player should not move beyond the left edge")

        # Attempt to move beyond right edge
        self.player.position = (750, self.player.position[1])
        self.player.move_right()
        self.assertEqual(self.player.get_position()[0], 750, "Player should not move beyond the right edge")

    def test_collision_detection(self):
        # Functionality 2: Collision Detection
        self.blocks_manager.blocks.append(pygame.Rect(self.player.get_position(), (50, 50)))
        self.assertTrue(self.game.check_collision(), "Collision should be detected")

        # Move player to avoid collision
        self.player.move_right()
        self.assertFalse(self.game.check_collision(), "Player should avoid the block")

    def test_falling_blocks_behavior(self):
        # Functionality 3: Falling Blocks Behavior
        initial_blocks_count = len(self.blocks_manager.get_blocks())
        self.blocks_manager.update_blocks()
        self.assertGreaterEqual(len(self.blocks_manager.get_blocks()), initial_blocks_count, "Blocks should spawn randomly")

    def test_scoring_system(self):
        # Functionality 4: Scoring System
        initial_score = self.score_manager.get_score()
        self.score_manager.update_score()
        self.assertGreater(self.score_manager.get_score(), initial_score, "Score should increase over time")

    def test_player_movement_constraints(self):
        # Functionality 5: Player Movement Constraints
        initial_position = self.player.get_position()

        # Attempt vertical movement
        self.player.position = (self.player.position[0], 500)
        self.assertEqual(self.player.get_position()[1], 550, "Player should not move vertically")

    def test_game_over_condition(self):
        # Functionality 6: Game Over Condition
        self.state.set_running(True)
        self.blocks_manager.blocks.append(pygame.Rect(self.player.get_position(), (50, 50)))
        self.game.update()
        self.assertFalse(self.state.is_game_running(), "Game should end on collision")

    def test_data_storage(self):
        # Functionality 7: Data Storage
        self.score_manager.save_score("TestPlayer")
        with open("scores.txt", "r") as f:
            scores = f.readlines()
        self.assertIn("TestPlayer", scores[-1], "Score should be saved to file")

if __name__ == '__main__':
    unittest.main()
