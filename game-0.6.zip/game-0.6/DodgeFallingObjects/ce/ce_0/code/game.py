import pygame
from player import Player
from blocks_manager import BlocksManager
from score_manager import ScoreManager
from game_state import GameState

class Game:
    def __init__(self):
        self.player = Player((400, 550))
        self.blocks_manager = BlocksManager()
        self.score_manager = ScoreManager()
        self.state = GameState()
        self.state.set_running(True)
        self.screen = pygame.display.set_mode((800, 600))
        pygame.display.set_caption("Dodge the Falling Blocks")
        self.clock = pygame.time.Clock()

    def run(self):
        while self.state.is_game_running():
            self.handle_events()
            self.update()
            self.render()
            self.clock.tick(60)
        self.end_game()

    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.state.set_running(False

    def update(self):
        self.player.move_left() if pygame.key.get_pressed()[pygame.K_LEFT] else None
        self.player.move_right() if pygame.key.get_pressed()[pygame.K_RIGHT] else None
        self.blocks_manager.update_blocks()
        if self.check_collision():
            self.state.set_running(False

    def render(self):
        self.screen.fill((255, 255, 255))
        self.player.draw(self.screen)
        self.blocks_manager.draw_blocks(self.screen)
        self.score_manager.display_score(self.screen)
        pygame.display.flip()

    def check_collision(self):
        player_rect = pygame.Rect(self.player.get_position(), (50, 50))
        for block in self.blocks_manager.get_blocks():
            if player_rect.colliderect(block):
                return True
        return False

    def end_game(self):
        self.score_manager.save_score("PlayerName")  # Placeholder for player name
        print("Game Over! Final Score:", self.score_manager.get_score())