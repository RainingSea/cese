class GameState:
    def __init__(self):
        self.is_running = False

    def set_running(self, state: bool):
        self.is_running = state

    def is_game_running(self):
        return self.is_running