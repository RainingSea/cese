[OUTPUT]
## general overview of the project
Develop a Dodge the Falling Blocks game. You must design a GUI.

## software functional requirements
1. The game shall allow the player to control a small character positioned at the bottom of the screen.
2. The game shall enable the player to move the character left or right using the arrow keys on the keyboard.
3. The game shall generate falling blocks that drop from the top of the screen at random intervals.
4. The falling blocks shall move straight down the screen and increase in speed as the player survives longer.
5. The game shall implement a scoring system that tracks the amount of time the player has survived.
6. The player shall be able to dodge the falling blocks by moving left or right, but the character shall not be able to move vertically.
7. The game shall end when the player collides with a falling block, and the final score shall be displayed to the player.
8. The game shall store player scores in local text files for future reference.
[/OUTPUT]